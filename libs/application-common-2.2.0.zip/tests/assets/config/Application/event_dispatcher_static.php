<?php

declare(strict_types=1);

use Psr\Container\ContainerInterface;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;

return [
    PsrEventDispatcherInterface::class => \DI\decorate(
        function (PsrEventDispatcherInterface $previous, ContainerInterface $container): PsrEventDispatcherInterface {
            $event = (object)[
                'value' => $container->get('event_dispatcher_environment'),
            ];
            $previous->dispatch($event);
            return $previous;
        },
    ),
];
