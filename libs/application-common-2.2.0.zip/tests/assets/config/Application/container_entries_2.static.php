<?php

declare(strict_types=1);

return [
    'static_1' => \DI\value('static_value_1'),
    'static_3' => \DI\decorate(
        function (string $previous): string {
            return sprintf('%1$s_%2$s', $previous, 'decorated');
        },
    ),
];
