<?php

declare(strict_types=1);

return [
    'environment_1' => function (array $server) {
        return \DI\value($server['environment_1'] ?? null);
    },
    'environment_3' => function () {
        return \DI\decorate(
            function (string $previous): string {
                // this will fail in case the previous entry has been defaulted to null
                return sprintf('%1$s_%2$s', $previous, 'decorated');
            },
        );
    },
];
