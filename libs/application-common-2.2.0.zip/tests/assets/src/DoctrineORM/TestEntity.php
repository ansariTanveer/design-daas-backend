<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use BadMethodCallException;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass = "TestEntityRepository")
 * @ORM\Table(name = "TEST_ENTITIES")
 * @ORM\EntityListeners(value = {"Application\Test\Assets\DoctrineORM\TestEntityListener"})
 * @final
 *
 * Doctrine entities must not be final,
 *     see https://www.doctrine-project.org/projects/doctrine-orm/en/2.13/reference/architecture.html
 */
class TestEntity
{
    /**
     * @ORM\Id()
     * @ORM\Column(type = "integer", name = "id")
     * @ORM\GeneratedValue()
     */
    private ?int $id;

    /**
     * @ORM\Version()
     * @ORM\Column(type = "integer", name = "version")
     */
    private ?int $version;

    /**
     * @ORM\Column(type = "string", name = "value", length = 255)
     */
    private string $value;

    public function __construct(string $value)
    {
        $this->setValue($value);
        $this->id = null;
        $this->version = null;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function id(): int
    {
        assert($this->id !== null);
        return $this->id;
    }

    public function version(): int
    {
        assert($this->version !== null);
        return $this->version;
    }

    public function value(): string
    {
        return $this->value;
    }

    public function setValue(string $value): void
    {
        assert(mb_strlen($value) <= 255);
        $this->value = $value;
    }
}
