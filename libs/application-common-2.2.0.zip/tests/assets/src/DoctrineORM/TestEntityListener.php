<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use Closure;
use Doctrine\ORM\Event\PrePersistEventArgs;

final class TestEntityListener
{
    private Closure $callback;

    public function __construct(Closure $callback = null)
    {
        $this->callback = $callback ?? function (): void {
        };
    }

    public function prePersist(TestEntity $entity, PrePersistEventArgs $event): void
    {
        ($this->callback)($entity, $event);
    }
}
