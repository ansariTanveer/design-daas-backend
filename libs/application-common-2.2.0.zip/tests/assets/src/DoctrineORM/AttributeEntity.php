<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use BadMethodCallException;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\EntityListeners;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\ORM\Mapping\Table;
use Doctrine\ORM\Mapping\Version;

/**
 * @final
 *
 * This entity is expected to be picked up only in PHP versions >= 8.0
 *
 * Doctrine entities must not be final,
 *     see https://www.doctrine-project.org/projects/doctrine-orm/en/2.13/reference/architecture.html
 */
#[Entity(repositoryClass: AttributeEntityRepository::class)]
#[Table(name: 'ATTRIBUTE_ENTITIES')]
#[EntityListeners(value: [AttributeTestEntityListener::class])]
class AttributeEntity
{
    #[Id()]
    #[Column(name: 'id', type: 'integer')]
    #[GeneratedValue()]
    private ?int $id;

    #[Version()]
    #[Column(name: 'version', type: 'integer')]
    private ?int $version;

    #[Column(name: 'value', type: 'string', length: 255)]
    private string $value;

    public function __construct(string $value)
    {
        $this->setValue($value);
        $this->id = null;
        $this->version = null;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function id(): int
    {
        assert($this->id !== null);
        return $this->id;
    }

    public function version(): int
    {
        assert($this->version !== null);
        return $this->version;
    }

    public function value(): string
    {
        return $this->value;
    }

    public function setValue(string $value): void
    {
        assert(mb_strlen($value) <= 255);
        $this->value = $value;
    }
}
