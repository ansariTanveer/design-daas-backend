<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

final class AttributeTestEntityListener
{
}
