<?php

declare(strict_types=1);

namespace Application\Test\Assets\JsonDTO;

use Application\Common\JsonDTO\AbstractJsonDTO;
use stdClass;

final class ComplexTestDTO extends AbstractJsonDTO
{
    public SimpleTestDTO $childDTO;

    /**
     * @var SimpleTestDTO[]
     */
    public array $childDTOs;

    protected static function convertValueFromJson(string $name, $value)
    {
        switch ($name) {
            case 'childDTO':
                assert($value instanceof stdClass);
                return SimpleTestDTO::fromJson($value);
            case 'childDTOs':
                assert(is_array($value));
                return array_values(
                    array_map(
                        [SimpleTestDTO::class, 'fromJson'],
                        $value,
                    ),
                );
            default:
                return parent::convertValueFromJson($name, $value);
        }
    }
}
