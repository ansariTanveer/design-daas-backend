<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpMiddleware;

use Application\Common\HttpMiddleware\RemoveBodyFromHeadResponsesMiddleware;
use Application\Test\TestCase;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\StreamFactoryInterface;
use Psr\Http\Message\StreamInterface;

final class RemoveBodyFromHeadResponsesMiddlewareTest extends TestCase
{
    public function testRequestIsPassedOnCorrectly(): void
    {
        $factory = $this->createMock(StreamFactoryInterface::class);
        $expectedRequest = $this->createMock(ServerRequestInterface::class);
        $expectedRequest->expects(self::atLeastOnce())
            ->method('getMethod')
            ->willReturn('GET');

        $middleware = new RemoveBodyFromHeadResponsesMiddleware($factory);
        $middleware(
            $expectedRequest,
            function (ServerRequestInterface $actualRequest) use ($expectedRequest): ResponseInterface {
                self::assertSame($expectedRequest, $actualRequest);
                return $this->createMock(ResponseInterface::class);
            },
        );
    }

    public function testNonHeadResponseIsLeftUntouched(): void
    {
        $factory = $this->createMock(StreamFactoryInterface::class);

        $request = $this->createMock(ServerRequestInterface::class);
        $request->expects(self::atLeastOnce())
            ->method('getMethod')
            ->willReturn('GET');

        $expectedResponse = $this->createMock(ResponseInterface::class);
        $expectedResponse->expects(self::never())
            ->method('getBody');
        $expectedResponse->expects(self::never())
            ->method('withBody');

        $middleware = new RemoveBodyFromHeadResponsesMiddleware($factory);
        $response = $middleware(
            $request,
            function () use ($expectedResponse): ResponseInterface {
                return $expectedResponse;
            },
        );
        self::assertSame($expectedResponse, $response);
    }

    public function testEmptyHeadResponseIsLeftUntouched(): void
    {
        $factory = $this->createMock(StreamFactoryInterface::class);

        $request = $this->createMock(ServerRequestInterface::class);
        $request->expects(self::atLeastOnce())
            ->method('getMethod')
            ->willReturn('HEAD');

        $body = $this->createMock(StreamInterface::class);
        $body->expects(self::atLeastOnce())
            ->method('getSize')
            ->willReturn(0);
        $expectedResponse = $this->createMock(ResponseInterface::class);
        $expectedResponse->expects(self::never())
            ->method('withBody');
        $expectedResponse->expects(self::atLeastOnce())
            ->method('getBody')
            ->willReturn($body);

        $middleware = new RemoveBodyFromHeadResponsesMiddleware($factory);
        $response = $middleware(
            $request,
            function () use ($expectedResponse): ResponseInterface {
                return $expectedResponse;
            },
        );
        self::assertSame($expectedResponse, $response);
    }

    public function testNonEmptyHeadResponseIsReplaced(): void
    {
        $expectedBody = $this->createMock(StreamInterface::class);
        $factory = $this->createMock(StreamFactoryInterface::class);
        $factory->expects(self::once())
            ->method('createStream')
            ->willReturn($expectedBody);

        $request = $this->createMock(ServerRequestInterface::class);
        $request->expects(self::atLeastOnce())
            ->method('getMethod')
            ->willReturn('HEAD');

        $expectedResponse = $this->createMock(ResponseInterface::class);

        $body = $this->createMock(StreamInterface::class);
        $body->expects(self::atLeastOnce())
            ->method('getSize')
            ->willReturn(1);
        $initialResponse = $this->createMock(ResponseInterface::class);
        $initialResponse->expects(self::once())
            ->method('withBody')
            ->with($expectedBody)
            ->willReturn($expectedResponse);
        $initialResponse->expects(self::atLeastOnce())
            ->method('getBody')
            ->willReturn($body);

        $middleware = new RemoveBodyFromHeadResponsesMiddleware($factory);
        $response = $middleware(
            $request,
            function () use ($initialResponse): ResponseInterface {
                return $initialResponse;
            },
        );
        self::assertSame($expectedResponse, $response);
    }

    public function testHeadResponseWithUnknownSizeIsReplaced(): void
    {
        $expectedBody = $this->createMock(StreamInterface::class);
        $factory = $this->createMock(StreamFactoryInterface::class);
        $factory->expects(self::once())
            ->method('createStream')
            ->willReturn($expectedBody);

        $request = $this->createMock(ServerRequestInterface::class);
        $request->expects(self::atLeastOnce())
            ->method('getMethod')
            ->willReturn('HEAD');

        $expectedResponse = $this->createMock(ResponseInterface::class);

        $body = $this->createMock(StreamInterface::class);
        $body->expects(self::atLeastOnce())
            ->method('getSize')
            ->willReturn(null);
        $initialResponse = $this->createMock(ResponseInterface::class);
        $initialResponse->expects(self::once())
            ->method('withBody')
            ->with($expectedBody)
            ->willReturn($expectedResponse);
        $initialResponse->expects(self::atLeastOnce())
            ->method('getBody')
            ->willReturn($body);

        $middleware = new RemoveBodyFromHeadResponsesMiddleware($factory);
        $response = $middleware(
            $request,
            function () use ($initialResponse): ResponseInterface {
                return $initialResponse;
            },
        );
        self::assertSame($expectedResponse, $response);
    }
}
