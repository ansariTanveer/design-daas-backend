<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpResponse\HttpFileResponseBuilder;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\ServerRequest;
use Http\Factory\Guzzle\ResponseFactory;
use Psr\Http\Message\StreamInterface;

final class HttpFileResponseBuilderRangeTest extends TestCase
{
    private ResponseFactory $responseFactory;

    private ServerRequest $request;

    private StreamInterface $body;

    protected function setUp(): void
    {
        parent::setUp();

        $this->responseFactory = new ResponseFactory();
        $this->request = new ServerRequest('GET', 'http://www.example.com/some.file');
        $this->body = $this->createMock(StreamInterface::class);
    }

    public function testDefaultAcceptRangesSetIfSizeNotSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertSame(
            'none',
            $response->getHeaderLine('Accept-Ranges'),
        );
    }

    public function testCorrectAcceptRangesSetIfSizeSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(
            'bytes',
            $response->getHeaderLine('Accept-Ranges'),
        );
    }

    public function testRequestMalformedRangeHeaderReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'malformed-range-header',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestInvalidRangeUnitReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'some-unit=some-value',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestMultipleRangesReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=5-10,-3',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestMalformedRangeSpecificationReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=malformed-range',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestRangeEndBeforeStartReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=20-10',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestRangeAfterEndOfFileReturns416(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=10-50',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(416, $response->getStatusCode());
    }

    public function testRequestClosedRangeIsReturnedCorrectly(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=10-19',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(206, $response->getStatusCode());
        self::assertSame('bytes 10-19/42', $response->getHeaderLine('Content-Range'));
        self::assertSame(10, (int)$response->getHeaderLine('Content-Length'));
    }

    public function testRequestOpenRangeIsReturnedCorrectly(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=10-',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(206, $response->getStatusCode());
        self::assertSame('bytes 10-41/42', $response->getHeaderLine('Content-Range'));
        self::assertSame(32, (int)$response->getHeaderLine('Content-Length'));
    }

    public function testRequestSuffixRangeIsReturnedCorrectly(): void
    {
        $this->request = $this->request->withHeader(
            'Range',
            'bytes=-10',
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize(42);

        $response = $builder->build();

        self::assertSame(206, $response->getStatusCode());
        self::assertSame('bytes 32-41/42', $response->getHeaderLine('Content-Range'));
        self::assertSame(10, (int)$response->getHeaderLine('Content-Length'));
    }
}
