<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpResponse\HttpFileResponseBuilder;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\ServerRequest;
use Http\Factory\Guzzle\ResponseFactory;
use LogicException;
use Psr\Http\Message\StreamInterface;

final class HttpFileResponseBuilderBasicTest extends TestCase
{
    private ResponseFactory $responseFactory;

    private ServerRequest $request;

    private StreamInterface $body;

    protected function setUp(): void
    {
        parent::setUp();

        $this->responseFactory = new ResponseFactory();
        $this->request = new ServerRequest('GET', 'http://www.example.com/some.file');
        $this->body = $this->createMock(StreamInterface::class);
    }

    public function testBodyIsReturnedCorrectly(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertSame(
            $this->body,
            $response->getBody(),
        );
    }

    public function testContentLengthNotSetIfSizeNotSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertFalse($response->hasHeader('Content-Length'));
    }

    public function testCorrectContentLengthSetIfSizeSpecified(): void
    {
        $expectedSize = 42;

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withSize($expectedSize);

        $response = $builder->build();

        self::assertSame(
            $expectedSize,
            (int)$response->getHeaderLine('Content-Length'),
        );
    }

    public function testDefaultContentTypeSetIfMimeNotSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertSame(
            'application/octet-stream',
            $response->getHeaderLine('Content-Type'),
        );
    }

    public function testCorrectContentTypeSetIfMimeSpecified(): void
    {
        $expectedMime = 'something/that-does-not-make-sense';

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withMime($expectedMime);

        $response = $builder->build();

        self::assertSame(
            $expectedMime,
            $response->getHeaderLine('Content-Type'),
        );
    }

    public function testETagNotSetIfNotSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertFalse($response->hasHeader('ETag'));
    }

    public function testCorrectETagSetIfSpecified(): void
    {
        $expectedETag = 'some-etag-that-does-not-matter';

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withETag($expectedETag);

        $response = $builder->build();

        self::assertSame(
            '"' . $expectedETag . '"',
            $response->getHeaderLine('ETag'),
        );
    }

    public function testLastModifiedNotSetIfModificationTimeNotSpecified(): void
    {
        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);

        $response = $builder->build();

        self::assertFalse($response->hasHeader('Last-Modified'));
    }

    public function testCorrectLastModifiedSetIfModificationTimeSpecified(): void
    {
        $expectedModificationTime = 1234567;

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withModificationTime($expectedModificationTime);

        $response = $builder->build();

        self::assertSame(
            $expectedModificationTime,
            strtotime($response->getHeaderLine('Last-Modified')),
        );
    }

    public function testInvalidRequestMethodThrowsException(): void
    {
        try {
            $request = new ServerRequest('OPTIONS', '/');
            new HttpFileResponseBuilder($this->responseFactory, $request, $this->body);
            self::fail('Expected exception not thrown');
        } catch (LogicException $e) {
            self::assertStringContainsString('OPTIONS', $e->getMessage());
        }
    }
}
