<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpResponse\HttpFileResponseFactory;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\ServerRequest;
use Http\Factory\Guzzle\ResponseFactory;
use Http\Factory\Guzzle\StreamFactory;
use LogicException;

final class HttpFileResponseFactoryFromFileTest extends TestCase
{
    private HttpFileResponseFactory $factory;

    private ServerRequest $request;

    protected function setUp(): void
    {
        parent::setUp();

        $this->factory = new HttpFileResponseFactory(new ResponseFactory(), new StreamFactory());
        $this->request = new ServerRequest('GET', 'http://www.example.com/some.file');
    }

    public function testJsonMimeType(): void
    {
        $response = $this->factory->buildFromFile(
            $this->request,
            self::TEST_CONFIG_DIR . '/HttpFileResponse/simple.json',
        );

        self::assertStringStartsWith(
            'application/json',
            $response->getHeaderLine('Content-Type'),
        );
    }

    public function testPngMimeType(): void
    {
        $response = $this->factory->buildFromFile(
            $this->request,
            self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png',
        );

        self::assertStringStartsWith(
            'image/png',
            $response->getHeaderLine('Content-Type'),
        );
    }

    public function testManualMimeTypeIsUsed(): void
    {
        $mime = 'something/that-does-not-make-sense';

        $response = $this->factory->buildFromFile(
            $this->request,
            self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png',
            $mime,
        );

        self::assertSame(
            $mime,
            $response->getHeaderLine('Content-Type'),
        );
    }

    public function testCorrectBodyContentsAreReturned(): void
    {
        $filename = self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png';

        $response = $this->factory->buildFromFile(
            $this->request,
            $filename,
        );

        $expectedContents = file_get_contents($filename);
        self::assertNotFalse($expectedContents);
        self::assertNotEmpty($expectedContents);

        self::assertSame(
            $expectedContents,
            (string)$response->getBody(),
        );
    }

    public function testCorrectFileSizeIsReturned(): void
    {
        $filename = self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png';

        $response = $this->factory->buildFromFile(
            $this->request,
            $filename,
        );

        $expectedSize = filesize($filename);
        self::assertNotFalse($expectedSize);
        self::assertGreaterThan(0, $expectedSize);

        self::assertSame(
            $expectedSize,
            (int)$response->getHeaderLine('Content-Length'),
        );
    }

    public function testCorrectModificationTimeIsReturned(): void
    {
        $filename = self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png';

        $response = $this->factory->buildFromFile(
            $this->request,
            $filename,
        );

        $expectedModificationTime = filemtime($filename);
        self::assertNotFalse($expectedModificationTime);
        self::assertGreaterThan(0, $expectedModificationTime);

        self::assertSame(
            $expectedModificationTime,
            strtotime($response->getHeaderLine('Last-Modified')),
        );
    }

    public function testReasonableETagIsReturned(): void
    {
        $response = $this->factory->buildFromFile(
            $this->request,
            self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png',
        );

        $eTag = trim($response->getHeaderLine('ETag'), '"');

        self::assertNotEmpty($eTag);
        self::assertMatchesRegularExpression('=^[0-9a-zA-Z\\.\\-\\_\\@]{32,}$=', $eTag);
    }

    public function testInvalidFileThrowsException(): void
    {
        try {
            $this->factory->buildFromFile(
                $this->request,
                self::TEST_CONFIG_DIR . '/HttpFileResponse/does-not-exist.file',
            );
            self::fail('Expected exception not thrown');
        } catch (LogicException $e) {
            self::assertStringContainsString('does-not-exist.file', $e->getMessage());
        }
    }
}
