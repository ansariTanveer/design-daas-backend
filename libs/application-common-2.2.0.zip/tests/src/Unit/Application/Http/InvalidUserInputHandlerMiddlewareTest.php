<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Http;

use Application\Common\Application\Http\InvalidUserInputEvent;
use Application\Common\Application\Http\InvalidUserInputException;
use Application\Common\Application\Http\InvalidUserInputHandlerMiddleware;
use Application\Test\TestCase;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final class InvalidUserInputHandlerMiddlewareTest extends TestCase
{
    public function testRequestAndResponseArePassedThrough(): void
    {
        $responseFactory = $this->createMock(ResponseFactoryInterface::class);
        $eventDispatcher = $this->createMock(PsrEventDispatcherInterface::class);
        $middleware = new InvalidUserInputHandlerMiddleware($responseFactory, $eventDispatcher);

        $expectedRequest = $this->createMock(ServerRequestInterface::class);
        $expectedResponse = $this->createMock(ResponseInterface::class);
        $next = function (
            ServerRequestInterface $actualRequest
        ) use (
            $expectedRequest,
            $expectedResponse
        ): ResponseInterface {
            self::assertSame($expectedRequest, $actualRequest);
            return $expectedResponse;
        };

        $actualResponse = $middleware($expectedRequest, $next);

        self::assertSame($expectedResponse, $actualResponse);
    }

    public function testThrownExceptionIsPassedOnWithTheEvent(): void
    {
        $responseFactory = $this->createMock(ResponseFactoryInterface::class);
        $eventDispatcher = $this->createMock(PsrEventDispatcherInterface::class);
        $middleware = new InvalidUserInputHandlerMiddleware($responseFactory, $eventDispatcher);

        $expectedException = $this->createMock(InvalidUserInputException::class);
        $eventDispatcher
            ->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(
                function (InvalidUserInputEvent $event) use ($expectedException): void {
                    self::assertSame($expectedException, $event->exception());
                },
            );

        $next = function () use ($expectedException): ResponseInterface {
            throw $expectedException;
        };
        $middleware($this->createMock(ServerRequestInterface::class), $next);
    }

    public function testResponseFromTheEventIsReturned(): void
    {
        $responseFactory = $this->createMock(ResponseFactoryInterface::class);
        $eventDispatcher = $this->createMock(PsrEventDispatcherInterface::class);
        $middleware = new InvalidUserInputHandlerMiddleware($responseFactory, $eventDispatcher);

        $expectedResponse = $this->createMock(ResponseInterface::class);
        $eventDispatcher
            ->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(
                function (InvalidUserInputEvent $event) use ($expectedResponse): void {
                    $event->replaceResponse($expectedResponse);
                },
            );

        $next = function (): ResponseInterface {
            throw $this->createMock(InvalidUserInputException::class);
        };
        $actualResponse = $middleware($this->createMock(ServerRequestInterface::class), $next);

        self::assertSame($expectedResponse, $actualResponse);
    }
}
