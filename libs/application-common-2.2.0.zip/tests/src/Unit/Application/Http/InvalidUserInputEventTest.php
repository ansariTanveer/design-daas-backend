<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Http;

use Application\Common\Application\Http\InvalidUserInputEvent;
use Application\Common\Application\Http\InvalidUserInputException;
use Application\Test\TestCase;
use Psr\Http\Message\ResponseInterface;

final class InvalidUserInputEventTest extends TestCase
{
    public function testCorrectExceptionIsReturned(): void
    {
        $exception = $this->createMock(InvalidUserInputException::class);
        $defaultResponse = $this->createMock(ResponseInterface::class);

        $event = new InvalidUserInputEvent($exception, $defaultResponse);

        self::assertSame($exception, $event->exception());
    }

    public function testDefaultResponseIsReturned(): void
    {
        $exception = $this->createMock(InvalidUserInputException::class);
        $defaultResponse = $this->createMock(ResponseInterface::class);

        $event = new InvalidUserInputEvent($exception, $defaultResponse);

        self::assertSame($defaultResponse, $event->response());
    }

    public function testReplacementResponseIsReturned(): void
    {
        $exception = $this->createMock(InvalidUserInputException::class);
        $defaultResponse = $this->createMock(ResponseInterface::class);
        $replacementResponse = $this->createMock(ResponseInterface::class);

        $event = new InvalidUserInputEvent($exception, $defaultResponse);
        $event->replaceResponse($replacementResponse);

        self::assertNotSame($defaultResponse, $event->response());

        self::assertSame($replacementResponse, $event->response());
    }
}
