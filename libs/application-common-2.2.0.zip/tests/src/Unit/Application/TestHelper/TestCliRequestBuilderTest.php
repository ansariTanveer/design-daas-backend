<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\TestHelper;

use Application\Common\Application\Cli\CliApplicationInterface;
use Application\Common\Application\TestHelper\TestCliRequestBuilder;
use Application\Test\TestCase;
use Throwable;

final class TestCliRequestBuilderTest extends TestCase
{
    public function testArgvVariableIsFilledCorrectly(): void
    {
        $builder = (new TestCliRequestBuilder())
            ->argv(['arg1', 'arg2']);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server): void {
                    self::assertIsArray($server['argv']);
                    self::assertNotEmpty(array_shift($server['argv']));
                    self::assertSame('arg1', array_shift($server['argv']));
                    self::assertSame('arg2', array_shift($server['argv']));
                    self::assertEmpty($server['argv']);
                },
            );

        $builder->execute($application);
    }

    public function testServerVariableIsFilledCorrectly(): void
    {
        $builder = (new TestCliRequestBuilder())
            ->argv(['originalArgv'])
            ->additionalEnv(['value1' => 'env1', 'value2' => 'env2'])
            ->additionalServer(['value2' => 'server2', 'argv' => 'serverArgv']);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server): void {
                    self::assertIsArray($server['argv']);
                    self::assertNotEmpty(array_shift($server['argv']));
                    self::assertSame('originalArgv', array_shift($server['argv']));
                    self::assertEmpty($server['argv']);
                    self::assertSame('env1', $server['value1']);
                    self::assertSame('server2', $server['value2']);
                },
            );

        $builder->execute($application);
    }

    public function testUnspecifiedStdInIsPassedAsEmpty(): void
    {
        $builder = (new TestCliRequestBuilder())
            ->argv([]);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server): void {
                    self::assertIsResource($stdIn);
                    self::assertSame('', (string)stream_get_contents($stdIn));
                },
            );

        $builder->execute($application);
    }

    public function testStdInIsPassedCorrectly(): void
    {
        $expectedStdInContent = 'StdIn Content';

        $builder = (new TestCliRequestBuilder())
            ->argv([])
            ->stdIn($expectedStdInContent);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server) use ($expectedStdInContent): void {
                    self::assertIsResource($stdIn);
                    self::assertSame($expectedStdInContent, (string)stream_get_contents($stdIn));
                },
            );

        $builder->execute($application);
    }

    public function testExitCodeIsPassedCorrectly(): void
    {
        $expectedExitCode = 42;

        $builder = (new TestCliRequestBuilder())
            ->argv([]);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($expectedExitCode);

        $response = $builder->execute($application);

        self::assertSame($expectedExitCode, $response->exitCode());
    }

    public function testStdOutIsPassedCorrectly(): void
    {
        $expectedStdOut = 'StdOut Content';

        $builder = (new TestCliRequestBuilder())
            ->argv([]);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server) use ($expectedStdOut): void {
                    self::assertIsResource($stdOut);
                    fwrite($stdOut, $expectedStdOut);
                },
            );

        $response = $builder->execute($application);

        self::assertSame($expectedStdOut, $response->stdOut());
    }

    public function testStdErrIsPassedCorrectly(): void
    {
        $expectedStdErr = 'StdErr Content';

        $builder = (new TestCliRequestBuilder())
            ->argv([]);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($stdIn, $stdOut, $stdErr, $server) use ($expectedStdErr): void {
                    self::assertIsResource($stdErr);
                    fwrite($stdErr, $expectedStdErr);
                },
            );

        $response = $builder->execute($application);

        self::assertSame($expectedStdErr, $response->stdErr());
    }

    public function testExpectedExitCodeDoesNotThrowException(): void
    {
        $expectedExitCode = 42;

        $builder = (new TestCliRequestBuilder())
            ->argv([])
            ->expectExitCode($expectedExitCode);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($expectedExitCode);

        $builder->execute($application);
    }

    public function testUnexpectedExitCodeDoesThrowsException(): void
    {
        $expectedExitCode = 42;
        $actualExitCode = 43;

        $builder = (new TestCliRequestBuilder())
            ->argv([])
            ->expectExitCode($expectedExitCode);

        $application = $this->createMock(CliApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($actualExitCode);

        try {
            $builder->execute($application);
            self::fail('Expected exception not thrown');
        } catch (Throwable $e) {
            self::assertStringContainsString((string)$expectedExitCode, $e->getMessage());
        }
    }
}
