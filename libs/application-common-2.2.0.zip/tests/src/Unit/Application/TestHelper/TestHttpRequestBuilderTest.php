<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\TestHelper;

use Application\Common\Application\Http\HttpApplicationInterface;
use Application\Common\Application\TestHelper\TestHttpRequestBuilder;
use Application\Common\Application\TestHelper\TestHttpRequestFile;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Response;
use Throwable;

final class TestHttpRequestBuilderTest extends TestCase
{
    public function testServerVariableIsFilledCorrectly(): void
    {
        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalEnv(['value1' => 'env1', 'value2' => 'env2'])
            ->additionalServer(['value2' => 'server2', 'PHP_SELF' => 'serverPhpSelf']);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream): void {
                    self::assertNotSame('serverPhpSelf', $server['PHP_SELF']);
                    self::assertSame('env1', $server['value1']);
                    self::assertSame('server2', $server['value2']);
                },
            );

        $builder->execute($application);
    }

    public function testGetVariableIsPassedCorrectly(): void
    {
        $expectedGet = ['hello' => 'world', 'additional' => 'value'];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalGet($expectedGet);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedGet): void {
                    self::assertSame($expectedGet, $get);
                },
            );

        $builder->execute($application);
    }

    public function testPostVariableIsPassedCorrectly(): void
    {
        $expectedPost = ['hello' => 'world', 'additional' => 'value'];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalPost($expectedPost);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedPost): void {
                    self::assertSame($expectedPost, $post);
                },
            );

        $builder->execute($application);
    }

    public function testCookieVariableIsPassedCorrectly(): void
    {
        $expectedCookie = ['hello' => 'world', 'additional' => 'value'];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalCookie($expectedCookie);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedCookie): void {
                    self::assertSame($expectedCookie, $cookie);
                },
            );

        $builder->execute($application);
    }

    public function testSimpleFilesVariableIsPassedCorrectly(): void
    {
        $filePath1 = self::TEST_TMP_DIR . '/file_path_1';
        file_put_contents($filePath1, 'File_1_Content');
        $filePath2 = self::TEST_TMP_DIR . '/file_path_2';
        file_put_contents($filePath2, 'File_2_Content_42');

        $expectedFiles = [
            'file1' => [
                'name' => 'file_name_1',
                'type' => 'file_type_1',
                'tmp_name' => $filePath1,
                'error' => UPLOAD_ERR_OK,
                'size' => (int)filesize($filePath1),
            ],
            'file2' => [
                'name' => 'file_name_2',
                'type' => 'file_type_2',
                'tmp_name' => $filePath2,
                'error' => UPLOAD_ERR_CANT_WRITE,
                'size' => (int)filesize($filePath2),
            ],
        ];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalFile(
                (new TestHttpRequestFile('file1', $expectedFiles['file1']['tmp_name']))
                    ->withName($expectedFiles['file1']['name'])
                    ->withType($expectedFiles['file1']['type'])
                    ->withUploadResult($expectedFiles['file1']['error']),
            )
            ->additionalFile(
                (new TestHttpRequestFile('file2', $expectedFiles['file2']['tmp_name']))
                    ->withName($expectedFiles['file2']['name'])
                    ->withType($expectedFiles['file2']['type'])
                    ->withUploadResult($expectedFiles['file2']['error']),
            );

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedFiles): void {
                    self::assertSame($expectedFiles, $files);
                },
            );

        $builder->execute($application);
    }

    public function testComplexFilesVariableIsPassedCorrectly(): void
    {
        $filePath1 = self::TEST_TMP_DIR . '/file_path_1';
        file_put_contents($filePath1, 'File_1_Content');
        $filePath2 = self::TEST_TMP_DIR . '/file_path_2';
        file_put_contents($filePath2, 'File_2_Content_42');
        $filePath3 = self::TEST_TMP_DIR . '/file_path_3';
        file_put_contents($filePath3, 'File_3_Content_1337');
        $filePath4 = self::TEST_TMP_DIR . '/file_path_4';
        file_put_contents($filePath4, 'File_4_Content_123');

        $expectedFiles = [
            'file1' => [
                [
                    'name' => 'file_name_1',
                    'type' => 'file_type_1',
                    'tmp_name' => $filePath1,
                    'error' => UPLOAD_ERR_OK,
                    'size' => (int)filesize($filePath1),
                ],
                [
                    'name' => 'file_name_3',
                    'type' => 'file_type_3',
                    'tmp_name' => $filePath3,
                    'error' => UPLOAD_ERR_EXTENSION,
                    'size' => (int)filesize($filePath3),
                ],
                [
                    'name' => 'file_name_4',
                    'type' => 'file_type_4',
                    'tmp_name' => $filePath4,
                    'error' => UPLOAD_ERR_INI_SIZE,
                    'size' => (int)filesize($filePath4),
                ],
            ],
            'file2' => [
                'name' => 'file_name_2',
                'type' => 'file_type_2',
                'tmp_name' => $filePath2,
                'error' => UPLOAD_ERR_CANT_WRITE,
                'size' => (int)filesize($filePath2),
            ],
        ];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalFile(
                (new TestHttpRequestFile('file1', $expectedFiles['file1'][0]['tmp_name']))
                    ->withName($expectedFiles['file1'][0]['name'])
                    ->withType($expectedFiles['file1'][0]['type'])
                    ->withUploadResult($expectedFiles['file1'][0]['error']),
            )
            ->additionalFile(
                (new TestHttpRequestFile('file2', $expectedFiles['file2']['tmp_name']))
                    ->withName($expectedFiles['file2']['name'])
                    ->withType($expectedFiles['file2']['type'])
                    ->withUploadResult($expectedFiles['file2']['error']),
            )
            ->additionalFile(
                (new TestHttpRequestFile('file1', $expectedFiles['file1'][1]['tmp_name']))
                    ->withName($expectedFiles['file1'][1]['name'])
                    ->withType($expectedFiles['file1'][1]['type'])
                    ->withUploadResult($expectedFiles['file1'][1]['error']),
            )
            ->additionalFile(
                (new TestHttpRequestFile('file1', $expectedFiles['file1'][2]['tmp_name']))
                    ->withName($expectedFiles['file1'][2]['name'])
                    ->withType($expectedFiles['file1'][2]['type'])
                    ->withUploadResult($expectedFiles['file1'][2]['error']),
            );

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedFiles): void {
                    self::assertSame($expectedFiles, $files);
                },
            );

        $builder->execute($application);
    }

    public function testSimpleFilesVariableEntryHasCorrectDefaultValues(): void
    {
        $filePath1 = self::TEST_TMP_DIR . '/file_path_1';
        file_put_contents($filePath1, 'File_1_Content');

        $expectedFiles = [
            'file1' => [
                'name' => 'file_path_1', // expected to be filled in automatically
                'type' => 'application/octet-stream', // expected to be filled in automatically
                'tmp_name' => $filePath1,
                'error' => UPLOAD_ERR_OK, // expected to be filled in automatically
                'size' => (int)filesize($filePath1),
            ],
        ];

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalFile(new TestHttpRequestFile('file1', $expectedFiles['file1']['tmp_name']));

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedFiles): void {
                    self::assertSame($expectedFiles, $files);
                },
            );

        $builder->execute($application);
    }

    public function testRequestMethodIsPassedCorrectly(): void
    {
        $expectedRequestMethod = 'OPTIONS';

        $builder = (new TestHttpRequestBuilder())
            ->method($expectedRequestMethod)
            ->uri('/');

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedRequestMethod): void {
                    self::assertSame($expectedRequestMethod, $server['REQUEST_METHOD']);
                },
            );

        $builder->execute($application);
    }

    public function testRequestUriIsPassedCorrectly(): void
    {
        $expectedRequestUri = '/some/request/uri';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri($expectedRequestUri);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedRequestUri): void {
                    self::assertStringEndsWith($expectedRequestUri, $server['REQUEST_URI']);
                },
            );

        $builder->execute($application);
    }

    public function testContentTypeIsPassedCorrectly(): void
    {
        $expectedContentType = 'some/content-type';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->contentType($expectedContentType);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedContentType): void {
                    self::assertSame($expectedContentType, $server['CONTENT_TYPE']);
                },
            );

        $builder->execute($application);
    }

    public function testRequestBodyIsPassedCorrectly(): void
    {
        $expectedBody = 'Body Content';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->body($expectedBody);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server, $inputStream) use ($expectedBody): void {
                    self::assertIsResource($inputStream);
                    self::assertSame($expectedBody, (string)stream_get_contents($inputStream));
                },
            );

        $builder->execute($application);
    }

    public function testTooLargeRequestFlagIsNotSetByDefault(): void
    {
        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/');

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::never())
            ->method('flagTooLargeRequestBody');

        $builder->execute($application);
    }

    public function testTooLargeRequestFlagIsPassedCorrectly(): void
    {
        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->requestTooLarge();

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('flagTooLargeRequestBody');

        $builder->execute($application);
    }

    public function testExpectedResponseCodeDoesNotThrowException(): void
    {
        $expectedResponse = new Response(142);

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectResponseCode($expectedResponse->getStatusCode());

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($expectedResponse);

        $builder->execute($application);
    }

    public function testUnexpectedResponseCodeDoesThrowException(): void
    {
        $expectedResponse = new Response(142);
        $actualResponse = new Response(200);

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectResponseCode($expectedResponse->getStatusCode());

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($actualResponse);

        try {
            $builder->execute($application);
            self::fail('Expected exception not thrown');
        } catch (Throwable $e) {
            self::assertStringContainsString(
                (string)$expectedResponse->getStatusCode(),
                $e->getMessage(),
            );
        }
    }

    public function testExpectedSimpleResponseContentTypeDoesNotThrowException(): void
    {
        $expectedResponse = (new Response(200))
            ->withHeader('Content-Type', 'some/content-type');

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectContentType($expectedResponse->getHeaderLine('Content-Type'));

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($expectedResponse);

        $builder->execute($application);
    }

    public function testUnexpectedSimpleResponseContentTypeDoesThrowException(): void
    {
        $expectedResponse = (new Response(200))
            ->withHeader('Content-Type', 'some/content-type');
        $actualResponse = (new Response(200))
            ->withHeader('Content-Type', 'another/content-type');

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectContentType($expectedResponse->getHeaderLine('Content-Type'));

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($actualResponse);

        try {
            $builder->execute($application);
            self::fail('Expected exception not thrown');
        } catch (Throwable $e) {
            self::assertStringContainsString(
                (string)json_encode($actualResponse->getHeaderLine('Content-Type')),
                $e->getMessage(),
            );
        }
    }

    public function testExpectedComplexResponseContentTypeDoesNotThrowException(): void
    {
        $expectedResponse = (new Response(200))
            ->withHeader('Content-Type', 'some/content-type');
        $actualResponse = (new Response(200))
            ->withHeader('Content-Type', 'some/content-type; with-extra=42');

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectContentType($expectedResponse->getHeaderLine('Content-Type'));

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($actualResponse);

        $builder->execute($application);
    }

    public function testUnexpectedComplexResponseContentTypeDoesThrowException(): void
    {
        $expectedResponse = (new Response(200))
            ->withHeader('Content-Type', 'some/content-type');
        $actualResponse = (new Response(200))
            ->withHeader('Content-Type', 'another/content-type; with-extra=42');

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->expectContentType($expectedResponse->getHeaderLine('Content-Type'));

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('execute')
            ->willReturn($actualResponse);

        try {
            $builder->execute($application);
            self::fail('Expected exception not thrown');
        } catch (Throwable $e) {
            self::assertStringContainsString(
                (string)json_encode($actualResponse->getHeaderLine('Content-Type')),
                $e->getMessage(),
            );
        }
    }

    public function testAdditionalHeaderIsAddedToServerVariable(): void
    {
        $inputHeader = 'Test-Header';
        $expectedHeader = 'HTTP_TEST_HEADER';
        $expectedValue = 'Test-Value';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalHeaders([$inputHeader => $expectedValue]);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function ($get, $post, $cookie, $files, $server) use ($expectedHeader, $expectedValue): void {
                    self::assertSame($expectedValue, $server[$expectedHeader]);
                },
            );

        $builder->execute($application);
    }

    public function testAdditionalHeaderWithMultipleValuesIsConvertedToString(): void
    {
        $inputHeader = 'Test-Header';
        $expectedHeader = 'HTTP_TEST_HEADER';
        $expectedValue1 = 'Test-Value 1';
        $expectedValue2 = 'Test-Value 2';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalHeaders([$inputHeader => [$expectedValue1, $expectedValue2]]);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function (
                    $get,
                    $post,
                    $cookie,
                    $files,
                    $server
                ) use (
                    $expectedHeader,
                    $expectedValue1,
                    $expectedValue2
                ): void {
                    self::assertSame(
                        [$expectedValue1, $expectedValue2],
                        array_map('trim', explode(',', $server[$expectedHeader])),
                    );
                },
            );

        $builder->execute($application);
    }

    public function testDuplicateAdditionalHeaderIsAppendedToExistingValue(): void
    {
        $inputHeader = 'Test-Header';
        $expectedHeader = 'HTTP_TEST_HEADER';
        $expectedValue1 = 'Test-Value 1';
        $expectedValue2 = 'Test-Value 2';

        $builder = (new TestHttpRequestBuilder())
            ->method('GET')
            ->uri('/')
            ->additionalServer([$expectedHeader => $expectedValue1])
            ->additionalHeaders([$inputHeader => $expectedValue2]);

        $application = $this->createMock(HttpApplicationInterface::class);
        $application->expects(self::once())
            ->method('setRuntimeEnvironment')
            ->willReturnCallback(
                function (
                    $get,
                    $post,
                    $cookie,
                    $files,
                    $server
                ) use (
                    $expectedHeader,
                    $expectedValue1,
                    $expectedValue2
                ): void {
                    self::assertSame(
                        [$expectedValue1, $expectedValue2],
                        array_map('trim', explode(',', $server[$expectedHeader])),
                    );
                },
            );

        $builder->execute($application);
    }
}
