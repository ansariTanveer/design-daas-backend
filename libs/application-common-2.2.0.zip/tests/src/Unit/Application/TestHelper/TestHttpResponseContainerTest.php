<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\TestHelper;

use Application\Common\Application\TestHelper\TestHttpResponseContainer;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Response;
use Http\Factory\Guzzle\StreamFactory;

final class TestHttpResponseContainerTest extends TestCase
{
    public function testCorrectResponseIsReturned(): void
    {
        $response = new Response(200);

        $container = new TestHttpResponseContainer($response);

        self::assertSame($response, $container->response());
    }

    public function testCorrectStatusCodeIsReturned(): void
    {
        $expectedStatusCode = 242;
        $response = new Response($expectedStatusCode);

        $container = new TestHttpResponseContainer($response);

        self::assertSame($expectedStatusCode, $container->statusCode());
    }

    public function testCorrectContentTypeIsReturned(): void
    {
        $expectedContentType = 'some/content-type';
        $response = (new Response(200))
            ->withHeader('Content-Type', $expectedContentType);

        $container = new TestHttpResponseContainer($response);

        self::assertSame($expectedContentType, $container->contentType());
    }

    public function testCorrectBodyIsReturned(): void
    {
        $expectedBody = 'Body Content';
        $response = (new Response(200))
            ->withBody((new StreamFactory())->createStream($expectedBody));

        $container = new TestHttpResponseContainer($response);

        self::assertSame($expectedBody, $container->bodyAsString());
    }

    public function testFormattedStringContainsStatusCode(): void
    {
        $expectedStatusCode = 242;
        $response = new Response($expectedStatusCode);

        $container = new TestHttpResponseContainer($response);

        self::assertStringContainsString((string)$expectedStatusCode, $container->formatAsString());
    }

    public function testFormattedStringContainsHeaders(): void
    {
        $expectedHeader = 'Some Header Value';
        $response = (new Response(200))
            ->withHeader('Some-Header', $expectedHeader);

        $container = new TestHttpResponseContainer($response);

        self::assertStringContainsString($expectedHeader, $container->formatAsString());
    }

    public function testFormattedStringContainsBody(): void
    {
        $expectedBody = 'Body Content';
        $response = (new Response(200))
            ->withBody((new StreamFactory())->createStream($expectedBody));

        $container = new TestHttpResponseContainer($response);

        self::assertStringContainsString($expectedBody, $container->formatAsString());
    }

    public function testCastingToStringIsSameAsFormattedString(): void
    {
        $response = new Response(200);

        $container = new TestHttpResponseContainer($response);

        self::assertSame(
            $container->formatAsString(),
            (string)$container,
        );
    }
}
