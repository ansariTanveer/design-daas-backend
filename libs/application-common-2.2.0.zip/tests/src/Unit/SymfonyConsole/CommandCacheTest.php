<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyConsole;

use Application\Common\SymfonyConsole\CommandCache;
use Application\Common\SymfonyConsole\CommandCollector;
use Application\Common\SymfonyConsole\CommandCollectorInterface;
use Application\Test\Assets\SymfonyConsole\CommandCache\WorkingCommands;
use Application\Test\TestCase;
use Consolidation\AnnotatedCommand\AnnotatedCommand;
use Psr\Container\ContainerInterface;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\NullOutput;

final class CommandCacheTest extends TestCase
{
    private string $cacheFile;

    private string $commandPath;

    private string $commandNamespace;

    private string $commandPattern;

    /**
     * @var string[]
     */
    private array $expectedCommandNames;

    protected function setUp(): void
    {
        parent::setUp();
        $this->cacheFile = self::TEST_TMP_DIR . '/console-commands.cache';
        $this->commandPath = self::TEST_SRC_DIR . '/SymfonyConsole/CommandCache';
        $this->commandNamespace = 'Application\\Test\\Assets\\SymfonyConsole\\CommandCache';
        $this->commandPattern = '*Commands.php';
        $this->expectedCommandNames = [
            'basic:command',
            'test1:some-command',
            'test1:do-something',
            'test2:some-command',
            'working:correctly',
        ];
        sort($this->expectedCommandNames);
    }

    /**
     * @param AnnotatedCommand[] $commands
     * @return string[]
     */
    private static function convertCommandList(array $commands): array
    {
        $commandNames = array_map(
            function (AnnotatedCommand $command): string {
                self::assertNotNull($command->getName());
                return $command->getName();
            },
            $commands,
        );
        sort($commandNames);
        return $commandNames;
    }

    /**
     * @param AnnotatedCommand[] $commands
     * @return AnnotatedCommand
     */
    private static function findWorkingCommand(array $commands): AnnotatedCommand
    {
        $commands = array_filter(
            $commands,
            function (AnnotatedCommand $command): bool {
                return $command->getName() === 'working:correctly';
            },
        );
        self::assertCount(1, $commands);
        assert(count($commands) > 0);
        return array_shift($commands);
    }

    public function testCorrectCommandsArePickedUp(): void
    {
        $collector = new CommandCollector();
        $collector->addSearchPath(
            $this->commandPath,
            $this->commandNamespace,
            $this->commandPattern,
        );
        $cache = new CommandCache($collector, null);

        $containerMock = $this->createMock(ContainerInterface::class);
        $containerMock->expects(self::never())->method('has');
        $containerMock->expects(self::never())->method('get');

        $commands = $cache->loadCommandList($containerMock);

        $actualCommandNames = self::convertCommandList($commands);
        self::assertSame($this->expectedCommandNames, $actualCommandNames);
    }

    public function testCommandsAreCorrectlyCached(): void
    {
        $collector = new CommandCollector();
        $collector->addSearchPath(
            $this->commandPath,
            $this->commandNamespace,
            $this->commandPattern,
        );
        $cache = new CommandCache($collector, $this->cacheFile);
        $cache->buildCache();
        unset($cache);
        unset($collector);

        $collector = $this->createMock(CommandCollectorInterface::class);
        $collector->expects(self::never())->method('collectCommandClassNames');
        $cache = new CommandCache($collector, $this->cacheFile);

        $containerMock = $this->createMock(ContainerInterface::class);
        $containerMock->expects(self::never())->method('has');
        $containerMock->expects(self::never())->method('get');

        $commands = $cache->loadCommandList($containerMock);

        $actualCommandNames = self::convertCommandList($commands);
        self::assertSame($this->expectedCommandNames, $actualCommandNames);
    }

    public function testBuildingCacheWithoutCacheFileDoesNothing(): void
    {
        $collector = $this->createMock(CommandCollectorInterface::class);
        $collector->expects(self::never())->method('collectCommandClassNames');
        $cache = new CommandCache($collector, null);

        $cache->buildCache();

        self::assertFileDoesNotExist($this->cacheFile);
    }

    public function testCommandIsCorrectlyCalled(): void
    {
        $collector = new CommandCollector();
        $collector->addSearchPath(
            $this->commandPath,
            $this->commandNamespace,
            $this->commandPattern,
        );
        $cache = new CommandCache($collector, null);

        $containerMock = $this->createMock(ContainerInterface::class);
        $containerMock->expects(self::never())->method('has');
        $containerMock->expects(self::once())
            ->method('get')
            ->with(WorkingCommands::class)
            ->willReturn(new WorkingCommands());

        $commands = $cache->loadCommandList($containerMock);
        $command = self::findWorkingCommand($commands);

        $expectedReturn = 42;
        $input = new ArrayInput(['return' => $expectedReturn]);
        $output = new NullOutput();
        $actualReturn = $command->run($input, $output);

        self::assertSame($expectedReturn, $actualReturn);
    }

    public function testCommandClassAndMethodArePresentInAnnotationData(): void
    {
        $collector = new CommandCollector();
        $collector->addSearchPath(
            $this->commandPath,
            $this->commandNamespace,
            $this->commandPattern,
        );
        $cache = new CommandCache($collector, null);

        $containerMock = $this->createMock(ContainerInterface::class);
        $containerMock->expects(self::never())->method('has');
        $containerMock->expects(self::never())->method('get');

        $commands = $cache->loadCommandList($containerMock);

        $workingCommand = self::findWorkingCommand($commands);

        self::assertSame(
            WorkingCommands::class,
            $workingCommand->getAnnotationData()['_commandClass'],
        );
        self::assertSame(
            'correctly',
            $workingCommand->getAnnotationData()['_commandMethod'],
        );
    }
}
