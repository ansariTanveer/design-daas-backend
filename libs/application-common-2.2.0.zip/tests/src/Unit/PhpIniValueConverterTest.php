<?php

declare(strict_types=1);

namespace Application\Test\Unit;

use Application\Common\PhpIniValueConverter;
use Application\Test\TestCase;

final class PhpIniValueConverterTest extends TestCase
{
    public function testShorthandBytesAreReturnedAsIs(): void
    {
        self::assertSame(
            42,
            PhpIniValueConverter::convertShorthandByteValue('42'),
        );
    }

    public function testShorthandKilobytesAreConvertedCorrectly(): void
    {
        self::assertSame(
            43008,
            PhpIniValueConverter::convertShorthandByteValue('42k'),
        );

        self::assertSame(
            43008,
            PhpIniValueConverter::convertShorthandByteValue('42K'),
        );
    }

    public function testShorthandMegabytesAreConvertedCorrectly(): void
    {
        self::assertSame(
            44040192,
            PhpIniValueConverter::convertShorthandByteValue('42m'),
        );

        self::assertSame(
            44040192,
            PhpIniValueConverter::convertShorthandByteValue('42M'),
        );
    }

    public function testShorthandGigabytesAreConvertedCorrectly(): void
    {
        self::assertSame(
            45097156608,
            PhpIniValueConverter::convertShorthandByteValue('42g'),
        );

        self::assertSame(
            45097156608,
            PhpIniValueConverter::convertShorthandByteValue('42G'),
        );
    }
}
