<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM;

use Application\Common\DoctrineORM\ConfigurationCacheEntityListenerResolverInjector;
use Application\Common\DoctrineORM\ConfigurationCacheInterface;
use Application\Test\TestCase;
use Doctrine\ORM\Configuration;
use Doctrine\ORM\Mapping\EntityListenerResolver;

final class ConfigurationCacheEntityListenerResolverInjectorTest extends TestCase
{
    public function testBuildCacheIsCalledOnParent(): void
    {
        $resolver = $this->createMock(EntityListenerResolver::class);
        $resolver
            ->expects(self::never())
            ->method(self::anything());
        $parent = $this->createMock(ConfigurationCacheInterface::class);
        $parent
            ->expects(self::once())
            ->method('buildCache');

        $configurationCache = new ConfigurationCacheEntityListenerResolverInjector($parent, $resolver);

        $configurationCache->buildCache();
    }

    public function testResolverIsInjected(): void
    {
        $resolver = $this->createMock(EntityListenerResolver::class);
        $resolver
            ->expects(self::never())
            ->method(self::anything());
        $configuration = $this->createMock(Configuration::class);
        $configuration
            ->expects(self::once())
            ->method('setEntityListenerResolver')
            ->with($resolver);
        $parent = $this->createMock(ConfigurationCacheInterface::class);
        $parent
            ->expects(self::once())
            ->method('loadConfiguration')
            ->willReturn($configuration);

        $configurationCache = new ConfigurationCacheEntityListenerResolverInjector($parent, $resolver);

        $returnedConfiguration = $configurationCache->loadConfiguration();

        self::assertSame(
            $configuration,
            $returnedConfiguration,
        );
    }
}
