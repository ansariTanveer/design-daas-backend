<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM;

use Application\Common\DoctrineORM\ContainerAwareEntityListenerResolver;
use Application\Test\Assets\DoctrineORM\AttributeTestEntityListener;
use Application\Test\Assets\DoctrineORM\TestEntityListener;
use Application\Test\TestCase;
use InvalidArgumentException;
use Psr\Container\ContainerInterface;

final class ContainerAwareEntityListenerResolverTest extends TestCase
{
    public function testRegisteringNonObjectThrowsException(): void
    {
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::never())
            ->method(self::anything());
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $this->expectException(InvalidArgumentException::class);
        $resolver->register('not-an-object'); // @phpstan-ignore-line
    }

    public function testRegisteredObjectIsReturned(): void
    {
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::never())
            ->method(self::anything());
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $object = new TestEntityListener();

        $resolver->register($object);

        $returnedObject = $resolver->resolve(TestEntityListener::class);

        self::assertSame(
            $object,
            $returnedObject,
        );
    }

    public function testRegisteredObjectIsReturnedAfterOtherObjectBeingCleared(): void
    {
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::never())
            ->method(self::anything());
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $object = new TestEntityListener();
        $otherObject = new AttributeTestEntityListener();

        $resolver->register($object);
        $resolver->register($otherObject);

        $resolver->clear(AttributeTestEntityListener::class);
        $returnedObject = $resolver->resolve(TestEntityListener::class);

        self::assertSame(
            $object,
            $returnedObject,
        );
    }

    public function testObjectIsReturnedFromContainerAfterBeingCleared(): void
    {
        $objectFromContainer = new TestEntityListener();
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::once())
            ->method('get')
            ->willReturn($objectFromContainer);
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $registeredObject = new TestEntityListener();
        $resolver->register($registeredObject);
        $resolver->clear(TestEntityListener::class);

        $returnedObject = $resolver->resolve(TestEntityListener::class);

        self::assertNotSame(
            $registeredObject,
            $returnedObject,
        );
        self::assertSame(
            $objectFromContainer,
            $returnedObject,
        );
    }

    public function testObjectsAreReturnedFromContainerAfterAllHaveBeenCleared(): void
    {
        $objectFromContainer = new TestEntityListener();
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::once())
            ->method('get')
            ->willReturn($objectFromContainer);
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $registeredObject = new TestEntityListener();
        $otherRegisteredObject = new AttributeTestEntityListener();
        $resolver->register($registeredObject);
        $resolver->register($otherRegisteredObject);
        $resolver->clear();

        $returnedObject = $resolver->resolve(TestEntityListener::class);

        self::assertNotSame(
            $registeredObject,
            $returnedObject,
        );
        self::assertSame(
            $objectFromContainer,
            $returnedObject,
        );
    }

    public function testNeverRegisteredObjectIsReturnedFromContainer(): void
    {
        $objectFromContainer = new TestEntityListener();
        $container = $this->createMock(ContainerInterface::class);
        $container
            ->expects(self::once())
            ->method('get')
            ->willReturn($objectFromContainer);
        $resolver = new ContainerAwareEntityListenerResolver($container);

        $returnedObject = $resolver->resolve(TestEntityListener::class);

        self::assertSame(
            $objectFromContainer,
            $returnedObject,
        );
    }
}
