<?php

declare(strict_types=1);

namespace Application\Test;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactory;
use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;

final class TestDoctrineDBALConnections
{
    /**
     * @var array<string, string>
     */
    private static array $registeredDSNs = [];

    public static function register(string $name, string $dsn): void
    {
        self::$registeredDSNs[$name] = $dsn;
    }

    private static function assertRegisteredDSNs(): void
    {
        if (count(self::$registeredDSNs) < 1) {
            TestCase::markTestSkipped('No Doctrine DBAL connections registered');
        }
    }

    /**
     * @return array<string, array<string>>
     */
    public static function databaseConnectionDSNDataProvider(): array
    {
        self::assertRegisteredDSNs();

        return array_map(
            function (string $dsn): array {
                return [$dsn];
            },
            self::$registeredDSNs,
        );
    }

    /**
     * @return array<string, array<DatabaseConnectionFactoryInterface>>
     */
    public static function databaseConnectionFactoryDataProvider(): array
    {
        self::assertRegisteredDSNs();

        return array_map(
            function (string $dsn): array {
                return [new DatabaseConnectionFactory($dsn)];
            },
            self::$registeredDSNs,
        );
    }
}
