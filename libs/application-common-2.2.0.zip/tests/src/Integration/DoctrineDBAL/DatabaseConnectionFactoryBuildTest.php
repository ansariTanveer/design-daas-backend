<?php

declare(strict_types=1);

namespace Application\Test\Integration\DoctrineDBAL;

use Application\Common\DoctrineDBAL\ConnectionPreparerInterface;
use Application\Common\DoctrineDBAL\DatabaseConnectionFactory;
use Application\Test\TestCase;
use Application\Test\TestDoctrineDBALConnections;

final class DatabaseConnectionFactoryBuildTest extends TestCase
{
    /**
     * @return array<string, array<string>>
     */
    public function dsnDataProvider(): array
    {
        return TestDoctrineDBALConnections::databaseConnectionDSNDataProvider();
    }

    /**
     * @dataProvider dsnDataProvider
     */
    public function testConnectionBuildingDoesNotCauseError(string $dsn): void
    {
        $factory = new DatabaseConnectionFactory($dsn);
        $connection = $factory->build();
        $connection->connect();

        self::assertTrue($connection->isConnected());
        self::assertFalse($connection->isTransactionActive());
    }

    /**
     * @dataProvider dsnDataProvider
     */
    public function testConnectionPreparerIsCalled(string $dsn): void
    {
        $preparedConnection = null;
        $mockConnectionPreparer = $this->createMock(ConnectionPreparerInterface::class);
        $mockConnectionPreparer->expects(self::once())
            ->method('prepareParams')
            ->willReturnCallback(
                function (array $params) use ($dsn): array {
                    self::assertArrayHasKey('url', $params);
                    self::assertSame($dsn, $params['url']);
                    return $params;
                },
            );
        $mockConnectionPreparer->expects(self::once())
            ->method('prepareConfiguration')
            ->willReturn(null);
        $mockConnectionPreparer->expects(self::once())
            ->method('prepareEventManager')
            ->willReturn(null);
        $mockConnectionPreparer->expects(self::once())
            ->method('prepareConnection')
            ->willReturnCallback(
                function ($connection) use (&$preparedConnection): void {
                    self::assertNull($preparedConnection);
                    $preparedConnection = $connection;
                },
            );

        $factory = new DatabaseConnectionFactory($dsn, $mockConnectionPreparer);
        $connection = $factory->build();

        self::assertNotNull($preparedConnection);
        self::assertSame($preparedConnection, $connection);
    }
}
