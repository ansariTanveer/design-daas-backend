<?php

declare(strict_types=1);

namespace Application\Test\Integration\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\DoctrineORM\ConfigurationCache;
use Application\Common\DoctrineORM\ConfigurationCacheEntityListenerResolverInjector;
use Application\Common\DoctrineORM\ConfigurationCacheInterface;
use Application\Common\DoctrineORM\ConfigurationCollector;
use Application\Common\DoctrineORM\ContainerAwareEntityListenerResolver;
use Application\Common\DoctrineORM\LazyEntityManager;
use Application\Test\Assets\DoctrineORM\TestEntity;
use Application\Test\Assets\DoctrineORM\TestEntityListener;
use Application\Test\TestCase;
use Application\Test\TestDoctrineDBALConnections;
use DI\Container;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Event\PrePersistEventArgs;

final class EntityListenerTest extends TestCase
{
    private Container $container;

    private ConfigurationCacheInterface $cache;

    private string $sqlScriptName;

    protected function setUp(): void
    {
        parent::setUp();
        $this->sqlScriptName = self::TEST_CONFIG_DIR . '/DoctrineORM/create_tables_%1$s.sql';
        $collector = new ConfigurationCollector();
        $collector->addSearchPath(self::TEST_SRC_DIR . '/DoctrineORM');
        $this->container = new Container();
        $this->cache = new ConfigurationCacheEntityListenerResolverInjector(
            new ConfigurationCache($collector, null, 'DoesNotMatter.cache'),
            new ContainerAwareEntityListenerResolver($this->container),
        );
    }

    private function executeSqlScript(EntityManagerInterface $em): void
    {
        $sql = file_get_contents(
            sprintf(
                $this->sqlScriptName,
                $em->getConnection()->getDatabasePlatform()->getName(),
            ),
        );
        self::assertIsString($sql);
        $em->getConnection()->executeStatement($sql);
    }

    /**
     * @return array<string, array<DatabaseConnectionFactoryInterface>>
     */
    public function dataProvider(): array
    {
        return TestDoctrineDBALConnections::databaseConnectionFactoryDataProvider();
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEntityListenerIsResolvedAndCalled(DatabaseConnectionFactoryInterface $factory): void
    {
        $em = new LazyEntityManager($factory, $this->cache);
        $this->executeSqlScript($em);

        $receivedEntity = null;
        $callback = function (TestEntity $entity, PrePersistEventArgs $event) use (&$receivedEntity): void {
            self::assertNull($receivedEntity);
            self::assertSame($entity, $event->getObject());
            $receivedEntity = $entity;
        };
        $listener = new TestEntityListener($callback);
        $this->container->set(TestEntityListener::class, $listener);

        $expectedValue = 'some-value';
        $expectedEntity = new TestEntity($expectedValue);
        $em->persist($expectedEntity);

        self::assertInstanceOf(
            TestEntity::class,
            $receivedEntity,
        );

        self::assertSame(
            $expectedEntity,
            $receivedEntity,
        );

        self::assertSame(
            $expectedValue,
            $receivedEntity->value(),
        );
    }
}
