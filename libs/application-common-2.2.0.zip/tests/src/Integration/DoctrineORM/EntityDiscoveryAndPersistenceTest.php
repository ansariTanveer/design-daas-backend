<?php

declare(strict_types=1);

namespace Application\Test\Integration\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\DoctrineORM\ConfigurationCache;
use Application\Common\DoctrineORM\ConfigurationCacheInterface;
use Application\Common\DoctrineORM\ConfigurationCollector;
use Application\Common\DoctrineORM\LazyEntityManager;
use Application\Test\Assets\DoctrineORM\MissingEntityRepository;
use Application\Test\Assets\DoctrineORM\TestEntity;
use Application\Test\Assets\DoctrineORM\TestEntityRepository;
use Application\Test\TestCase;
use Application\Test\TestDoctrineDBALConnections;
use Doctrine\ORM\EntityManagerInterface;
use RuntimeException;

final class EntityDiscoveryAndPersistenceTest extends TestCase
{
    private ConfigurationCacheInterface $cache;

    private string $sqlScriptName;

    protected function setUp(): void
    {
        parent::setUp();
        $this->sqlScriptName = self::TEST_CONFIG_DIR . '/DoctrineORM/create_tables_%1$s.sql';
        $collector = new ConfigurationCollector();
        $collector->addSearchPath(self::TEST_SRC_DIR . '/DoctrineORM');
        $this->cache = new ConfigurationCache($collector, null, 'DoesNotMatter.cache');
    }

    private function executeSqlScript(EntityManagerInterface $em): void
    {
        $sql = file_get_contents(
            sprintf(
                $this->sqlScriptName,
                $em->getConnection()->getDatabasePlatform()->getName(),
            ),
        );
        self::assertIsString($sql);
        $em->getConnection()->executeStatement($sql);
    }

    /**
     * @return array<string, array<DatabaseConnectionFactoryInterface>>
     */
    public function dataProvider(): array
    {
        return TestDoctrineDBALConnections::databaseConnectionFactoryDataProvider();
    }

    public function testCorrectRepositoryIsUsed(): void
    {
        $factory = $this->createMock(DatabaseConnectionFactoryInterface::class);
        $factory->expects(self::never())->method('build');
        $em = new LazyEntityManager($factory, $this->cache);

        $repository = $em->getRepository(TestEntity::class);

        self::assertInstanceOf(TestEntityRepository::class, $repository);
    }

    public function testRepositoryCanBeCreatedManually(): void
    {
        $factory = $this->createMock(DatabaseConnectionFactoryInterface::class);
        $factory->expects(self::never())->method('build');
        $em = new LazyEntityManager($factory, $this->cache);

        $repository = new TestEntityRepository($em);

        self::assertSame($em, $repository->getEntityManagerForTesting());
    }

    public function testRepositoryWithMissingEntityCannotBeCreatedManually(): void
    {
        $factory = $this->createMock(DatabaseConnectionFactoryInterface::class);
        $factory->expects(self::never())->method('build');
        $em = new LazyEntityManager($factory, $this->cache);

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessageMatches('=^Failed to lookup class metadata for repository=');

        new MissingEntityRepository($em);
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEntityIsPersistedCorrectly(DatabaseConnectionFactoryInterface $factory): void
    {
        $em = new LazyEntityManager($factory, $this->cache);
        $this->executeSqlScript($em);

        $value = 'SomeValue';
        $entity = new TestEntity($value);
        $em->persist($entity);
        $em->flush();

        self::assertGreaterThanOrEqual(1, $entity->id());
        self::assertGreaterThanOrEqual(1, $entity->version());
        self::assertSame($value, $entity->value());
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEntityIsLoadedCorrectly(DatabaseConnectionFactoryInterface $factory): void
    {
        $em = new LazyEntityManager($factory, $this->cache);
        $this->executeSqlScript($em);
        $repository = new TestEntityRepository($em);

        $entity = new TestEntity('SomeValue');
        $em->persist($entity);
        $em->flush();
        $em->clear();

        $entity2 = $repository->find($entity->id());
        self::assertNotNull($entity2);

        self::assertSame($entity->id(), $entity2->id());
        self::assertSame($entity->version(), $entity2->version());
        self::assertSame($entity->value(), $entity2->value());
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEntityIsUpdatedCorrectly(DatabaseConnectionFactoryInterface $factory): void
    {
        $em = new LazyEntityManager($factory, $this->cache);
        $this->executeSqlScript($em);
        $repository = new TestEntityRepository($em);

        $entity = new TestEntity('SomeValue');
        $em->persist($entity);
        $em->flush();
        $em->clear();

        $entity2 = $repository->find($entity->id());
        self::assertNotNull($entity2);

        $value = 'AnotherValue';
        self::assertNotSame($value, $entity2->value());
        $entity2->setValue($value);
        $em->flush();
        $em->clear();

        $entity3 = $repository->find($entity2->id());
        self::assertNotNull($entity3);

        self::assertSame($entity2->id(), $entity3->id());
        self::assertNotSame($entity->version(), $entity3->version());
        self::assertSame($entity2->version(), $entity3->version());
        self::assertSame($entity2->value(), $entity3->value());
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEntityIsRemovedCorrectly(DatabaseConnectionFactoryInterface $factory): void
    {
        $em = new LazyEntityManager($factory, $this->cache);
        $this->executeSqlScript($em);
        $repository = new TestEntityRepository($em);

        $entity = new TestEntity('SomeValue');
        $em->persist($entity);
        $em->flush();
        $em->clear();

        $entity2 = $repository->find($entity->id());
        self::assertNotNull($entity2);

        $em->remove($entity2);
        $em->flush();
        $em->clear();

        self::assertNull($repository->find($entity->id()));
    }
}
