<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use Application\Common\HttpBaseUrl\BaseUrlResolverInterface;
use BadMethodCallException;
use Closure;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Symfony\Component\EventDispatcher\EventDispatcher as SymfonyComponentEventDispatcher;
use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\Matcher\UrlMatcher;
use Symfony\Component\Routing\RequestContext;

final class Psr7Router implements Psr7RouterInterface
{
    private BaseUrlResolverInterface $baseUrlResolver;

    private RouteCacheInterface $routeCache;

    private ResponseFactoryInterface $responseFactory;

    private PsrEventDispatcherInterface $eventDispatcher;

    private string $routeNameAttribute;

    private string $routeParametersAttribute;

    private string $routeOptionsAttribute;

    public function __construct(
        BaseUrlResolverInterface $baseUrlResolver,
        RouteCacheInterface $routeCache,
        ResponseFactoryInterface $responseFactory,
        PsrEventDispatcherInterface $eventDispatcher = null,
        string $routeNameAttribute = null,
        string $routeParametersAttribute = null,
        string $routeOptionsAttribute = null
    ) {
        $this->baseUrlResolver = $baseUrlResolver;
        $this->routeCache = $routeCache;
        $this->responseFactory = $responseFactory;
        $this->eventDispatcher = $eventDispatcher ?? new SymfonyComponentEventDispatcher();
        $this->routeNameAttribute = $routeNameAttribute ?? 'route_name';
        $this->routeParametersAttribute = $routeParametersAttribute ?? 'route_parameters';
        $this->routeOptionsAttribute = $routeOptionsAttribute ?? 'route_options';
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    private function buildRouteNotFoundResponse(
        ServerRequestInterface $request,
        ResourceNotFoundException $exception
    ): ResponseInterface {
        $event = new RouteNotFoundEvent($request, $exception);
        $this->eventDispatcher->dispatch($event);
        $response = $event->response();
        if ($response === null) {
            $response = $this->responseFactory->createResponse(404);
        }
        return $response;
    }

    private function buildMethodNotAllowedResponse(
        ServerRequestInterface $request,
        MethodNotAllowedException $exception
    ): ResponseInterface {
        $event = new MethodNotAllowedEvent($request, $exception);
        $this->eventDispatcher->dispatch($event);
        $response = $event->response();
        if ($response === null) {
            if ($request->getMethod() === 'OPTIONS') {
                $response = $this->responseFactory->createResponse(200)
                    ->withHeader('Allow', implode(',', $exception->getAllowedMethods()));
            } else {
                $response = $this->responseFactory->createResponse(405);
            }
        }
        return $response;
    }

    public function routeNameAttribute(): string
    {
        return $this->routeNameAttribute;
    }

    public function routeParametersAttribute(): string
    {
        return $this->routeParametersAttribute;
    }

    public function routeOptionsAttribute(): string
    {
        return $this->routeOptionsAttribute;
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        return $this($request, Closure::fromCallable([$handler, 'handle']));
    }

    /**
     * @param callable(ServerRequestInterface): ResponseInterface $next
     */
    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface
    {
        $baseUrl = $this->baseUrlResolver->baseUrl();
        $uriScheme = $request->getUri()->getScheme();
        $uriPort = $request->getUri()->getPort();
        $context = new RequestContext(
            $baseUrl->getPath(),
            $request->getMethod(),
            $request->getUri()->getHost(),
            $request->getUri()->getScheme(),
            ($uriScheme !== 'https' && $uriPort !== null) ? $uriPort : 80,
            ($uriScheme === 'https' && $uriPort !== null) ? $uriPort : 443,
            $request->getRequestTarget(),
            $request->getUri()->getQuery(),
        );

        $routes = $this->routeCache->loadRouteCollection();

        $matcher = new UrlMatcher($routes, $context);
        try {
            $parameters = $matcher->match($context->getPathInfo());
            $matchedRoute = $routes->get($parameters['_route']);
            assert($matchedRoute !== null);
        } catch (ResourceNotFoundException $e) {
            return $this->buildRouteNotFoundResponse($request, $e);
        } catch (MethodNotAllowedException $e) {
            return $this->buildMethodNotAllowedResponse($request, $e);
        }

        $request = $request->withAttribute($this->routeNameAttribute(), $parameters['_controller'])
            ->withAttribute($this->routeParametersAttribute(), $parameters)
            ->withAttribute($this->routeOptionsAttribute(), $matchedRoute->getOptions());

        return $next($request);
    }
}
