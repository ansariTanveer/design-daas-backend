<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole;

use Application\Common\SymfonyConsole\CommandCache\CommandFactory;
use Application\Common\SymfonyConsole\CommandCache\DataStore;
use BadMethodCallException;
use Psr\Container\ContainerInterface;
use ReflectionClass;

final class CommandCache implements CommandCacheInterface
{
    private CommandCollectorInterface $collector;

    private ?string $cacheFile;

    private ?DataStore $inMemoryCache = null;

    public function __construct(CommandCollectorInterface $collector, ?string $cacheFile)
    {
        $this->collector = $collector;
        $this->cacheFile = $cacheFile;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildCache(): void
    {
        if (!$this->useCache()) {
            return;
        }
        $dataStore = $this->buildDataStore();
        assert($this->cacheFile !== null);
        file_put_contents($this->cacheFile, serialize($dataStore));
    }

    private function useCache(): bool
    {
        return $this->cacheFile !== null;
    }

    public function loadCommandList(ContainerInterface $container): array
    {
        $commandList = [];
        $dataStore = $this->loadDataStore();
        $commandFactory = new CommandFactory($dataStore, $container);
        /** @psalm-var class-string[] $commandClassNames */
        $commandClassNames = $dataStore->keys();
        foreach ($commandClassNames as $commandClassName) {
            $additionalCommands = $commandFactory->createCommandsFromClass(
                $this->createDummyCommandClass($commandClassName),
            );
            foreach ($additionalCommands as $command) {
                $commandList[] = $command;
            }
        }
        return $commandList;
    }

    private function loadDataStore(): DataStore
    {
        if ($this->inMemoryCache === null) {
            if ($this->useCache()) {
                assert($this->cacheFile !== null);
                $serializesDataStore = file_get_contents($this->cacheFile);
                assert($serializesDataStore !== false);
                $dataStore = unserialize($serializesDataStore);
                assert($dataStore instanceof DataStore);
            } else {
                $dataStore = $this->buildDataStore();
            }
            $this->inMemoryCache = $dataStore;
        }
        return $this->inMemoryCache;
    }

    private function buildDataStore(): DataStore
    {
        $dataStore = new DataStore();
        $commandFactory = new CommandFactory($dataStore, null);
        $commandClassNames = $this->collector->collectCommandClassNames();
        foreach ($commandClassNames as $commandClassName) {
            $commandFactory->getCommandInfoListFromClass(
                $this->createDummyCommandClass($commandClassName),
            );
        }
        return $dataStore;
    }

    /**
     * @param class-string $commandClassName
     * @return object
     */
    private function createDummyCommandClass(string $commandClassName): object
    {
        $reflectionClass = new ReflectionClass($commandClassName);
        return $reflectionClass->newInstanceWithoutConstructor();
    }
}
