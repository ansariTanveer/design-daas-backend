<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use BadMethodCallException;
use Psr\Http\Message\ResponseInterface;

final class InvalidUserInputEvent
{
    private InvalidUserInputException $exception;

    private ResponseInterface $response;

    public function __construct(InvalidUserInputException $exception, ResponseInterface $defaultResponse)
    {
        $this->exception = $exception;
        $this->response = $defaultResponse;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function exception(): InvalidUserInputException
    {
        return $this->exception;
    }

    public function replaceResponse(ResponseInterface $newResponse): void
    {
        $this->response = $newResponse;
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }
}
