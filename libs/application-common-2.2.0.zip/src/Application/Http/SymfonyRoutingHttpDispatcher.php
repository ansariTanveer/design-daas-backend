<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use Application\Common\Application\UnexpectedExceptionEvent;
use Application\Common\SymfonyRouting\Psr7RouterInterface;
use BadMethodCallException;
use Closure;
use DI\Container;
use Http\Factory\Guzzle\ResponseFactory;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Relay\Relay;
use Symfony\Component\EventDispatcher\EventDispatcher as SymfonyComponentEventDispatcher;
use Throwable;

final class SymfonyRoutingHttpDispatcher implements HttpDispatcherInterface
{
    private Container $container;

    private Psr7RouterInterface $router;

    /**
     * @var array<MiddlewareInterface|RequestHandlerInterface|callable>
     */
    private array $preRouteMiddlewareQueue;

    /**
     * @var array<MiddlewareInterface|RequestHandlerInterface|callable>
     */
    private array $postRouteMiddlewareQueue;

    private PsrEventDispatcherInterface $eventDispatcher;

    /**
     * @param array<MiddlewareInterface|RequestHandlerInterface|callable> $preRouteMiddlewareQueue
     * @param array<MiddlewareInterface|RequestHandlerInterface|callable> $postRouteMiddlewareQueue
     */
    public function __construct(
        Container $container,
        Psr7RouterInterface $router,
        array $preRouteMiddlewareQueue,
        array $postRouteMiddlewareQueue,
        PsrEventDispatcherInterface $eventDispatcher = null
    ) {
        $this->container = $container;
        $this->router = $router;
        $this->preRouteMiddlewareQueue = $preRouteMiddlewareQueue;
        $this->postRouteMiddlewareQueue = $postRouteMiddlewareQueue;
        $this->eventDispatcher = $eventDispatcher ?? new SymfonyComponentEventDispatcher();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function dispatch(ServerRequestInterface $request, bool $bodyTooLarge): ResponseInterface
    {
        $queue = array_merge(
            [
                /*
                 * In case the first set of middlewares did not handle the exception thrown in case
                 * $bodyTooLarge is true, convert the exception to an empty HTTP 413 response by default
                 * because otherwise a too large request body would cause a crash of the application
                 * (which would probably result in an HTTP 500 response).
                 */
                function (ServerRequestInterface $request, callable $next): ResponseInterface {
                    try {
                        return $next($request);
                    } catch (RequestBodyTooLargeException $e) {
                        return (new ResponseFactory())->createResponse(413);
                    }
                },
            ],
            array_values($this->preRouteMiddlewareQueue),
            [
                /*
                 * Convert $bodyTooLarge to an exception AFTER the first set of middlewares to allow
                 * returning a custom response in that case.
                 */
                function (ServerRequestInterface $request, callable $next) use ($bodyTooLarge): ResponseInterface {
                    if ($bodyTooLarge) {
                        throw new RequestBodyTooLargeException('Request body too large');
                    }
                    return $next($request);
                },
                /*
                 * Actual request routing is done by the router.
                 */
                $this->router,
            ],
            array_values($this->postRouteMiddlewareQueue),
            [
                /*
                 * Call the route that has been resolved by the router.
                 */
                Closure::fromCallable([$this, 'callRoute']),
            ],
        );
        $relay = new Relay($queue);

        try {
            $response = $relay->handle($request);
            $this->eventDispatcher->dispatch(new HttpDispatcherFinishedEvent(true, $response->getStatusCode()));
            return $response;
        } catch (Throwable $e) {
            $this->eventDispatcher->dispatch(new UnexpectedExceptionEvent($e));
            $this->eventDispatcher->dispatch(new HttpDispatcherFinishedEvent(false, $e->getCode()));
            throw $e;
        }
    }

    private function callRoute(ServerRequestInterface $request): ResponseInterface
    {
        $this->container->set(ServerRequestInterface::class, $request);
        /** @var callable $callableRoute */
        $callableRoute = $request->getAttribute($this->router->routeNameAttribute());
        $routeParameters = $request->getAttribute($this->router->routeParametersAttribute());
        assert(is_array($routeParameters));
        $response = $this->container->call($callableRoute, $routeParameters);
        assert($response instanceof ResponseInterface);
        return $response;
    }

    public function reset(): void
    {
    }
}
