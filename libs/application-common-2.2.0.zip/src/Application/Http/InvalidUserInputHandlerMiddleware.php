<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use BadMethodCallException;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final class InvalidUserInputHandlerMiddleware
{
    private ResponseFactoryInterface $responseFactory;

    private PsrEventDispatcherInterface $eventDispatcher;

    public function __construct(ResponseFactoryInterface $responseFactory, PsrEventDispatcherInterface $eventDispatcher)
    {
        $this->responseFactory = $responseFactory;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @param callable(ServerRequestInterface): ResponseInterface $next
     */
    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface
    {
        try {
            return $next($request);
        } catch (InvalidUserInputException $exception) {
            return $this->buildResponse($exception);
        }
    }

    private function buildResponse(InvalidUserInputException $exception): ResponseInterface
    {
        $defaultResponse = $this->responseFactory->createResponse(400);
        $event = new InvalidUserInputEvent($exception, $defaultResponse);
        $this->eventDispatcher->dispatch($event);
        return $event->response();
    }
}
