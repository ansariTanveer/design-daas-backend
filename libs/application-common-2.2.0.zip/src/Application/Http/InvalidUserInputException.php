<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use RuntimeException;

class InvalidUserInputException extends RuntimeException
{
}
