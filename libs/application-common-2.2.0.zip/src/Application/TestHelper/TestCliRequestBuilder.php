<?php

declare(strict_types=1);

namespace Application\Common\Application\TestHelper;

use Application\Common\Application\Cli\CliApplicationInterface;
use BadMethodCallException;
use PHPUnit\Framework\TestCase;

final class TestCliRequestBuilder
{
    /**
     * @var array<string, string>
     */
    private array $env = [];

    /**
     * @var array<string, string>
     */
    private array $server = [];

    /**
     * @var array<int, string>|null
     */
    private ?array $argv = null;

    /**
     * @var resource|null
     */
    private $stdIn = null;

    private ?int $expectedExitCode = null;

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @param array<string, string> $env
     * @return self
     */
    public function additionalEnv(array $env): self
    {
        $this->env = array_merge($this->env, $env);
        return $this;
    }

    /**
     * @param array<string, string> $server
     * @return self
     */
    public function additionalServer(array $server): self
    {
        $this->server = array_merge($this->server, $server);
        return $this;
    }

    /**
     * @param array<int, string> $argv
     * @return self
     */
    public function argv(array $argv): self
    {
        $this->argv = $argv;
        return $this;
    }

    public function stdIn(string $stdIn): self
    {
        $stream = fopen('php://memory', 'r+');
        assert($stream !== false);
        $this->stdIn = $stream;
        unset($stream);
        fwrite($this->stdIn, $stdIn);
        rewind($this->stdIn);
        return $this;
    }

    public function expectExitCode(int $expectedExitCode): self
    {
        $this->expectedExitCode = $expectedExitCode;
        return $this;
    }

    /**
     * @return array{std_in: resource, std_out: resource, std_err: resource}
     */
    public function prepare(CliApplicationInterface $application): array
    {
        TestCase::assertNotNull($this->argv, 'Command line arguments not specified');

        $server = [
            'argv' => ['application.php'],
        ];

        foreach ($this->argv as $arg) {
            $server['argv'][] = $arg;
        }

        if ($this->stdIn === null) {
            $stream = fopen('php://memory', 'r+');
            assert($stream !== false);
            $this->stdIn = $stream;
            unset($stream);
        }

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $application->setRuntimeEnvironment(
            $this->stdIn,
            $stdOut,
            $stdErr,
            array_merge($this->env, $this->server, $server),
        );

        return ['std_in' => $this->stdIn, 'std_out' => $stdOut, 'std_err' => $stdErr];
    }

    public function execute(CliApplicationInterface $application): TestCliResponseContainer
    {
        $data = $this->prepare($application);

        $response = new TestCliResponseContainer(
            $application->execute(),
            $data['std_out'],
            $data['std_err'],
        );

        if ($this->expectedExitCode !== null) {
            TestCase::assertSame(
                $this->expectedExitCode,
                $response->exitCode(),
                $response->formatAsString(),
            );
        }

        return $response;
    }
}
