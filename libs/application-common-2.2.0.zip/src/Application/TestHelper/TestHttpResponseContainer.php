<?php

declare(strict_types=1);

namespace Application\Common\Application\TestHelper;

use BadMethodCallException;
use Psr\Http\Message\ResponseInterface;

final class TestHttpResponseContainer
{
    private ResponseInterface $response;

    public function __construct(ResponseInterface $response)
    {
        $this->response = $response;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }

    public function statusCode(): int
    {
        return $this->response->getStatusCode();
    }

    public function contentType(): string
    {
        return $this->response->getHeaderLine('Content-Type');
    }

    public function bodyAsString(): string
    {
        $bodyStream = $this->response->getBody();
        assert($bodyStream->isSeekable()); // Assume that response streams during testing are always seekable
        $bodyStream->rewind();
        return (string)$bodyStream;
    }

    public function formatAsString(): string
    {
        $format = 'HTTP Status: %1$d' . PHP_EOL . PHP_EOL .
            'Response Headers (JSON encoded): ' . PHP_EOL . PHP_EOL . '%2$s' . PHP_EOL . PHP_EOL .
            'Response body (JSON encoded):' . PHP_EOL . PHP_EOL . '%3$s' . PHP_EOL . PHP_EOL;
        return sprintf(
            $format,
            $this->statusCode(),
            json_encode($this->response->getHeaders()),
            json_encode($this->bodyAsString()),
        );
    }

    public function __toString(): string
    {
        return $this->formatAsString();
    }
}
