<?php

declare(strict_types=1);

namespace Application\Common\Application\TestHelper;

use Application\Common\Application\Http\HttpApplicationInterface;
use BadMethodCallException;
use PHPUnit\Framework\TestCase;

final class TestHttpRequestBuilder
{
    /**
     * @var array<string, string>
     */
    private array $env = [];

    /**
     * @var array<string, string>
     */
    private array $server = [];

    /**
     * @var array<string, string>
     */
    private array $get = [];

    /**
     * @var array<string, string>
     */
    private array $post = [];

    /**
     * @var array<string, string>
     */
    private array $cookie = [];

    /**
     * @var array<TestHttpRequestFile>
     */
    private array $files = [];

    private ?string $method = null;

    private ?string $uri = null;

    private ?string $contentType = null;

    /**
     * @var resource|null
     */
    private $inputStream = null;

    private bool $requestTooLarge = false;

    private ?int $expectedResponseCode = null;

    private ?string $expectedContentType = null;

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @param array<string, string> $env
     * @return self
     */
    public function additionalEnv(array $env): self
    {
        $this->env = array_merge($this->env, $env);
        return $this;
    }

    /**
     * @param array<string, string> $server
     * @return self
     */
    public function additionalServer(array $server): self
    {
        $this->server = array_merge($this->server, $server);
        return $this;
    }

    /**
     * @param array<string, string> $get
     * @return self
     */
    public function additionalGet(array $get): self
    {
        $this->get = array_merge($this->get, $get);
        return $this;
    }

    /**
     * @param array<string, string> $post
     * @return self
     */
    public function additionalPost(array $post): self
    {
        $this->post = array_merge($this->post, $post);
        return $this;
    }

    /**
     * @param array<string, string> $cookie
     * @return self
     */
    public function additionalCookie(array $cookie): self
    {
        $this->cookie = array_merge($this->cookie, $cookie);
        return $this;
    }

    /**
     * @param array<string, string|list<string>> $headers
     * @return self
     */
    public function additionalHeaders(array $headers): self
    {
        $additionalServer = [];
        foreach ($headers as $header => $value) {
            $header = 'HTTP_' . strtoupper((string)preg_replace('=[\W]+=', '_', $header));
            if (!is_array($value)) {
                $value = [$value];
            }
            $value = implode(',', $value);
            if (array_key_exists($header, $this->server)) {
                $value = $this->server[$header] . ', ' . $value;
            }
            $additionalServer[$header] = $value;
        }
        return $this->additionalServer($additionalServer);
    }

    public function additionalFile(TestHttpRequestFile $file): self
    {
        $this->files[] = $file;
        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    private function prepareFilesArray(): array
    {
        $files = [];
        foreach ($this->files as $file) {
            $part = $file->part();
            $data = [
                'name' => $file->name(),
                'type' => $file->type(),
                'tmp_name' => $file->path(),
                'error' => $file->uploadResult(),
                'size' => $file->size(),
            ];
            if (!array_key_exists($part, $files)) {
                $files[$part] = $data;
            } elseif (array_key_exists('name', $files[$part])) {
                $files[$part] = [
                    $files[$part],
                    $data,
                ];
            } else {
                $files[$part][] = $data;
            }
        }
        return $files;
    }

    public function method(string $method): self
    {
        $this->method = $method;
        return $this;
    }

    public function uri(string $uri): self
    {
        $this->uri = $uri;
        return $this;
    }

    public function contentType(string $contentType): self
    {
        $this->contentType = $contentType;
        return $this;
    }

    public function body(string $body): self
    {
        $stream = fopen('php://memory', 'r+');
        assert($stream !== false);
        $this->inputStream = $stream;
        unset($stream);
        fwrite($this->inputStream, $body);
        rewind($this->inputStream);
        return $this;
    }

    public function requestTooLarge(): self
    {
        $this->requestTooLarge = true;
        return $this;
    }

    public function expectResponseCode(int $expectedResponseCode): self
    {
        $this->expectedResponseCode = $expectedResponseCode;
        return $this;
    }

    public function expectContentType(string $expectedContentType): self
    {
        $this->expectedContentType = $expectedContentType;
        return $this;
    }

    /**
     * @return array{input_stream: resource}
     */
    public function prepare(HttpApplicationInterface $application): array
    {
        TestCase::assertNotNull($this->method, 'Request method not specified');
        TestCase::assertNotNull($this->uri, 'Request URI not specified');
        TestCase::assertStringStartsWith('/', $this->uri, 'Request URI must start with /');

        if ($this->inputStream === null) {
            $stream = fopen('php://memory', 'r+');
            assert($stream !== false);
            $this->inputStream = $stream;
            unset($stream);
        }

        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => $this->method,
            'REQUEST_URI' => '/subdir' . $this->uri,
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];

        if ($this->contentType !== null) {
            $server['CONTENT_TYPE'] = $this->contentType;
        }

        $application->setRuntimeEnvironment(
            $this->get,
            $this->post,
            $this->cookie,
            $this->prepareFilesArray(),
            array_merge($this->env, $this->server, $server),
            $this->inputStream,
        );

        if ($this->requestTooLarge) {
            $application->flagTooLargeRequestBody();
        }

        return ['input_stream' => $this->inputStream];
    }

    public function execute(HttpApplicationInterface $application): TestHttpResponseContainer
    {
        $this->prepare($application);

        $response = new TestHttpResponseContainer(
            $application->execute(),
        );

        if ($this->expectedResponseCode !== null) {
            TestCase::assertSame(
                $this->expectedResponseCode,
                $response->statusCode(),
                $response->formatAsString(),
            );
        }

        if ($this->expectedContentType !== null) {
            $actualContentType = $response->contentType();
            $matchPrimaryContentType = strpos($this->expectedContentType, ';') === false &&
                strpos($actualContentType, ';') !== false;
            if ($matchPrimaryContentType) {
                TestCase::assertStringStartsWith(
                    $this->expectedContentType . ';',
                    $actualContentType,
                    $response->formatAsString(),
                );
            } else {
                TestCase::assertSame(
                    $this->expectedContentType,
                    $actualContentType,
                    $response->formatAsString(),
                );
            }
        }

        return $response;
    }
}
