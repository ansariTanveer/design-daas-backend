<?php

declare(strict_types=1);

namespace Application\Common\Application;

use DI\Definition\Source\DefinitionArray;
use DI\Definition\Source\DefinitionSource;
use DI\Definition\Source\SourceChain;
use Http\Factory\Guzzle\RequestFactory;
use Http\Factory\Guzzle\ResponseFactory;
use Http\Factory\Guzzle\ServerRequestFactory;
use Http\Factory\Guzzle\StreamFactory;
use Http\Factory\Guzzle\UploadedFileFactory;
use Http\Factory\Guzzle\UriFactory;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\RequestFactoryInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Psr\Http\Message\StreamFactoryInterface;
use Psr\Http\Message\UploadedFileFactoryInterface;
use Psr\Http\Message\UriFactoryInterface;
use Symfony\Component\EventDispatcher\EventDispatcher as SymfonyComponentEventDispatcher;
use Symfony\Component\EventDispatcher\EventDispatcherInterface as SymfonyComponentEventDispatcherInterface;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface as SymfonyContractsEventDispatcherInterface;

final class DefaultContainerServices
{
    /**
     * Private constructor.
     *
     * @codeCoverageIgnore
     */
    private function __construct()
    {
    }

    public static function definitions(): DefinitionSource
    {
        return new SourceChain(
            [
                self::httpFactories(),
                self::eventDispatcher(),
            ],
        );
    }

    private static function httpFactories(): DefinitionSource
    {
        return new DefinitionArray(
            [
                RequestFactoryInterface::class =>
                    \DI\get(RequestFactory::class),
                ServerRequestFactoryInterface::class =>
                    \DI\get(ServerRequestFactory::class),
                UriFactoryInterface::class =>
                    \DI\get(UriFactory::class),
                UploadedFileFactoryInterface::class =>
                    \DI\get(UploadedFileFactory::class),
                StreamFactoryInterface::class =>
                    \DI\get(StreamFactory::class),
                ResponseFactoryInterface::class =>
                    \DI\get(ResponseFactory::class),
            ],
        );
    }

    private static function eventDispatcher(): DefinitionSource
    {
        return new DefinitionArray(
            [
                SymfonyComponentEventDispatcherInterface::class =>
                    \DI\get(SymfonyComponentEventDispatcher::class),
                SymfonyContractsEventDispatcherInterface::class =>
                    \DI\get(SymfonyComponentEventDispatcherInterface::class),
                PsrEventDispatcherInterface::class =>
                    \DI\get(SymfonyContractsEventDispatcherInterface::class),
            ],
        );
    }
}
