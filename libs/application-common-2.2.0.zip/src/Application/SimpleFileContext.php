<?php

declare(strict_types=1);

namespace Application\Common\Application;

use BadMethodCallException;
use DI\Container;
use DI\ContainerBuilder;
use DI\Definition\Source\DefinitionArray;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;

final class SimpleFileContext implements ApplicationContextInterface
{
    private bool $registerDefaultServices;

    /**
     * @var array<array<string, mixed>>
     */
    private array $staticEntries = [];

    /**
     * @var array<array{source: DefinitionArray, entries: array<string, callable>}>
     */
    private array $environmentEntries = [];

    private bool $environmentApplied = false;

    private Container $container;

    /**
     * @param array<string> $staticEntriesFiles
     * @param array<string> $environmentEntriesFiles
     */
    public function __construct(
        array $staticEntriesFiles,
        array $environmentEntriesFiles,
        bool $registerDefaultServices = true
    ) {
        $this->registerDefaultServices = $registerDefaultServices;
        $this->loadStaticEntriesFromFiles($staticEntriesFiles);
        $this->loadEnvironmentEntriesFromFiles($environmentEntriesFiles);
        $this->initialize();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @param array<string> $files
     */
    private function loadStaticEntriesFromFiles(array $files): void
    {
        foreach ($files as $file) {
            /** @var array<string, mixed> $entries */
            $entries = (function () use ($file): array {
                return require $file;
            })();
            $this->staticEntries[] = $entries;
        }
    }

    /**
     * @param array<string> $files
     */
    private function loadEnvironmentEntriesFromFiles(array $files): void
    {
        foreach ($files as $file) {
            /** @var array<string, callable> $entries */
            $entries = (function () use ($file): array {
                return require $file;
            })();
            $this->environmentEntries[] = [
                'source' => new DefinitionArray(),
                'entries' => $entries,
            ];
        }
    }

    public function container(): Container
    {
        $this->ensureEnvironmentIsApplied();
        return $this->container;
    }

    public function applyEnvironmentVariablesFromServer(array $server): void
    {
        foreach ($this->environmentEntries as $data) {
            $this->applyEnvironmentVariablesToSource($server, $data['source'], $data['entries']);
        }
        $this->environmentApplied = true;
    }

    /**
     * @param array<string, mixed> $server
     * @param array<string, callable> $entries
     */
    private function applyEnvironmentVariablesToSource(array $server, DefinitionArray $source, array $entries): void
    {
        $definitions = [];
        foreach ($entries as $name => $callable) {
            $definitions[$name] = $callable($server);
        }
        $source->addDefinitions($definitions);
    }

    public function reset(): void
    {
        $this->dispatchEvent(new ApplicationContextResetEvent());
        $this->initialize();
    }

    private function ensureEnvironmentIsApplied(): void
    {
        if (!$this->environmentApplied) {
            $this->applyEnvironmentVariablesFromServer([]);
            assert($this->environmentApplied);
        }
    }

    private function initialize(): void
    {
        $builder = new ContainerBuilder();
        $builder->useAutowiring(true);
        $builder->useAnnotations(true);

        if ($this->registerDefaultServices) {
            $builder->addDefinitions(DefaultContainerServices::definitions());
        }

        foreach ($this->staticEntries as $entries) {
            $builder->addDefinitions($entries);
        }

        foreach (array_keys($this->environmentEntries) as $index) {
            $source = new DefinitionArray();
            $this->environmentEntries[$index]['source'] = $source;
            $builder->addDefinitions($source);
        }

        $this->container = $builder->build();
        $this->environmentApplied = false;
    }

    private function dispatchEvent(object $event): void
    {
        if ($this->container->has(PsrEventDispatcherInterface::class)) {
            $this->ensureEnvironmentIsApplied();
            $eventDispatcher = $this->container->get(PsrEventDispatcherInterface::class);
            assert($eventDispatcher instanceof PsrEventDispatcherInterface);
            $eventDispatcher->dispatch($event);
        }
    }

    /**
     * @return ApplicationContextBuilder<self>
     */
    public static function builder(bool $registerDefaultServices = true): ApplicationContextBuilder
    {
        return new ApplicationContextBuilder(
            self::class,
            function (
                array $staticEntriesFiles,
                array $environmentEntriesFiles
            ) use (
                $registerDefaultServices
            ): self {
                return new self(
                    $staticEntriesFiles,
                    $environmentEntriesFiles,
                    $registerDefaultServices,
                );
            },
        );
    }
}
