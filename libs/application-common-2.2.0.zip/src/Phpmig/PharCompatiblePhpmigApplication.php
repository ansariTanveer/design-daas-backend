<?php

declare(strict_types=1);

namespace Application\Common\Phpmig;

use ArrayAccess;
use BadMethodCallException;
use Phpmig\Api\PhpmigApplication;
use Symfony\Component\Console\Output\OutputInterface;

final class PharCompatiblePhpmigApplication extends PhpmigApplication
{
    /**
     * @param ArrayAccess<string, mixed> $container
     * @param OutputInterface $output
     */
    public function __construct(ArrayAccess $container, OutputInterface $output)
    {
        /*
         * Ugly hack because Phpmig uses realpath() to "validate" migrations and that does not work
         * when the migrations are part of a PHAR file :(
         */

        $migrations = [];
        if (isset($container['phpmig.migrations'])) {
            if (is_array($container['phpmig.migrations'])) {
                $migrations = $container['phpmig.migrations'];
            }
            unset($container['phpmig.migrations']);
        }

        $migrationsPath = '';
        if (isset($container['phpmig.migrations_path'])) {
            assert(is_scalar($container['phpmig.migrations_path']));
            $migrationsPath = (string)$container['phpmig.migrations_path'];
            unset($container['phpmig.migrations_path']);
        }

        parent::__construct($container, $output);

        if (strlen($migrationsPath) > 0) {
            $migrations = array_merge(
                array_values($migrations),
                array_values(
                    array_filter(
                        array_map(
                            function ($file) use ($migrationsPath): string {
                                return $migrationsPath . '/' . $file;
                            },
                            (array)scandir($migrationsPath),
                        ),
                        function ($file) {
                            return is_file($file) && substr($file, -4, 4) === '.php';
                        },
                    ),
                ),
            );
        }

        $this->migrations = $migrations;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }
}
