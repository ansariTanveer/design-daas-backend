<?php

declare(strict_types=1);

namespace Application\Common\DoctrineDBAL;

use BadMethodCallException;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;

final class DatabaseConnectionFactory implements DatabaseConnectionFactoryInterface
{
    private ?string $dsn;

    private ConnectionPreparerInterface $connectionPreparer;

    public function __construct(?string $dsn, ConnectionPreparerInterface $connectionPreparer = null)
    {
        $this->dsn = $dsn;
        $this->connectionPreparer = $connectionPreparer ?? new NullConnectionPreparer();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function build(): Connection
    {
        $connection = DriverManager::getConnection(
            $this->connectionPreparer->prepareParams(
                [
                    'url' => $this->dsn,
                ],
            ),
            $this->connectionPreparer->prepareConfiguration(),
            $this->connectionPreparer->prepareEventManager(),
        );

        $this->connectionPreparer->prepareConnection($connection);

        return $connection;
    }
}
