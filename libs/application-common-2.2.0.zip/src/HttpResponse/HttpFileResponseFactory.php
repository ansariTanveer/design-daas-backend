<?php

declare(strict_types=1);

namespace Application\Common\HttpResponse;

use BadMethodCallException;
use LogicException;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\StreamFactoryInterface;

final class HttpFileResponseFactory
{
    private ResponseFactoryInterface $responseFactory;

    private StreamFactoryInterface $streamFactory;

    public function __construct(ResponseFactoryInterface $responseFactory, StreamFactoryInterface $streamFactory)
    {
        $this->responseFactory = $responseFactory;
        $this->streamFactory = $streamFactory;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildFromString(
        ServerRequestInterface $request,
        string $contents,
        ?string $mime = null,
        ?int $modificationTime = null
    ): ResponseInterface {
        $body = $this->streamFactory->createStream($contents);
        $size = strlen($contents);
        $sha1 = sha1($contents);

        return (new HttpFileResponseBuilder($this->responseFactory, $request, $body))
            ->withMime($mime)
            ->withSize($size)
            ->withETag($sha1 . '@' . $size)
            ->withModificationTime($modificationTime)
            ->build();
    }

    public function buildFromFile(
        ServerRequestInterface $request,
        string $filename,
        ?string $mime = null
    ): ResponseInterface {
        /*
         * The file must exist and be readable because this method will not generate an HTTP 404 response automatically
         */
        if (!is_file($filename) || !is_readable($filename)) {
            $msg = 'Specified filename is not a file or is not readable: %1$s';
            throw new LogicException(
                sprintf(
                    $msg,
                    $filename,
                ),
            );
        }

        if ($mime === null) {
            $mime = $this->detectMimeType($filename);
        }

        $body = $this->streamFactory->createStreamFromFile($filename);

        $size = filesize($filename);
        assert($size !== false);

        $sha1 = sha1_file($filename);
        assert($sha1 !== false);

        $modificationTime = filemtime($filename);
        assert($modificationTime !== false);

        return (new HttpFileResponseBuilder($this->responseFactory, $request, $body))
            ->withMime($mime)
            ->withSize($size)
            ->withETag($sha1 . '@' . $size)
            ->withModificationTime($modificationTime)
            ->build();
    }

    private function detectMimeType(string $filename): string
    {
        $staticMimeTypes = [
            'css' => 'text/css',
            'js' => 'text/javascript',
            'json' => 'application/json',
            'html' => 'text/html',
        ];

        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        if (array_key_exists($extension, $staticMimeTypes)) {
            $mime = $staticMimeTypes[$extension];
        } else {
            $finfo = finfo_open(FILEINFO_MIME);
            assert($finfo !== false);
            $mime = finfo_file($finfo, $filename);
            assert($mime !== false);
            finfo_close($finfo);
        }

        return $mime;
    }
}
