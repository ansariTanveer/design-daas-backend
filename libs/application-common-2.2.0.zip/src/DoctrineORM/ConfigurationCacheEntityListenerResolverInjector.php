<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use Doctrine\ORM\Configuration;
use Doctrine\ORM\Mapping\EntityListenerResolver;

final class ConfigurationCacheEntityListenerResolverInjector implements ConfigurationCacheInterface
{
    private ConfigurationCacheInterface $parent;

    private EntityListenerResolver $resolver;

    public function __construct(ConfigurationCacheInterface $parent, EntityListenerResolver $resolver)
    {
        $this->parent = $parent;
        $this->resolver = $resolver;
    }

    public function buildCache(): void
    {
        $this->parent->buildCache();
    }

    public function loadConfiguration(): Configuration
    {
        $configuration = $this->parent->loadConfiguration();
        $configuration->setEntityListenerResolver($this->resolver);
        return $configuration;
    }
}
