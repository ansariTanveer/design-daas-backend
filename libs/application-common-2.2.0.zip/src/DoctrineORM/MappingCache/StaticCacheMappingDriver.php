<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM\MappingCache;

use Doctrine\Persistence\Mapping\ClassMetadata;
use Doctrine\Persistence\Mapping\Driver\MappingDriver;
use Doctrine\Persistence\Mapping\MappingException;
use RuntimeException;

/**
 * @internal
 */
final class StaticCacheMappingDriver implements MappingDriver
{
    private const TRANSIENT = 't';

    /**
     * @var array<class-string, array{t: bool}>
     */
    private array $classData = [];

    public function __construct(MappingDriver $sourceDriver)
    {
        foreach ($sourceDriver->getAllClassNames() as $className) {
            $this->classData[$className] = [
                self::TRANSIENT => $sourceDriver->isTransient($className),
            ];
        }
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * @return array{classData: array<class-string, array{t: bool}>}
     */
    public function __serialize(): array
    {
        return [
            'classData' => $this->classData,
        ];
    }

    /**
     * @param array{classData: array<class-string, array{t: bool}>} $data
     */
    public function __unserialize(array $data): void
    {
        $this->classData = $data['classData'];
    }

    public function loadMetadataForClass($className, ClassMetadata $metadata)
    {
        /*
         * Metadata for unknown classes cannot be loaded
         */
        if (!array_key_exists($className, $this->classData)) {
            throw new MappingException(
                sprintf(
                    'Unknown entity class: %1$s',
                    $className,
                ),
            );
        }

        /*
         * Metadata for known classes must never be loaded during runtime, it should be present in the cache
         */
        throw new RuntimeException(
            sprintf(
                'Cannot load metadata for class during runtime: %1$s',
                static::class,
            ),
        );
    }

    public function getAllClassNames(): array
    {
        return array_keys($this->classData);
    }

    public function isTransient($className): bool
    {
        return array_key_exists($className, $this->classData) ?
            $this->classData[$className][self::TRANSIENT] :
            true;
    }
}
