<?php

namespace Application\Common\DoctrineORM;

use Doctrine\ORM\Mapping\EntityListenerResolver;
use InvalidArgumentException;
use Psr\Container\ContainerInterface;

final class ContainerAwareEntityListenerResolver implements EntityListenerResolver
{
    private ContainerInterface $container;

    /**
     * @var array<class-string, object>
     */
    private array $instances = [];

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function clear($className = null)
    {
        if ($className === null) {
            $this->instances = [];
            return;
        }

        $className = trim($className, '\\');
        if (isset($this->instances[$className])) {
            unset($this->instances[$className]);
        }
    }

    public function register($object)
    {
        if (!is_object($object)) {
            throw new InvalidArgumentException(sprintf('An object was expected, but got "%s".', gettype($object)));
        }

        $this->instances[get_class($object)] = $object;
    }

    public function resolve($className)
    {
        $className = trim($className, '\\');
        if (isset($this->instances[$className])) {
            return $this->instances[$className];
        }

        $object = $this->container->get($className);
        assert(is_object($object));
        return $object;
    }
}
