<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use BadMethodCallException;
use Doctrine\DBAL\DriverManager;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Query\ResultSetMapping;

final class LazyEntityManager implements ResettableEntityManagerInterface
{
    private DatabaseConnectionFactoryInterface $connectionFactory;

    private ConfigurationCacheInterface $configurationCache;

    private ?EntityManagerInterface $instance = null;

    private bool $fullyInitialized = false;

    public function __construct(
        DatabaseConnectionFactoryInterface $connectionFactory,
        ConfigurationCacheInterface $configurationCache
    ) {
        $this->connectionFactory = $connectionFactory;
        $this->configurationCache = $configurationCache;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    private function init(bool $fullyInitialize = true): void
    {
        // only need partly initialized entity manager and any instance is available
        if ($fullyInitialize !== true && $this->instance !== null) {
            return;
        }

        // need fully initialized entity manager and such an instance is available
        if ($fullyInitialize === true && $this->instance !== null && $this->fullyInitialized === true) {
            return;
        }

        $connection = $fullyInitialize === true ?
            $this->connectionFactory->build() :
            DriverManager::getConnection(['url' => 'sqlite:///:memory:']);

        $this->reset();
        $this->instance = EntityManager::create(
            $connection,
            $this->configurationCache->loadConfiguration(),
        );
        $this->fullyInitialized = $fullyInitialize;
    }

    public function getCache()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getCache();
    }

    public function getConnection()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getConnection();
    }

    public function getExpressionBuilder()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->beginTransaction();
    }

    public function transactional($func)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->transactional($func);
    }

    public function wrapInTransaction($func)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->commit();
    }

    public function rollback()
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->rollback();
    }

    public function createQuery($dql = '')
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->createNamedQuery($name);
    }

    public function createNativeQuery($sql, ResultSetMapping $rsm)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->createQueryBuilder();
    }

    public function getReference($entityName, $id)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getPartialReference($entityName, $identifier);
    }

    public function close()
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->close();
    }

    public function copy($entity, $deep = false)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->lock($entity, $lockMode, $lockVersion);
    }

    public function getEventManager()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getEventManager();
    }

    public function getConfiguration()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getConfiguration();
    }

    public function isOpen()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getProxyFactory();
    }

    public function getFilters()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->hasFilters();
    }

    public function find($className, $id)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->find($className, $id);
    }

    public function persist($object)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->persist($object);
    }

    public function remove($object)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->remove($object);
    }

    public function merge($object)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->merge($object);
    }

    public function clear($objectName = null)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->clear($objectName);
    }

    public function detach($object)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->detach($object);
    }

    public function refresh($object)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->refresh($object);
    }

    public function flush()
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->flush();
    }

    public function getRepository($className)
    {
        $this->init(false);
        assert($this->instance !== null);
        return $this->instance->getRepository($className);
    }

    public function getMetadataFactory()
    {
        $this->init(false);
        assert($this->instance !== null);
        return $this->instance->getMetadataFactory();
    }

    public function initializeObject($obj)
    {
        $this->init();
        assert($this->instance !== null);
        $this->instance->initializeObject($obj);
    }

    public function contains($object)
    {
        $this->init();
        assert($this->instance !== null);
        return $this->instance->contains($object);
    }

    public function getClassMetadata($className)
    {
        $this->init(false);
        assert($this->instance !== null);
        return $this->instance->getClassMetadata($className);
    }

    public function reset(): void
    {
        if ($this->instance !== null) {
            $this->instance->close();
        }
        $this->instance = null;
        $this->fullyInitialized = false;
    }
}
