<?php

declare(strict_types=1);

namespace Application\Common\HttpMiddleware;

use BadMethodCallException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\StreamFactoryInterface;

final class RemoveBodyFromHeadResponsesMiddleware
{
    private StreamFactoryInterface $streamFactory;

    public function __construct(StreamFactoryInterface $streamFactory)
    {
        $this->streamFactory = $streamFactory;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface
    {
        /** @var ResponseInterface $response */
        $response = $next($request);

        /*
         * Responses to HEAD requests should not have a response body:
         *     https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD
         */
        if ($request->getMethod() === 'HEAD' && $response->getBody()->getSize() !== 0) {
            $response = $response->withBody($this->streamFactory->createStream());
        }

        return $response;
    }
}
