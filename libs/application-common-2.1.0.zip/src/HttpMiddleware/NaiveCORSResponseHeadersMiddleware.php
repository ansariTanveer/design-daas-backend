<?php

declare(strict_types=1);

namespace Application\Common\HttpMiddleware;

use BadMethodCallException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final class NaiveCORSResponseHeadersMiddleware
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface
    {
        /** @var ResponseInterface $response */
        $response = $next($request);

        $addAllowOriginHeader = $request->hasHeader('Origin') &&
            !$response->hasHeader('Access-Control-Allow-Origin');
        if ($addAllowOriginHeader) {
            $response = $response->withHeader(
                'Access-Control-Allow-Origin',
                $request->getHeaderLine('Origin')
            );
        } elseif (!$response->hasHeader('Access-Control-Allow-Origin')) {
            $response = $response->withHeader(
                'Access-Control-Allow-Origin',
                '*'
            );
        }

        if ($request->getMethod() !== 'OPTIONS') {
            return $response;
        }

        $addAllowMethodsHeader = $request->hasHeader('Access-Control-Request-Method') &&
            !$response->hasHeader('Access-Control-Allow-Methods');
        if ($addAllowMethodsHeader) {
            $response = $response->withHeader(
                'Access-Control-Allow-Methods',
                $request->getHeaderLine('Access-Control-Request-Method')
            );
        }

        $addAllowHeadersHeader = $request->hasHeader('Access-Control-Request-Headers') &&
            !$response->hasHeader('Access-Control-Allow-Headers');
        if ($addAllowHeadersHeader) {
            $response = $response->withHeader(
                'Access-Control-Allow-Headers',
                $request->getHeaderLine('Access-Control-Request-Headers')
            );
        }

        return $response;
    }
}
