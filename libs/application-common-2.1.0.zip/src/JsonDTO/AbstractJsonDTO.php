<?php

declare(strict_types=1);

namespace Application\Common\JsonDTO;

use BadMethodCallException;
use JsonSerializable;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use ReflectionClass;
use ReflectionProperty;
use stdClass;

abstract class AbstractJsonDTO implements JsonSerializable
{
    final public function __construct()
    {
        foreach (self::relevantProperties($this) as $property) {
            $name = $property->getName();
            /*
             * Properties without specified type are initialized with null by default,
             * calling unset() resets the property so \ReflectionProperty::isInitialized() returns false
             */
            unset($this->{$name}); // @phpstan-ignore-line
        }
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @param stdClass $json
     * @return static
     */
    public static function fromJson(stdClass $json): self
    {
        $dto = new static();
        foreach (self::relevantProperties($dto) as $property) {
            $name = $property->getName();
            if (property_exists($json, $name)) {
                /*
                 * Map all properties that exist in the $dto and $json from the $json into the $dto,
                 * type checks are deliberately omitted and a type mismatch will cause a PHP error/crash
                 */
                $property->setValue($dto, static::convertValueFromJson($name, $json->{$name}));
            }
        }
        return $dto;
    }

    /**
     * @param ServerRequestInterface $request
     * @return static
     */
    public static function fromRequest(ServerRequestInterface $request): self
    {
        $json = json_decode((string)$request->getBody());
        assert($json instanceof stdClass);
        return static::fromJson($json);
    }

    /**
     * @param ResponseInterface $response
     * @return static
     */
    public static function fromResponse(ResponseInterface $response): self
    {
        $json = json_decode((string)$response->getBody());
        assert($json instanceof stdClass);
        return static::fromJson($json);
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    protected static function convertValueFromJson(string $name, $value)
    {
        return $value;
    }

    #[\ReturnTypeWillChange]
    public function jsonSerialize()
    {
        $data = [];
        foreach (self::relevantProperties($this) as $property) {
            $name = $property->getName();
            if ($property->isInitialized($this)) {
                /*
                 * Only initialized values are returned to be included in the JSON, this allows
                 * to differentiate between null values and properties that are not set at all
                 */
                $data[$name] = $property->getValue($this);
            }
        }
        return $data;
    }

    public function hasProperty(string $name): bool
    {
        $property = new ReflectionProperty($this, $name);
        return $property->isPublic() &&
            !$property->isStatic() &&
            $property->isInitialized($this);
    }

    /**
     * @param self $dto
     * @return ReflectionProperty[]
     */
    private static function relevantProperties(self $dto): array
    {
        $reflectionClass = new ReflectionClass($dto);
        return array_filter(
            $reflectionClass->getProperties(),
            function (ReflectionProperty $property): bool {
                return $property->isPublic() && !$property->isStatic();
            }
        );
    }
}
