<?php

declare(strict_types=1);

namespace Application\Common;

final class PhpIniValueConverter
{
    /**
     * Private constructor.
     *
     * @codeCoverageIgnore
     */
    private function __construct()
    {
    }

    /**
     * @noinspection PhpMissingBreakStatementInspection
     */
    public static function convertShorthandByteValue(string $value): int
    {
        $value = trim($value);
        if (is_numeric($value)) {
            return (int)$value;
        }

        $last = strtolower(substr($value, -1));
        /** @var int $value */
        $value = substr($value, 0, -1);

        switch ($last) {
            case 'g':
                $value *= 1024;
            // fall-through
            case 'm':
                $value *= 1024;
            // fall-through
            case 'k':
                $value *= 1024;
        }

        return $value;
    }
}
