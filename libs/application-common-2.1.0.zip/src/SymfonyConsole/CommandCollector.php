<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole;

use BadMethodCallException;
use Consolidation\AnnotatedCommand\CommandFileDiscovery;

final class CommandCollector implements CommandCollectorInterface
{
    private const PATH = 'path';
    private const NAMESPACE = 'namespace';
    private const PATTERN = 'pattern';

    /**
     * @var array<array{path: string, namespace: string, pattern: string}>
     */
    private array $search = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function addSearchPath(string $path, string $baseNamespace, string $pattern): void
    {
        $this->search[] = [
            self::PATH => $path,
            self::NAMESPACE => $baseNamespace,
            self::PATTERN => $pattern,
        ];
    }

    public function collectCommandClassNames(): array
    {
        $classNames = [];
        foreach ($this->search as $search) {
            $commandDiscovery = new CommandFileDiscovery();
            $commandDiscovery->setSearchPattern($search[self::PATTERN]);
            $commandDiscovery->setSearchLocations([]);
            $commandDiscovery->setExcludeList([]);
            $additionalClassNames = $commandDiscovery->discover($search[self::PATH], $search[self::NAMESPACE]);
            foreach ($additionalClassNames as $className) {
                $classNames[] = $className;
            }
        }
        return $classNames;
    }
}
