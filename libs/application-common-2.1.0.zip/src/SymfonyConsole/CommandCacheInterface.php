<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole;

use Consolidation\AnnotatedCommand\AnnotatedCommand;
use Psr\Container\ContainerInterface;

interface CommandCacheInterface
{
    public function buildCache(): void;

    /**
     * @param ContainerInterface $container
     * @return AnnotatedCommand[]
     */
    public function loadCommandList(ContainerInterface $container): array;
}
