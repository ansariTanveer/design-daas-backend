<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole;

use BadMethodCallException;
use Symfony\Component\Console\Formatter\OutputFormatterInterface;
use Symfony\Component\Console\Output\ConsoleOutputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class ConsoleOutput implements OutputInterface
{
    private OutputInterface $stdOut;

    private OutputInterface $stdErr;

    public function __construct(OutputInterface $stdOut, OutputInterface $stdErr)
    {
        $this->stdOut = $stdOut;
        $this->stdErr = $stdErr;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public static function wrapOutput(OutputInterface $output): self
    {
        if ($output instanceof self) {
            return $output;
        }

        if ($output instanceof ConsoleOutputInterface) {
            return new self($output, $output->getErrorOutput());
        }

        return new self($output, $output);
    }

    public function write($messages, bool $newline = false, int $options = 0): void
    {
        $this->stdOut->write($messages, $newline, $options);
    }

    public function writeln($messages, int $options = 0): void
    {
        $this->stdOut->writeln($messages, $options);
    }

    public function setVerbosity(int $level): void
    {
        $this->stdOut->setVerbosity($level);
        $this->stdErr->setVerbosity($level);
    }

    public function getVerbosity(): int
    {
        return $this->stdOut->getVerbosity();
    }

    public function isQuiet(): bool
    {
        return $this->stdOut->isQuiet();
    }

    public function isVerbose(): bool
    {
        return $this->stdOut->isVerbose();
    }

    public function isVeryVerbose(): bool
    {
        return $this->stdOut->isVeryVerbose();
    }

    public function isDebug(): bool
    {
        return $this->stdOut->isDebug();
    }

    public function setDecorated(bool $decorated): void
    {
        $this->stdOut->setDecorated($decorated);
        $this->stdErr->setDecorated($decorated);
    }

    public function isDecorated(): bool
    {
        return $this->stdOut->isDecorated();
    }

    public function setFormatter(OutputFormatterInterface $formatter): void
    {
        $this->stdOut->setFormatter($formatter);
        $this->stdErr->setFormatter($formatter);
    }

    public function getFormatter(): OutputFormatterInterface
    {
        return $this->stdOut->getFormatter();
    }

    public function stdOut(): OutputInterface
    {
        return $this->stdOut;
    }

    public function stdErr(): OutputInterface
    {
        return $this->stdErr;
    }
}
