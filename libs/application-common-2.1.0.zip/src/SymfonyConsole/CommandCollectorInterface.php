<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole;

interface CommandCollectorInterface
{
    public function addSearchPath(string $path, string $baseNamespace, string $pattern): void;

    /**
     * @return class-string[]
     */
    public function collectCommandClassNames(): array;
}
