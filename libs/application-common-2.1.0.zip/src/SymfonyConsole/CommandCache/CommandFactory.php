<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole\CommandCache;

use BadMethodCallException;
use Consolidation\AnnotatedCommand\AnnotatedCommandFactory;
use Consolidation\AnnotatedCommand\Cache\SimpleCacheInterface;
use Consolidation\AnnotatedCommand\Parser\CommandInfo;
use Consolidation\OutputFormatters\FormatterManager;
use Psr\Container\ContainerInterface;

/**
 * @internal
 */
final class CommandFactory extends AnnotatedCommandFactory
{
    private ?ContainerInterface $container;

    public function __construct(SimpleCacheInterface $dataStore, ?ContainerInterface $container)
    {
        parent::__construct();

        $this->setDataStore($dataStore);
        $this->container = $container;

        $this->setIncludeAllPublicMethods(false);
        $this->commandProcessor()->setPassExceptions(true);
        $this->commandProcessor()->setFormatterManager(new FormatterManager());
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function createCommand(CommandInfo $commandInfo, $commandFileInstance)
    {
        /** @var class-string $commandClassName */
        $commandClassName = get_class($commandFileInstance);
        $commandMethodName = $commandInfo->getMethodName();
        $commandInfo->addAnnotation('_commandClass', $commandClassName);
        $commandInfo->addAnnotation('_commandMethod', $commandMethodName);
        $commandCallback = function () use ($commandClassName, $commandMethodName) {
            assert($this->container !== null);
            $commandClass = $this->container->get($commandClassName);
            /** @var callable $commandCallback */
            $commandCallback = [$commandClass, $commandMethodName];
            return call_user_func_array($commandCallback, func_get_args());
        };

        $command = parent::createCommand($commandInfo, $commandFileInstance);
        $command->setCommandCallback($commandCallback);
        return $command;
    }
}
