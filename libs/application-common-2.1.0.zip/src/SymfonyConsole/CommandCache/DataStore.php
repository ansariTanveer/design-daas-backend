<?php

declare(strict_types=1);

namespace Application\Common\SymfonyConsole\CommandCache;

use Consolidation\AnnotatedCommand\Cache\SimpleCacheInterface;

/**
 * @internal
 */
final class DataStore implements SimpleCacheInterface
{
    /**
     * @var array<string, array{}>
     */
    private array $dataStore = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * @return array{dataStore: array<string, array{}>}
     */
    public function __serialize(): array
    {
        return [
            'dataStore' => $this->dataStore,
        ];
    }

    /**
     * @param array{dataStore: array<string, array{}>} $data
     */
    public function __unserialize(array $data): void
    {
        $this->dataStore = $data['dataStore'];
    }

    public function has($key)
    {
        assert(is_string($key));
        return array_key_exists($key, $this->dataStore);
    }

    public function get($key)
    {
        assert(is_string($key));
        if (!$this->has($key)) {
            return [];
        }
        return $this->dataStore[$key];
    }

    public function set($key, $data)
    {
        assert(is_string($key));
        assert(is_array($data));
        $this->dataStore[$key] = $data;
    }

    /**
     * @return string[]
     */
    public function keys(): array
    {
        return array_keys($this->dataStore);
    }
}
