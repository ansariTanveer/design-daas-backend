<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use BadMethodCallException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Component\Routing\Exception\MethodNotAllowedException;

final class MethodNotAllowedEvent
{
    private ServerRequestInterface $request;

    private MethodNotAllowedException $exception;

    private ?ResponseInterface $response = null;

    public function __construct(
        ServerRequestInterface $request,
        MethodNotAllowedException $exception
    ) {
        $this->request = $request;
        $this->exception = $exception;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function request(): ServerRequestInterface
    {
        return $this->request;
    }

    public function exception(): MethodNotAllowedException
    {
        return $this->exception;
    }

    public function response(): ?ResponseInterface
    {
        return $this->response;
    }

    public function setResponse(?ResponseInterface $response): void
    {
        $this->response = $response;
    }
}
