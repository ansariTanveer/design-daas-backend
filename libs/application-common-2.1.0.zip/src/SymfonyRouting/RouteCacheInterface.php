<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use Symfony\Component\Routing\RouteCollection;

interface RouteCacheInterface
{
    public function buildCache(): void;

    public function loadRouteCollection(): RouteCollection;
}
