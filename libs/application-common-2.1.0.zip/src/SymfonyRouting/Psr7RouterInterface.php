<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;

interface Psr7RouterInterface extends MiddlewareInterface
{
    public function routeNameAttribute(): string;

    public function routeParametersAttribute(): string;

    public function routeOptionsAttribute(): string;

    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface;
}
