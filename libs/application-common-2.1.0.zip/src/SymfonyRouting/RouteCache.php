<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use BadMethodCallException;
use Symfony\Component\Routing\Route;
use Symfony\Component\Routing\RouteCollection;

final class RouteCache implements RouteCacheInterface
{
    private RouteCollectorInterface $collector;

    private ?string $cacheFile;

    private ?RouteCollection $inMemoryCache = null;

    public function __construct(RouteCollectorInterface $collector, ?string $cacheFile)
    {
        $this->collector = $collector;
        $this->cacheFile = $cacheFile;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildCache(): void
    {
        if (!$this->useCache()) {
            return;
        }
        $routes = $this->buildRoutes();
        assert($this->cacheFile !== null);
        file_put_contents($this->cacheFile, serialize($routes));
    }

    private function useCache(): bool
    {
        return $this->cacheFile !== null;
    }

    public function loadRouteCollection(): RouteCollection
    {
        if ($this->inMemoryCache === null) {
            if ($this->useCache()) {
                assert($this->cacheFile !== null);
                $serializedRoutes = file_get_contents($this->cacheFile);
                assert($serializedRoutes !== false);
                /** @psalm-var Route[] $routes */
                $routes = unserialize($serializedRoutes);
            } else {
                $routes = $this->buildRoutes();
            }
            $this->inMemoryCache = new RouteCollection();
            foreach ($routes as $name => $route) {
                $this->inMemoryCache->add($name, $route);
            }
        }
        return $this->inMemoryCache;
    }

    /**
     * Returns route names as keys and route objects as values.
     *
     * @return array<string, Route>
     */
    private function buildRoutes(): array
    {
        return $this->collector->collectRoutes()->all();
    }
}
