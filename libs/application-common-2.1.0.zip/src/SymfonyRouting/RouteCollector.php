<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use Application\Common\SymfonyRouting\RouteCache\ControllerClassLoader;
use BadMethodCallException;
use Doctrine\Common\Annotations\AnnotationReader;
use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\Finder\Iterator\FilenameFilterIterator;
use Symfony\Component\Routing\Loader\AnnotationFileLoader;
use Symfony\Component\Routing\RouteCollection;

final class RouteCollector implements RouteCollectorInterface
{
    private const PATH = 'path';
    private const PATTERN = 'pattern';

    /**
     * @var array<array{path: string, pattern: string}>
     */
    private array $search = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function addSearchPath(string $path, string $pattern): void
    {
        $this->search[] = [
            self::PATH => $path,
            self::PATTERN => $pattern,
        ];
    }

    public function collectRoutes(): RouteCollection
    {
        $loader = new AnnotationFileLoader(
            new FileLocator(),
            new ControllerClassLoader(new AnnotationReader())
        );
        $collection = new RouteCollection();
        foreach ($this->search as $search) {
            $directoryContents = new RecursiveDirectoryIterator(
                $search[self::PATH],
                FilesystemIterator::SKIP_DOTS | FilesystemIterator::FOLLOW_SYMLINKS
            );
            $onlyLeafNodes = new RecursiveIteratorIterator(
                $directoryContents,
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            $filterControllerFiles = new FilenameFilterIterator(
                $onlyLeafNodes,
                [$search[self::PATTERN]],
                []
            );
            /** @var array<SplFileInfo|string> $files */
            $files = iterator_to_array($filterControllerFiles);
            foreach ($files as $file) {
                $innerCollection = $loader->load((string)$file);
                assert($innerCollection !== null);
                $collection->addCollection($innerCollection);
            }
        }
        return $collection;
    }
}
