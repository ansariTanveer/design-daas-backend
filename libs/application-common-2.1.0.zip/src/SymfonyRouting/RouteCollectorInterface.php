<?php

declare(strict_types=1);

namespace Application\Common\SymfonyRouting;

use Symfony\Component\Routing\RouteCollection;

interface RouteCollectorInterface
{
    public function addSearchPath(string $path, string $pattern): void;

    public function collectRoutes(): RouteCollection;
}
