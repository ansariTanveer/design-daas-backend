<?php

declare(strict_types=1);

namespace Application\Common\GuzzleHttpClient;

use BadMethodCallException;
use GuzzleHttp\Client;
use GuzzleHttp\HandlerStack;
use LogicException;

final class HttpClientFactory
{
    private HandlerStack $handler;

    public function __construct(HandlerStack $handler)
    {
        $this->handler = $handler;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * Build a client using the specified configuration.
     *
     * The factory will build the client using the preconfigured handler stack, passing in
     * a configuration that includes the "handler" key is not allowed.
     *
     * @param array<string, mixed> $config
     * @return Client
     */
    public function build(array $config = []): Client
    {
        if (array_key_exists('handler', $config)) {
            throw new LogicException('Not allowed to specify custom handler stack when building HTTP client');
        }
        $config['handler'] = $this->handler;
        return new Client($config);
    }
}
