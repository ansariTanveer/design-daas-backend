<?php

declare(strict_types=1);

namespace Application\Common\InternalMessageBroker;

use BadMethodCallException;
use Closure;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\EntityManagerInterface;
use Enqueue\Dbal\DbalConsumer;
use Enqueue\Dbal\DbalContext;
use Enqueue\Dbal\DbalMessage;
use LogicException;

final class DbalInternalMessageBroker implements InternalMessageBrokerInterface
{
    private DbalContext $context;

    public function __construct(DbalContext $context)
    {
        $this->context = $context;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public static function fromConnection(string $tableName, Connection $connection): self
    {
        return new self(
            new DbalContext(
                function () use ($connection): Connection {
                    return $connection;
                },
                [
                    'table_name' => $tableName,
                ]
            )
        );
    }

    public static function fromEntityManager(string $tableName, EntityManagerInterface $em): self
    {
        return new self(
            new DbalContext(
                function () use ($em): Connection {
                    return $em->getConnection();
                },
                [
                    'table_name' => $tableName,
                ]
            )
        );
    }

    public function sendMessage(string $queue, string $message, int $delayInMs = 0): void
    {
        if ($delayInMs < 0) {
            throw new LogicException(
                sprintf(
                    '$delayInMs must be at least 0, actual value: %1$s',
                    $delayInMs
                )
            );
        }

        $destination = $this->context->createQueue($queue);
        $message = $this->context->createMessage($message);
        assert($message instanceof DbalMessage);
        if ($delayInMs > 0) {
            $message->setDeliveryDelay($delayInMs);
        }

        $this->context->createProducer()->send($destination, $message);
    }

    public function receiveMessages(
        string $queue,
        Closure $processor,
        int $timeoutInMs = 0,
        int $redeliveryDelayInMs = 300000
    ): void {
        /** @var Closure(string): ProcessingResult $processor */

        if ($timeoutInMs < 0) {
            throw new LogicException(
                sprintf(
                    '$timeoutInMs must be at least 0, actual value: %1$s',
                    $timeoutInMs
                )
            );
        }
        if ($redeliveryDelayInMs < 0) {
            throw new LogicException(
                sprintf(
                    '$redeliveryDelayInMs must be at least 0, actual value: %1$s',
                    $redeliveryDelayInMs
                )
            );
        }

        $destination = $this->context->createQueue($queue);
        $consumer = $this->context->createConsumer($destination);
        $consumer->setRedeliveryDelay($redeliveryDelayInMs);
        $subscriptionConsumer = $this->context->createSubscriptionConsumer();

        $subscriptionConsumer->subscribe(
            $consumer,
            function (DbalMessage $message, DbalConsumer $consumer) use ($processor): bool {
                $result = $processor($message->getBody());
                if ($result->acknowledgeMessage()) {
                    $consumer->acknowledge($message);
                } else {
                    $message->setDeliveryDelay($result->redeliverMessageAfterMs());
                    $consumer->reject($message, $result->redeliverMessage());
                }
                return $result->continueProcessing();
            }
        );

        $subscriptionConsumer->consume($timeoutInMs);
    }
}
