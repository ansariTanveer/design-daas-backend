<?php

declare(strict_types=1);

namespace Application\Common\InternalMessageBroker;

use BadMethodCallException;
use LogicException;

final class ProcessingResult
{
    private bool $acknowledge;

    private ?int $redeliverAfterMs;

    private bool $continueProcessing;

    public function __construct(bool $acknowledge, ?int $redeliverAfterMs, bool $continueProcessing)
    {
        if ($acknowledge && $redeliverAfterMs !== null) {
            throw new LogicException(
                sprintf(
                    'Acknowledged messages cannot be redelivered, $redeliverAfterMs must be null, actual value: %1$s',
                    $redeliverAfterMs
                )
            );
        }

        if ($redeliverAfterMs !== null && $redeliverAfterMs < 0) {
            throw new LogicException(
                sprintf(
                    '$redeliverAfterMs must be null or at least 0, actual value: %1$s',
                    $redeliverAfterMs
                )
            );
        }

        $this->acknowledge = $acknowledge;
        $this->redeliverAfterMs = $redeliverAfterMs;
        $this->continueProcessing = $continueProcessing;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public static function acknowledge(): self
    {
        return new self(true, null, true);
    }

    public static function rejectAndDiscard(): self
    {
        return new self(false, null, true);
    }

    public static function rejectAndRedeliver(int $redeliverAfterMs): self
    {
        return new self(false, $redeliverAfterMs, true);
    }

    public function acknowledgeMessage(): bool
    {
        return $this->acknowledge;
    }

    public function redeliverMessageAfterMs(): ?int
    {
        return $this->redeliverAfterMs;
    }

    public function redeliverMessage(): bool
    {
        return $this->redeliverAfterMs !== null;
    }

    public function continueProcessing(): bool
    {
        return $this->continueProcessing;
    }
}
