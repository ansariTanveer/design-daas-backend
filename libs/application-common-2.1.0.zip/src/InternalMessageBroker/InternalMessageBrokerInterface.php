<?php

declare(strict_types=1);

namespace Application\Common\InternalMessageBroker;

use Closure;

interface InternalMessageBrokerInterface
{
    /**
     * Send a message to the specified queue.
     *
     * By default, the message will be visible to processors immediately ($delayInMs = 0).
     */
    public function sendMessage(string $queue, string $message, int $delayInMs = 0): void;

    /**
     * Receive messages from the specified queue and pass them to the specified callback for processing.
     *
     * By default, messages will be processed infinitely ($timeoutInMs = 0) and in case of crashes a message will
     * be processed again after 5 minutes ($redeliveryDelayInMs = 300000).
     *
     * @param Closure(string): ProcessingResult $processor
     */
    public function receiveMessages(
        string $queue,
        Closure $processor,
        int $timeoutInMs = 0,
        int $redeliveryDelayInMs = 300000
    ): void;
}
