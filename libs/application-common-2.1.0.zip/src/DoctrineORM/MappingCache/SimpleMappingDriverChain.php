<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM\MappingCache;

use BadMethodCallException;
use Doctrine\Persistence\Mapping\ClassMetadata;
use Doctrine\Persistence\Mapping\Driver\MappingDriver;

/**
 * @internal
 */
final class SimpleMappingDriverChain implements MappingDriver
{
    /**
     * @var MappingDriver[]
     */
    private array $chain = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function addDriver(MappingDriver $driver): void
    {
        $this->chain[] = $driver;
    }

    public function loadMetadataForClass($className, ClassMetadata $metadata)
    {
        foreach ($this->chain as $driver) {
            if (in_array($className, $driver->getAllClassNames(), true)) {
                $driver->loadMetadataForClass($className, $metadata);
                return;
            }
        }
    }

    public function getAllClassNames()
    {
        $classNames = [];
        foreach ($this->chain as $driver) {
            $classNames = array_merge($classNames, $driver->getAllClassNames());
        }
        return array_values(array_unique($classNames));
    }

    public function isTransient($className)
    {
        foreach ($this->chain as $driver) {
            if (in_array($className, $driver->getAllClassNames(), true)) {
                return $driver->isTransient($className);
            }
        }
        return true;
    }
}
