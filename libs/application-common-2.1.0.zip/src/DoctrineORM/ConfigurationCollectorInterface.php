<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

interface ConfigurationCollectorInterface
{
    public function addSearchPath(string $path): void;

    /**
     * @return string[]
     */
    public function collectSearchPaths(): array;
}
