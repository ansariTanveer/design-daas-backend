<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use Doctrine\ORM\Configuration;

interface ConfigurationCacheInterface
{
    public function buildCache(): void;

    public function loadConfiguration(): Configuration;
}
