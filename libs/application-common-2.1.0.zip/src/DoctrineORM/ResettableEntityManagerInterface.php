<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Contracts\Service\ResetInterface;

interface ResettableEntityManagerInterface extends EntityManagerInterface, ResetInterface
{
}
