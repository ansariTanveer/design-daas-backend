<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use BadMethodCallException;

final class ConfigurationCollector implements ConfigurationCollectorInterface
{
    private const PATH = 'path';

    /**
     * @var array<array{path: string}>
     */
    private array $search = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function addSearchPath(string $path): void
    {
        $this->search[] = [
            self::PATH => $path,
        ];
    }

    public function collectSearchPaths(): array
    {
        $searchPaths = [];
        foreach ($this->search as $search) {
            $searchPaths[] = $search[self::PATH];
        }
        return $searchPaths;
    }
}
