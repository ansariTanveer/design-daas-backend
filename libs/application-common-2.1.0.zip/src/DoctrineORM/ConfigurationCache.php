<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use Application\Common\DoctrineORM\MappingCache\SimpleMappingDriverChain;
use Application\Common\DoctrineORM\MappingCache\StaticCacheMappingDriver;
use BadMethodCallException;
use Doctrine\Common\Annotations\AnnotationReader;
use Doctrine\Common\Annotations\PsrCachedReader;
use Doctrine\Common\Proxy\AbstractProxyFactory;
use Doctrine\DBAL\DriverManager;
use Doctrine\ORM\Configuration;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Mapping\Driver\AnnotationDriver;
use Doctrine\ORM\Mapping\Driver\AttributeDriver;
use Doctrine\ORM\ORMSetup;
use Doctrine\Persistence\Mapping\Driver\MappingDriver;
use Psr\Cache\CacheItemPoolInterface;
use Symfony\Component\Cache\Adapter\ArrayAdapter;

final class ConfigurationCache implements ConfigurationCacheInterface
{
    private ConfigurationCollectorInterface $configurationCollector;

    private ?string $staticCacheDir;

    private string $cacheFileName;

    private ?Configuration $inMemoryCache = null;

    public function __construct(
        ConfigurationCollectorInterface $configurationCollector,
        ?string $staticCacheDir,
        string $cacheFileName
    ) {
        $this->configurationCollector = $configurationCollector;
        $this->staticCacheDir = $staticCacheDir;
        $this->cacheFileName = $cacheFileName;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildCache(): void
    {
        if (!$this->useCache()) {
            return;
        }
        $configuration = $this->buildConfiguration();
        $em = new EntityManager(
            DriverManager::getConnection(['url' => 'sqlite:///:memory:']),
            $configuration
        );
        // write proxy classes to disk
        $em->getProxyFactory()->generateProxyClasses($em->getMetadataFactory()->getAllMetadata());
        // write filled metadata cache to disk
        $metadataDriverImpl = $configuration->getMetadataDriverImpl();
        assert($metadataDriverImpl instanceof MappingDriver);
        $metadataCache = [
            new StaticCacheMappingDriver($metadataDriverImpl),
            $configuration->getMetadataCache(),
        ];
        file_put_contents($this->cacheFile(), serialize($metadataCache));
    }

    private function useCache(): bool
    {
        return $this->staticCacheDir !== null;
    }

    private function cacheFile(): string
    {
        return sprintf('%1$s/%2$s', $this->staticCacheDir, $this->cacheFileName);
    }

    public function loadConfiguration(): Configuration
    {
        if ($this->inMemoryCache === null) {
            $this->inMemoryCache = $this->buildConfiguration();
            if ($this->useCache()) {
                $serializedMetadataCache = file_get_contents($this->cacheFile());
                assert($serializedMetadataCache !== false);
                /** @psalm-var array{StaticCacheMappingDriver, CacheItemPoolInterface} $metadataCache */
                $metadataCache = unserialize($serializedMetadataCache);
                $this->inMemoryCache->setMetadataDriverImpl(array_shift($metadataCache));
                $this->inMemoryCache->setMetadataCache(array_shift($metadataCache));
                // expect proxy classes on disk and never generate them
                $this->inMemoryCache->setAutoGenerateProxyClasses(AbstractProxyFactory::AUTOGENERATE_NEVER);
            } else {
                // never expect proxy classes on disk or try to write them, just create them in memory using `eval()`
                $this->inMemoryCache->setAutoGenerateProxyClasses(AbstractProxyFactory::AUTOGENERATE_EVAL);
            }
        }
        return $this->inMemoryCache;
    }

    private function buildConfiguration(): Configuration
    {
        // no cache = dev mode
        $isDevMode = !$this->useCache();
        // empty in-memory cache by default, filled metadata cache added later (if present)
        $cache = new ArrayAdapter();

        // support for multiple sources of entity definitions without namespace restrictions
        $chain = new SimpleMappingDriverChain();
        // attributes are supported since PHP 8
        if (PHP_VERSION_ID >= 80000) {
            $chain->addDriver(
                new AttributeDriver(
                    $this->configurationCollector->collectSearchPaths(),
                    true
                )
            );
        }
        // support for legacy annotations
        $chain->addDriver(
            new AnnotationDriver(
                new PsrCachedReader(new AnnotationReader(), $cache),
                $this->configurationCollector->collectSearchPaths(),
                true
            )
        );

        // build and return ORM configuration
        $configuration = ORMSetup::createConfiguration(
            $isDevMode,
            $this->staticCacheDir,
            $cache
        );
        $configuration->setMetadataDriverImpl($chain);
        return $configuration;
    }
}
