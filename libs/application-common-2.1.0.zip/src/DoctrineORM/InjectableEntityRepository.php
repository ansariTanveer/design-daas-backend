<?php

declare(strict_types=1);

namespace Application\Common\DoctrineORM;

use BadMethodCallException;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Mapping\ClassMetadata;
use RuntimeException;

/**
 * @template T of object
 * @psalm-template T of object
 * @extends EntityRepository<T>
 * @template-extends EntityRepository<T>
 */
abstract class InjectableEntityRepository extends EntityRepository
{
    /**
     * @param EntityManagerInterface $em
     * @param ClassMetadata<T>|null $classMetadata
     */
    public function __construct(EntityManagerInterface $em, ?ClassMetadata $classMetadata = null)
    {
        if ($classMetadata === null) {
            foreach ($em->getMetadataFactory()->getAllMetadata() as $metadataCandidate) {
                $matches = $metadataCandidate instanceof ClassMetadata &&
                    static::class === $metadataCandidate->customRepositoryClassName;
                if ($matches) {
                    $classMetadata = $metadataCandidate;
                    break;
                }
            }
            if ($classMetadata === null) {
                throw new RuntimeException(
                    sprintf(
                        'Failed to lookup class metadata for repository: %1$s',
                        static::class
                    )
                );
            }
        }
        parent::__construct($em, $classMetadata);
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @return EntityManagerInterface
     */
    protected function getEntityManager(): EntityManagerInterface
    {
        return parent::getEntityManager();
    }
}
