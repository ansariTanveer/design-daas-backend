<?php

declare(strict_types=1);

namespace Application\Common\Phpmig;

use ArrayAccess;
use BadMethodCallException;
use Phpmig\Api\PhpmigApplication;
use Symfony\Component\Console\Output\OutputInterface;

final class PhpmigApplicationFactory implements PhpmigApplicationFactoryInterface
{
    /**
     * @var ArrayAccess<string, mixed>
     */
    private ArrayAccess $container;

    /**
     * @param ArrayAccess<string, mixed> $container
     */
    public function __construct(ArrayAccess $container)
    {
        $this->container = $container;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function build(OutputInterface $output): PhpmigApplication
    {
        return new PhpmigApplication(
            $this->container,
            $output
        );
    }
}
