<?php

declare(strict_types=1);

namespace Application\Common\Phpmig;

use Phpmig\Api\PhpmigApplication;
use Symfony\Component\Console\Output\OutputInterface;

interface PhpmigApplicationFactoryInterface
{
    public function build(OutputInterface $output): PhpmigApplication;
}
