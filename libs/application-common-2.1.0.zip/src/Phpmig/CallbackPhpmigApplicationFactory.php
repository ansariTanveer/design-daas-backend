<?php

declare(strict_types=1);

namespace Application\Common\Phpmig;

use BadMethodCallException;
use Closure;
use Phpmig\Api\PhpmigApplication;
use Symfony\Component\Console\Output\OutputInterface;

final class CallbackPhpmigApplicationFactory implements PhpmigApplicationFactoryInterface
{
    /**
     * @var Closure(OutputInterface): PhpmigApplication
     */
    private Closure $callback;

    /**
     * @param Closure(OutputInterface): PhpmigApplication $callback
     */
    public function __construct(Closure $callback)
    {
        $this->callback = $callback;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function build(OutputInterface $output): PhpmigApplication
    {
        $application = call_user_func($this->callback, $output);
        assert($application instanceof PhpmigApplication);
        return $application;
    }
}
