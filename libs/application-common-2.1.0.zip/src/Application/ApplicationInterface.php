<?php

declare(strict_types=1);

namespace Application\Common\Application;

use DI\Container;
use Symfony\Contracts\Service\ResetInterface;

interface ApplicationInterface extends ResetInterface
{
    /**
     * Return the applications DI container instance.
     */
    public function container(): Container;

    /**
     * Prepare the application to run based on the current runtime environment.
     */
    public function setRuntimeEnvironmentFromGlobals(): void;

    /**
     * Execute the prepared application, output the result and terminate the script execution.
     */
    public function run(): void;
}
