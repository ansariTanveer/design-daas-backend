<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Application\Common\Application\UnexpectedExceptionEvent;
use Application\Common\SymfonyConsole\CommandCacheInterface;
use Application\Common\SymfonyConsole\ConsoleOutput;
use BadMethodCallException;
use Psr\Container\ContainerInterface;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Symfony\Component\Console\Application as SymfonyApplication;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\EventDispatcher\EventDispatcher;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface as SymfonyContractEventDispatcherInterface;
use Throwable;

final class SymfonyConsoleCliDispatcher implements CliDispatcherInterface
{
    private ContainerInterface $container;

    private CommandCacheInterface $commandCache;

    private string $applicationName;

    private string $applicationVersion;

    private PsrEventDispatcherInterface $eventDispatcher;

    public function __construct(
        ContainerInterface $container,
        CommandCacheInterface $commandCache,
        string $applicationName,
        string $applicationVersion,
        PsrEventDispatcherInterface $eventDispatcher = null
    ) {
        $this->container = $container;
        $this->commandCache = $commandCache;
        $this->applicationName = $applicationName;
        $this->applicationVersion = $applicationVersion;
        $this->eventDispatcher = $eventDispatcher ?? new EventDispatcher();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function dispatch(InputInterface $input, OutputInterface $output): int
    {
        $application = new SymfonyApplication();
        $application->setCatchExceptions(false);
        $application->setAutoExit(false);

        $application->setName($this->applicationName);
        $application->setVersion($this->applicationVersion);

        $application->addCommands($this->commandCache->loadCommandList($this->container));

        if ($this->eventDispatcher instanceof SymfonyContractEventDispatcherInterface) {
            $application->setDispatcher($this->eventDispatcher);
        }

        $this->eventDispatcher->dispatch(new SymfonyConsoleApplicationReadyEvent($application));

        try {
            $exitCode = $application->run($input, $output);
            $this->eventDispatcher->dispatch(new CliDispatcherFinishedEvent(true, $exitCode));
            return $exitCode;
        } catch (Throwable $e) {
            $this->eventDispatcher->dispatch(new UnexpectedExceptionEvent($e));
            $exitCode = $e->getCode();
            $exitCode = (is_int($exitCode) && $exitCode >= 1 && $exitCode <= 255) ? $exitCode : 255;
            $application->renderThrowable($e, ConsoleOutput::wrapOutput($output)->stdErr());
            $this->eventDispatcher->dispatch(new CliDispatcherFinishedEvent(false, $exitCode));
            return $exitCode;
        }
    }

    public function reset(): void
    {
    }
}
