<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use BadMethodCallException;

final class CliDispatcherFinishedEvent
{
    private bool $successful;

    private int $exitCode;

    public function __construct(bool $successful, int $exitCode)
    {
        $this->successful = $successful;
        $this->exitCode = $exitCode;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function successful(): bool
    {
        return $this->successful;
    }

    public function exitCode(): int
    {
        return $this->exitCode;
    }
}
