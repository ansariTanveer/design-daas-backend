<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Application\Common\Application\ApplicationInterface;

interface CliApplicationInterface extends ApplicationInterface
{
    /**
     * Prepare the application to run based on the specified runtime environment.
     *
     * @param resource $stdIn
     * @param resource $stdOut
     * @param resource $stdErr
     * @param array<string, mixed> $server
     */
    public function setRuntimeEnvironment(
        $stdIn,
        $stdOut,
        $stdErr,
        array $server
    ): void;

    /**
     * Execute the prepared application and return the result.
     */
    public function execute(): int;
}
