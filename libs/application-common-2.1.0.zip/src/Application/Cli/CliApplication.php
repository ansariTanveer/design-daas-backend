<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Application\Common\SymfonyConsole\ConsoleOutput;
use BadMethodCallException;
use DI\Container;
use InvalidArgumentException;
use Symfony\Component\Console\Input\ArgvInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Output\StreamOutput;

final class CliApplication implements CliApplicationInterface
{
    private CliContextInterface $context;

    private ?InputInterface $input = null;

    private ?OutputInterface $output = null;

    public function __construct(CliContextInterface $context)
    {
        $this->context = $context;
        $this->initialize();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function setRuntimeEnvironmentFromGlobals(): void
    {
        $this->setRuntimeEnvironment(
            STDIN,
            STDOUT,
            STDERR,
            $_SERVER
        );
    }

    public function setRuntimeEnvironment(
        $stdIn,
        $stdOut,
        $stdErr,
        array $server
    ): void {
        if (!is_resource($stdIn) || get_resource_type($stdIn) !== 'stream') {
            throw new InvalidArgumentException('Invalid input resource');
        }

        if (!is_resource($stdOut) || get_resource_type($stdOut) !== 'stream') {
            throw new InvalidArgumentException('Invalid output resource');
        }

        if (!is_resource($stdErr) || get_resource_type($stdErr) !== 'stream') {
            throw new InvalidArgumentException('Invalid error resource');
        }

        $this->input = new ArgvInput(
            array_key_exists('argv', $server) && is_array($server['argv']) ?
                $server['argv'] :
                []
        );
        $this->input->setStream($stdIn);

        $this->output = new ConsoleOutput(
            new StreamOutput($stdOut),
            new StreamOutput($stdErr)
        );

        $this->context->applyEnvironmentVariablesFromServer($server);
    }

    public function container(): Container
    {
        return $this->context->container();
    }

    /**
     * @codeCoverageIgnore Not testing this method because it stops the script execution
     */
    public function run(): void
    {
        exit($this->execute());
    }

    public function execute(): int
    {
        assert($this->input !== null);
        assert($this->output !== null);

        return $this->context->dispatcher()->dispatch(
            $this->input,
            $this->output
        );
    }

    public function reset(): void
    {
        $this->context->reset();
        $this->initialize();
    }

    private function initialize(): void
    {
        $this->input = null;
        $this->output = null;
    }
}
