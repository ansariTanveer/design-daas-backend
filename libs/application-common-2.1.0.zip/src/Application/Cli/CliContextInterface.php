<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Application\Common\Application\ApplicationContextInterface;

interface CliContextInterface extends ApplicationContextInterface
{
    /**
     * Return the dispatcher instance for this context.
     */
    public function dispatcher(): CliDispatcherInterface;
}
