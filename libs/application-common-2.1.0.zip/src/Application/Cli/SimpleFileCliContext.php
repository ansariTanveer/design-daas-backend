<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Application\Common\Application\ApplicationContextBuilder;
use Application\Common\Application\SimpleFileContext;
use BadMethodCallException;
use DI\Container;

final class SimpleFileCliContext implements CliContextInterface
{
    private string $dispatcherEntryName;

    private SimpleFileContext $simpleContext;

    /**
     * @param array<string> $staticEntriesFiles
     * @param array<string> $environmentEntriesFiles
     */
    public function __construct(
        string $dispatcherEntryName,
        array $staticEntriesFiles,
        array $environmentEntriesFiles,
        bool $registerDefaultServices = true
    ) {
        $this->dispatcherEntryName = $dispatcherEntryName;
        $this->simpleContext = new SimpleFileContext(
            $staticEntriesFiles,
            $environmentEntriesFiles,
            $registerDefaultServices
        );
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function container(): Container
    {
        return $this->simpleContext->container();
    }

    public function applyEnvironmentVariablesFromServer(array $server): void
    {
        $this->simpleContext->applyEnvironmentVariablesFromServer($server);
    }

    public function reset(): void
    {
        $this->simpleContext->reset();
    }

    public function dispatcher(): CliDispatcherInterface
    {
        $dispatcher = $this->container()->get($this->dispatcherEntryName);
        assert($dispatcher instanceof CliDispatcherInterface);
        return $dispatcher;
    }

    /**
     * @return ApplicationContextBuilder<self>
     */
    public static function builder(
        string $dispatcherEntryName,
        bool $registerDefaultServices = true
    ): ApplicationContextBuilder {
        return new ApplicationContextBuilder(
            self::class,
            function (
                array $staticEntriesFiles,
                array $environmentEntriesFiles
            ) use (
                $dispatcherEntryName,
                $registerDefaultServices
            ): self {
                return new self(
                    $dispatcherEntryName,
                    $staticEntriesFiles,
                    $environmentEntriesFiles,
                    $registerDefaultServices
                );
            }
        );
    }
}
