<?php

declare(strict_types=1);

namespace Application\Common\Application\Cli;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Contracts\Service\ResetInterface;

interface CliDispatcherInterface extends ResetInterface
{
    /**
     * Dispatch the specified request and return the result.
     */
    public function dispatch(InputInterface $input, OutputInterface $output): int;
}
