<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use Application\Common\Application\ApplicationContextInterface;

interface HttpContextInterface extends ApplicationContextInterface
{
    /**
     * Return the dispatcher instance for this context.
     */
    public function dispatcher(): HttpDispatcherInterface;
}
