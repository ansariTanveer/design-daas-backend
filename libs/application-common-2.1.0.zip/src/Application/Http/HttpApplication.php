<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use Application\Common\PhpIniValueConverter;
use BadMethodCallException;
use DI\Container;
use Http\Factory\Guzzle\ResponseFactory;
use Http\Factory\Guzzle\ServerRequestFactory;
use Http\Factory\Guzzle\StreamFactory;
use Http\Factory\Guzzle\UploadedFileFactory;
use InvalidArgumentException;
use Laminas\HttpHandlerRunner\Emitter\SapiStreamEmitter;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Bridge\PsrHttpMessage\Factory\PsrHttpFactory;
use Symfony\Component\HttpFoundation\Request;

final class HttpApplication implements HttpApplicationInterface
{
    private HttpContextInterface $context;

    private bool $bodyTooLarge = false;

    private ?ServerRequestInterface $request = null;

    public function __construct(HttpContextInterface $context)
    {
        $this->context = $context;
        $this->initialize();
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function setRuntimeEnvironmentFromGlobals(): void
    {
        /*
         * When trying to open the php input stream from a request body that is too
         * large (larger than "post_max_size"), PHP will simply stop processing and
         * not return any response - open an alternative input stream in this case
         * and return an appropriate http response later
         */
        $maxBodySize = (string)ini_get('post_max_size');
        $bodyTooLarge = isset($_SERVER['CONTENT_LENGTH']) &&
            $_SERVER['CONTENT_LENGTH'] > PhpIniValueConverter::convertShorthandByteValue($maxBodySize);

        $body = fopen(($bodyTooLarge) ? 'php://memory' : 'php://input', 'rb');
        assert($body !== false);

        $this->setRuntimeEnvironment(
            $_GET,
            $_POST,
            $_COOKIE,
            $_FILES,
            $_SERVER,
            $body
        );

        if ($bodyTooLarge) {
            $this->flagTooLargeRequestBody();
        }
    }

    public function setRuntimeEnvironment(
        array $get,
        array $post,
        array $cookie,
        array $files,
        array $server,
        $inputStream
    ): void {
        if (!is_resource($inputStream) || get_resource_type($inputStream) !== 'stream') {
            throw new InvalidArgumentException('Invalid input resource');
        }

        $httpFactory = new PsrHttpFactory(
            new ServerRequestFactory(),
            new StreamFactory(),
            new UploadedFileFactory(),
            new ResponseFactory()
        );

        $request = new Request($get, $post, [], $cookie, $files, $server, $inputStream);
        $this->request = $httpFactory->createRequest($request);
        $this->bodyTooLarge = false;

        $this->context->applyEnvironmentVariablesFromServer($server);
    }

    public function flagTooLargeRequestBody(): void
    {
        $this->bodyTooLarge = true;
    }

    public function container(): Container
    {
        return $this->context->container();
    }

    /**
     * @codeCoverageIgnore Not testing this method because it stops the script execution
     */
    public function run(): void
    {
        $emitter = new SapiStreamEmitter();
        $emitter->emit($this->execute());
        exit(0);
    }

    public function execute(): ResponseInterface
    {
        assert($this->request !== null);

        return $this->context->dispatcher()->dispatch(
            $this->request,
            $this->bodyTooLarge
        );
    }

    public function reset(): void
    {
        $this->context->reset();
        $this->initialize();
    }

    private function initialize(): void
    {
        $this->bodyTooLarge = false;
        $this->request = null;
    }
}
