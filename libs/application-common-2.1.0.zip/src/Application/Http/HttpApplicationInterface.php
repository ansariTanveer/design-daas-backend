<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use Application\Common\Application\ApplicationInterface;
use Psr\Http\Message\ResponseInterface;

interface HttpApplicationInterface extends ApplicationInterface
{
    /**
     * Prepare the application to run based on the specified runtime environment.
     *
     * @param array<string, mixed> $get
     * @param array<string, mixed> $post
     * @param array<string, mixed> $cookie
     * @param array<string, mixed> $files
     * @param array<string, mixed> $server
     * @param resource $inputStream
     */
    public function setRuntimeEnvironment(
        array $get,
        array $post,
        array $cookie,
        array $files,
        array $server,
        $inputStream
    ): void;

    /**
     * Flag the request body of the prepared application as too large to be opened.
     */
    public function flagTooLargeRequestBody(): void;

    /**
     * Execute the prepared application and return the result.
     */
    public function execute(): ResponseInterface;
}
