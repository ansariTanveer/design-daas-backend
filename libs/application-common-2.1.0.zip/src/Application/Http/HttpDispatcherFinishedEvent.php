<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use BadMethodCallException;

final class HttpDispatcherFinishedEvent
{
    private bool $successful;

    private int $statusCode;

    public function __construct(bool $successful, int $statusCode)
    {
        $this->successful = $successful;
        $this->statusCode = $statusCode;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function successful(): bool
    {
        return $this->successful;
    }

    public function statusCode(): int
    {
        return $this->statusCode;
    }
}
