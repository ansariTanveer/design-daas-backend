<?php

declare(strict_types=1);

namespace Application\Common\Application\Http;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Contracts\Service\ResetInterface;

interface HttpDispatcherInterface extends ResetInterface
{
    /**
     * Dispatch the specified request and return the result.
     */
    public function dispatch(ServerRequestInterface $request, bool $bodyTooLarge): ResponseInterface;
}
