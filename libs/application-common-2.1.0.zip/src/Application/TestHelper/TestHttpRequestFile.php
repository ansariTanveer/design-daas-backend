<?php

declare(strict_types=1);

namespace Application\Common\Application\TestHelper;

use Application\Test\TestCase;
use BadMethodCallException;

final class TestHttpRequestFile
{
    private string $part;

    private string $path;

    private ?string $name = null;

    private ?string $type = null;

    private ?int $uploadResult = null;

    public function __construct(string $part, string $path)
    {
        TestCase::assertNotEmpty($part);
        TestCase::assertFileIsReadable($path);
        $this->part = $part;
        $this->path = $path;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function part(): string
    {
        return $this->part;
    }

    public function path(): string
    {
        return $this->path;
    }

    public function withName(?string $name): self
    {
        $clone = clone $this;
        $clone->name = $name;
        return $clone;
    }

    public function name(): string
    {
        return $this->name ?? basename($this->path);
    }

    public function withType(?string $type): self
    {
        $clone = clone $this;
        $clone->type = $type;
        return $clone;
    }

    public function type(): string
    {
        return $this->type ?? 'application/octet-stream';
    }

    public function withUploadResult(?int $uploadResult): self
    {
        $clone = clone $this;
        $clone->uploadResult = $uploadResult;
        return $clone;
    }

    public function uploadResult(): int
    {
        return $this->uploadResult ?? UPLOAD_ERR_OK;
    }

    public function size(): int
    {
        return (int)filesize($this->path);
    }
}
