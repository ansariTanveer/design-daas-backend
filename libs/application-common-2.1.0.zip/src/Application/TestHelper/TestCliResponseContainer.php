<?php

declare(strict_types=1);

namespace Application\Common\Application\TestHelper;

use BadMethodCallException;
use InvalidArgumentException;

final class TestCliResponseContainer
{
    private int $exitCode;

    /**
     * @var resource
     */
    private $stdOut;

    /**
     * @var resource
     */
    private $stdErr;

    /**
     * @param int $exitCode
     * @param resource $stdOut
     * @param resource $stdErr
     */
    public function __construct(int $exitCode, $stdOut, $stdErr)
    {
        if (!is_resource($stdOut) || get_resource_type($stdOut) !== 'stream') {
            throw new InvalidArgumentException('Invalid output resource');
        }

        if (!is_resource($stdErr) || get_resource_type($stdErr) !== 'stream') {
            throw new InvalidArgumentException('Invalid error resource');
        }

        $this->exitCode = $exitCode;
        $this->stdOut = $stdOut;
        $this->stdErr = $stdErr;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function exitCode(): int
    {
        return $this->exitCode;
    }

    public function stdOut(): string
    {
        rewind($this->stdOut);
        return (string)stream_get_contents($this->stdOut);
    }

    public function stdErr(): string
    {
        rewind($this->stdErr);
        return (string)stream_get_contents($this->stdErr);
    }

    public function formatAsString(): string
    {
        $format = 'ExitCode: %1$d' . PHP_EOL . PHP_EOL .
            'StdOut (JSON encoded): ' . PHP_EOL . PHP_EOL . '%2$s' . PHP_EOL . PHP_EOL .
            'StdErr (JSON encoded):' . PHP_EOL . PHP_EOL . '%3$s' . PHP_EOL . PHP_EOL;
        return sprintf(
            $format,
            $this->exitCode(),
            json_encode($this->stdOut()),
            json_encode($this->stdErr())
        );
    }

    public function __toString(): string
    {
        return $this->formatAsString();
    }
}
