<?php

declare(strict_types=1);

namespace Application\Common\Application;

use BadMethodCallException;
use Closure;

/**
 * @template T of ApplicationContextInterface
 */
final class ApplicationContextBuilder
{
    /**
     * @var class-string<T>
     */
    private string $type;

    /**
     * @var Closure(array<string>, array<string>): T
     */
    private Closure $callback;

    private string $staticFileSuffix = '.static.php';

    private string $environmentFileSuffix = '.env.php';

    /**
     * @var array<string>
     */
    private array $staticEntriesFiles = [];

    /**
     * @var array<string>
     */
    private array $environmentEntriesFiles = [];

    /**
     * @param class-string<T> $type
     * @param Closure(array<string>, array<string>): T $callback
     */
    public function __construct(string $type, Closure $callback)
    {
        $this->type = $type;
        $this->callback = $callback;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @return $this
     */
    public function withStaticFileSuffix(string $suffix): self
    {
        $this->staticFileSuffix = $suffix;
        return $this;
    }

    /**
     * @return $this
     */
    public function withEnvironmentFileSuffix(string $suffix): self
    {
        $this->environmentFileSuffix = $suffix;
        return $this;
    }

    /**
     * @return $this
     */
    public function scanDir(string $dir): self
    {
        $files = scandir($dir);
        assert($files !== false);

        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (!is_file($path)) {
                continue;
            }
            if (str_ends_with($path, $this->staticFileSuffix)) {
                $this->staticEntriesFiles[] = $path;
            } elseif (str_ends_with($path, $this->environmentFileSuffix)) {
                $this->environmentEntriesFiles[] = $path;
            }
        }

        return $this;
    }

    /**
     * @return T
     */
    public function build(): ApplicationContextInterface
    {
        $context = call_user_func($this->callback, $this->staticEntriesFiles, $this->environmentEntriesFiles);
        assert($context instanceof ApplicationContextInterface && $context instanceof $this->type);
        return $context;
    }
}
