<?php

declare(strict_types=1);

namespace Application\Common\Application;

use DI\Container;
use Symfony\Contracts\Service\ResetInterface;

interface ApplicationContextInterface extends ResetInterface
{
    /**
     * Return the context DI container instance.
     */
    public function container(): Container;

    /**
     * Process environment variables that are present in the specified runtime environment.
     *
     * @param array<string, mixed> $server
     */
    public function applyEnvironmentVariablesFromServer(array $server): void;
}
