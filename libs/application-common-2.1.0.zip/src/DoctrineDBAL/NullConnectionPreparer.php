<?php

declare(strict_types=1);

namespace Application\Common\DoctrineDBAL;

use BadMethodCallException;
use Doctrine\Common\EventManager;
use Doctrine\DBAL\Configuration;
use Doctrine\DBAL\Connection;

final class NullConnectionPreparer implements ConnectionPreparerInterface
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function prepareParams(array $params): array
    {
        return $params;
    }

    public function prepareConfiguration(): ?Configuration
    {
        return null;
    }

    public function prepareEventManager(): ?EventManager
    {
        return null;
    }

    public function prepareConnection(Connection $connection): void
    {
    }
}
