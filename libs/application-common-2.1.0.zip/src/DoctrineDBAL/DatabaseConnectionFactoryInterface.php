<?php

declare(strict_types=1);

namespace Application\Common\DoctrineDBAL;

use Doctrine\DBAL\Connection;
use Throwable;

interface DatabaseConnectionFactoryInterface
{
    /**
     * @throws Throwable
     */
    public function build(): Connection;
}
