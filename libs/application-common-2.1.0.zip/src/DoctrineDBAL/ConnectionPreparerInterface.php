<?php

declare(strict_types=1);

namespace Application\Common\DoctrineDBAL;

use Doctrine\Common\EventManager;
use Doctrine\DBAL\Configuration;
use Doctrine\DBAL\Connection;

interface ConnectionPreparerInterface
{
    /**
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     */
    public function prepareParams(array $params): array;

    public function prepareConfiguration(): ?Configuration;

    public function prepareEventManager(): ?EventManager;

    public function prepareConnection(Connection $connection): void;
}
