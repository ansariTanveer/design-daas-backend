<?php

declare(strict_types=1);

namespace Application\Common\DoctrineDBAL;

use BadMethodCallException;
use Doctrine\Common\EventManager;
use Doctrine\DBAL\Configuration;
use Doctrine\DBAL\Connection;

final class CallbackConnectionPreparer implements ConnectionPreparerInterface
{
    /**
     * @var callable(array<string, mixed>): array<string, mixed>
     */
    private $prepareParamsCallback;

    /**
     * @var callable(): ?Configuration
     */
    private $prepareConfigurationCallback;

    /**
     * @var callable(): ?EventManager
     */
    private $prepareEventManagerCallback;

    /**
     * @var callable(Connection): void
     */
    private $prepareConnectionCallback;

    /**
     * @param callable(array<string, mixed>): array<string, mixed>|null $prepareParamsCallback
     * @param callable(): ?Configuration|null $prepareConfigurationCallback
     * @param callable(): ?EventManager|null $prepareEventManagerCallback
     * @param callable(Connection): void|null $prepareConnectionCallback
     */
    public function __construct(
        ?callable $prepareParamsCallback,
        ?callable $prepareConfigurationCallback,
        ?callable $prepareEventManagerCallback,
        ?callable $prepareConnectionCallback
    ) {
        $this->prepareParamsCallback =
            $prepareParamsCallback ??
            function (array $params): array {
                return $params;
            };
        $this->prepareConfigurationCallback =
            $prepareConfigurationCallback ??
            function (): ?Configuration {
                return null;
            };
        $this->prepareEventManagerCallback =
            $prepareEventManagerCallback ??
            function (): ?EventManager {
                return null;
            };
        $this->prepareConnectionCallback =
            $prepareConnectionCallback ??
            function (Connection $connection): void {
            };
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function prepareParams(array $params): array
    {
        $callback = $this->prepareParamsCallback;
        return $callback($params);
    }

    public function prepareConfiguration(): ?Configuration
    {
        $callback = $this->prepareConfigurationCallback;
        return $callback();
    }

    public function prepareEventManager(): ?EventManager
    {
        $callback = $this->prepareEventManagerCallback;
        return $callback();
    }

    public function prepareConnection(Connection $connection): void
    {
        $callback = $this->prepareConnectionCallback;
        $callback($connection);
    }
}
