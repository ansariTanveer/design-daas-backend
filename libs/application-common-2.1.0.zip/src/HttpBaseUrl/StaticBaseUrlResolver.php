<?php

declare(strict_types=1);

namespace Application\Common\HttpBaseUrl;

use BadMethodCallException;
use Psr\Http\Message\UriInterface;

final class StaticBaseUrlResolver implements BaseUrlResolverInterface
{
    private UriInterface $baseUrl;

    public function __construct(UriInterface $baseUrl)
    {
        $this->baseUrl = $baseUrl;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function baseUrl(): UriInterface
    {
        return $this->baseUrl;
    }
}
