<?php

declare(strict_types=1);

namespace Application\Common\HttpBaseUrl;

use BadMethodCallException;
use LogicException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UriInterface;

final class RequestAttributeBaseUrlResolverMiddleware implements BaseUrlResolverInterface
{
    private string $attribute;

    private ?UriInterface $baseUrl;

    public function __construct(string $attribute)
    {
        $this->attribute = $attribute;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function __invoke(ServerRequestInterface $request, callable $next): ResponseInterface
    {
        $baseUrl = $request->getAttribute($this->attribute);
        if (!($baseUrl instanceof UriInterface)) {
            $msg = 'Request attribute "%1$s" was expected to contain instance of "%2$s" but instead contains: %3$s';
            throw new LogicException(
                sprintf(
                    $msg,
                    $this->attribute,
                    UriInterface::class,
                    is_object($baseUrl) ? get_class($baseUrl) : gettype($baseUrl)
                )
            );
        }
        $this->baseUrl = $baseUrl;
        return $next($request);
    }

    public function baseUrl(): UriInterface
    {
        assert($this->baseUrl !== null);
        return $this->baseUrl;
    }
}
