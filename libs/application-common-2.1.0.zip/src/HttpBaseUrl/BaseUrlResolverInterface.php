<?php

declare(strict_types=1);

namespace Application\Common\HttpBaseUrl;

use Psr\Http\Message\UriInterface;

interface BaseUrlResolverInterface
{
    public function baseUrl(): UriInterface;
}
