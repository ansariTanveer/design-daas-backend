<?php

declare(strict_types=1);

namespace Application\Common\SymfonyEventDispatcher;

interface EventSubscriberCollectorInterface
{
    public function addSearchPath(string $path, string $pattern): void;

    /**
     * @return class-string[]
     */
    public function collectEventSubscriberClassNames(): array;
}
