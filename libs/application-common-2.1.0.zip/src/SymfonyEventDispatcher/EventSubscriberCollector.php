<?php

declare(strict_types=1);

namespace Application\Common\SymfonyEventDispatcher;

use BadMethodCallException;
use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Finder\Iterator\FilenameFilterIterator;

final class EventSubscriberCollector implements EventSubscriberCollectorInterface
{
    private const PATH = 'path';
    private const PATTERN = 'pattern';

    /**
     * @var array<array{path: string, pattern: string}>
     */
    private array $search = [];

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function addSearchPath(string $path, string $pattern): void
    {
        $this->search[] = [
            self::PATH => $path,
            self::PATTERN => $pattern,
        ];
    }

    public function collectEventSubscriberClassNames(): array
    {
        $classNames = [];
        foreach ($this->search as $search) {
            $directoryContents = new RecursiveDirectoryIterator(
                $search[self::PATH],
                FilesystemIterator::SKIP_DOTS | FilesystemIterator::FOLLOW_SYMLINKS
            );
            $onlyLeafNodes = new RecursiveIteratorIterator(
                $directoryContents,
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            $filterControllerFiles = new FilenameFilterIterator(
                $onlyLeafNodes,
                [$search[self::PATTERN]],
                []
            );
            /** @var array<SplFileInfo|string> $files */
            $files = iterator_to_array($filterControllerFiles);
            foreach ($files as $file) {
                $foundClassNames = $this->extractClassNamesFromFile((string)$file);
                foreach ($foundClassNames as $candidateClassName) {
                    if (is_subclass_of($candidateClassName, EventSubscriberInterface::class)) {
                        $classNames[] = $candidateClassName;
                    }
                }
            }
        }
        return $classNames;
    }

    /**
     * @return class-string[]
     */
    private function extractClassNamesFromFile(string $file): array
    {
        $contents = file_get_contents($file);
        assert($contents !== false);
        $tokens = token_get_all($contents, TOKEN_PARSE);

        $currentNamespace = '';
        $classNames = [];
        for (; false !== $token = current($tokens); next($tokens)) {
            // namespace definition
            if (is_array($token) && token_name($token[0]) === 'T_NAMESPACE') {
                $currentNamespace = '';
                for (next($tokens); false !== $token = current($tokens); next($tokens)) {
                    if (in_array($token, [';', '{'], true)) {
                        // namespace ...; or namespace ... {}
                        break;
                    }
                    if (is_array($token)) {
                        $tokenName = token_name($token[0]);
                        $namespaceTokens = ['T_STRING', 'T_NAME_FULLY_QUALIFIED', 'T_NAME_QUALIFIED'];
                        if (in_array($tokenName, $namespaceTokens, true)) {
                            // concat namespace parts
                            $currentNamespace .= $token[1] . '\\';
                        }
                    }
                    // ignore all other tokens like whitespaces etc.
                }
                // remove leading \ from namespace in case it is present
                $currentNamespace = ltrim($currentNamespace, '\\');
                continue;
            }
            // class declaration
            if (is_array($token) && token_name($token[0]) === 'T_CLASS') {
                for (next($tokens); false !== $token = current($tokens); next($tokens)) {
                    if (is_array($token)) {
                        $tokenName = token_name($token[0]);
                        $classNameTokens = ['T_STRING'];
                        if (in_array($tokenName, $classNameTokens, true)) {
                            // add class name to list (the first string after "class" is expected to be the class name)
                            /** @psalm-var class-string $currentClassName */
                            $currentClassName = $currentNamespace . $token[1];
                            $classNames[] = $currentClassName;
                            break;
                        }
                    }
                    // ignore all other tokens like whitespaces etc.
                }
            }
        }

        return $classNames;
    }
}
