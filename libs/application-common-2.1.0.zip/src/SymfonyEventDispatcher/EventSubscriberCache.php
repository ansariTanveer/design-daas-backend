<?php

declare(strict_types=1);

namespace Application\Common\SymfonyEventDispatcher;

use BadMethodCallException;

final class EventSubscriberCache implements EventSubscriberCacheInterface
{
    private EventSubscriberCollectorInterface $collector;

    private ?string $cacheFile;

    /**
     * @var class-string[]|null
     */
    private ?array $inMemoryCache = null;

    public function __construct(EventSubscriberCollectorInterface $collector, ?string $cacheFile)
    {
        $this->collector = $collector;
        $this->cacheFile = $cacheFile;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildCache(): void
    {
        if (!$this->useCache()) {
            return;
        }
        $classNames = $this->buildClassNameList();
        assert($this->cacheFile !== null);
        file_put_contents($this->cacheFile, serialize($classNames));
    }

    private function useCache(): bool
    {
        return $this->cacheFile !== null;
    }

    public function loadEventSubscriberClassNames(): array
    {
        if ($this->inMemoryCache === null) {
            if ($this->useCache()) {
                assert($this->cacheFile !== null);
                $serializedClassNames = file_get_contents($this->cacheFile);
                assert($serializedClassNames !== false);
                /** @psalm-var class-string[] $classNames */
                $classNames = unserialize($serializedClassNames);
            } else {
                $classNames = $this->buildClassNameList();
            }
            $this->inMemoryCache = $classNames;
        }
        return $this->inMemoryCache;
    }

    /**
     * @return class-string[]
     */
    private function buildClassNameList(): array
    {
        return $this->collector->collectEventSubscriberClassNames();
    }
}
