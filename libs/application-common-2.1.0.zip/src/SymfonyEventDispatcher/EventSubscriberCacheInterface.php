<?php

declare(strict_types=1);

namespace Application\Common\SymfonyEventDispatcher;

interface EventSubscriberCacheInterface
{
    public function buildCache(): void;

    /**
     * @return class-string[]
     */
    public function loadEventSubscriberClassNames(): array;
}
