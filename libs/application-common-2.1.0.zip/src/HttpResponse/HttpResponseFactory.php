<?php

declare(strict_types=1);

namespace Application\Common\HttpResponse;

use Application\Common\HttpBaseUrl\BaseUrlResolverInterface;
use BadMethodCallException;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamFactoryInterface;

final class HttpResponseFactory
{
    private ResponseFactoryInterface $responseFactory;

    private StreamFactoryInterface $streamFactory;

    private BaseUrlResolverInterface $baseUrlResolver;

    public function __construct(
        ResponseFactoryInterface $responseFactory,
        StreamFactoryInterface $streamFactory,
        BaseUrlResolverInterface $baseUrlResolver
    ) {
        $this->responseFactory = $responseFactory;
        $this->streamFactory = $streamFactory;
        $this->baseUrlResolver = $baseUrlResolver;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public function buildEmpty(int $code): ResponseInterface
    {
        return $this->responseFactory->createResponse($code);
    }

    public function buildLocalRedirect(string $path): ResponseInterface
    {
        return $this->buildEmpty(302)
            ->withHeader(
                'Location',
                sprintf('%1$s%2$s', $this->baseUrlResolver->baseUrl()->getPath(), $path)
            );
    }

    public function buildHtml(int $code, string $body): ResponseInterface
    {
        return $this->buildEmpty($code)
            ->withHeader('Content-Type', 'text/html')
            ->withBody($this->streamFactory->createStream($body));
    }

    /**
     * @param int $code
     * @param mixed $body
     * @return ResponseInterface
     */
    public function buildJson(int $code, $body): ResponseInterface
    {
        return $this->buildEmpty($code)
            ->withHeader('Content-Type', 'application/json')
            ->withBody($this->streamFactory->createStream((string)json_encode($body)));
    }

    /**
     * @param int $code
     * @param string $message
     * @param array<string, mixed> $additionalFields
     * @return ResponseInterface
     */
    public function buildJsonMessage(int $code, string $message, array $additionalFields = []): ResponseInterface
    {
        return $this->buildJson(
            $code,
            (object)array_merge(
                $additionalFields,
                [
                    'message' => $message,
                ]
            )
        );
    }
}
