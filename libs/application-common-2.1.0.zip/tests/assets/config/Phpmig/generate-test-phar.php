<?php

declare(strict_types=1);

/*
 * This script can be used to generate the test.phar file because normally the creation/modification
 * of .phar files is disabled.
 *
 * ./scripts/tools.sh php -dphar.readonly=0 tests/assets/config/Phpmig/generate-test-phar.php
 */

$phar = new Phar(__DIR__ . '/test.phar');
$phar->addFromString('/001_test_file_1.php', '001_test_file_1');
$phar->addFromString('/002_test_file_2.php', '002_test_file_2');
$phar->addFromString('/003_test_file_3.php', '003_test_file_3');
$phar->addFromString('/test/001_file_4.php', 'test_001_file_4');
$phar->addFromString('/test/002_file_5.php', 'test_002_file_5');
$phar->addFromString('/test/003_file_6.php', 'test_003_file_6');
