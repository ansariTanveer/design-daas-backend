<?php

declare(strict_types=1);

use Psr\Container\ContainerInterface;
use Psr\EventDispatcher\EventDispatcherInterface;

return [
    EventDispatcherInterface::class => \DI\decorate(
        function (EventDispatcherInterface $previous, ContainerInterface $container): EventDispatcherInterface {
            $event = (object)[
                'value' => $container->get('event_dispatcher_environment'),
            ];
            $previous->dispatch($event);
            return $previous;
        }
    ),
];
