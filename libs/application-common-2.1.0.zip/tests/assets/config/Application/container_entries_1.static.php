<?php

declare(strict_types=1);

return [
    'static_1' => \DI\value('will_be_overridden'),
    'static_2' => \DI\value('static_value_2'),
    'static_3' => \DI\value('static_value_3'),
];
