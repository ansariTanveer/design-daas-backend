<?php

declare(strict_types=1);

return [
    'event_dispatcher_environment' => function (array $server) {
        return \DI\value($server['event_dispatcher_environment'] ?? null);
    },
];
