<?php

declare(strict_types=1);

return [
    'environment_1' => function (array $server) {
        return \DI\value('will_be_overridden');
    },
    'environment_2' => function (array $server) {
        return \DI\value($server['environment_2'] ?? null);
    },
    'environment_3' => function (array $server) {
        return \DI\value($server['environment_3'] ?? null);
    },
];
