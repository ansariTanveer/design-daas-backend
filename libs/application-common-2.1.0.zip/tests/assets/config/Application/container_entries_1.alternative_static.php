<?php

declare(strict_types=1);

return [
    'static_alternative_1' => \DI\value('static_value_1'),
];
