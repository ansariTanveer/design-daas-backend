<?php

declare(strict_types=1);

return [
    'environment_alternative_1' => function (array $server) {
        return \DI\value($server['environment_alternative_1'] ?? null);
    },
];
