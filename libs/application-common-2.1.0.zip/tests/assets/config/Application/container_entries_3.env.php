<?php

declare(strict_types=1);

return [
    // intentionally left empty to make sure a list without entries does not cause errors
];
