<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyRouting\RouteCache;

use BadMethodCallException;
use GuzzleHttp\Psr7\Response;
use LogicException;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\Routing\Annotation\Route;

final class NoControllerClass
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * This method is not expected to be picked up because the class is not named *Controller
     *
     * @Route(
     *     path = "/ignored/should-not-be-picked-up",
     *     methods = {"GET"},
     *     name = "ignored_should_not_be_picked_up",
     * )
     * @return ResponseInterface
     */
    public function someMethod(): ResponseInterface
    {
        return new Response();
    }
}
