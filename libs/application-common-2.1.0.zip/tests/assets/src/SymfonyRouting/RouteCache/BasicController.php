<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyRouting\RouteCache;

use BadMethodCallException;
use GuzzleHttp\Psr7\Response;
use LogicException;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\Routing\Annotation\Route;

final class BasicController
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @Route(
     *     path = "/basic-action",
     *     methods = {"GET"},
     *     name = "basic_action",
     * )
     * @return ResponseInterface
     */
    public function action(): ResponseInterface
    {
        return new Response();
    }
}
