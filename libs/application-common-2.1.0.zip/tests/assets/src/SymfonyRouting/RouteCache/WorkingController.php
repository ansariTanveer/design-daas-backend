<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyRouting\RouteCache;

use BadMethodCallException;
use GuzzleHttp\Psr7\Response;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\Routing\Annotation\Route;

final class WorkingController
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @Route(
     *     path = "/working-correctly",
     *     methods = {"GET"},
     *     name = "working_correctly",
     *     options = {
     *         "hello": "world",
     *         "some": {"additional", "data"},
     *     },
     * )
     * @return ResponseInterface
     */
    public function correctly(): ResponseInterface
    {
        return new Response();
    }
}
