<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyRouting\RouteCache\Module1;

use BadMethodCallException;
use GuzzleHttp\Psr7\Response;
use LogicException;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\Routing\Annotation\Route;

final class Test1Controller
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @Route(
     *     path = "/test1/some-action",
     *     methods = {"GET"},
     *     name = "test1_some_action",
     * )
     * @return ResponseInterface
     */
    public function someAction(): ResponseInterface
    {
        return new Response();
    }

    /**
     * @Route(
     *     path = "/test1/do-something",
     *     methods = {"GET"},
     *     name = "test1_do_something",
     * )
     * @return ResponseInterface
     */
    public function doSomething(): ResponseInterface
    {
        return new Response();
    }
}
