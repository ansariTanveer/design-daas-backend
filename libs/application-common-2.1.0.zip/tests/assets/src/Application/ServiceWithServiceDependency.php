<?php

declare(strict_types=1);

namespace Application\Test\Assets\Application;

use BadMethodCallException;

final class ServiceWithServiceDependency
{
    public SimpleService $dependency;

    public function __construct(SimpleService $dependency)
    {
        $this->dependency = $dependency;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }
}
