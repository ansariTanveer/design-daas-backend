<?php

declare(strict_types=1);

namespace Application\Test\Assets\Application;

use BadMethodCallException;
use DI\Annotation\Inject;

final class ServiceWithStringParameter
{
    public string $parameter;

    /**
     * @Inject({
     *     "parameter" = "environment_1",
     * })
     */
    public function __construct(string $parameter)
    {
        $this->parameter = $parameter;
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }
}
