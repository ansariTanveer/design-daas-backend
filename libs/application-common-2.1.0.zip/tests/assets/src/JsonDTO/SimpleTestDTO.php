<?php

declare(strict_types=1);

namespace Application\Test\Assets\JsonDTO;

use Application\Common\JsonDTO\AbstractJsonDTO;

final class SimpleTestDTO extends AbstractJsonDTO
{
    /**
     * @var string|null
     */
    public static $staticPropertyWillBeIgnored;

    /**
     * @var string|null
     */
    protected $protectedPropertyWillBeIgnored;

    /**
     * @var string|null
     */
    private $privatePropertyWillBeIgnored; // @phpstan-ignore-line

    /**
     * @var string|null
     */
    public $property1untyped;

    /**
     * @var string|null
     */
    public $property2untyped;

    public ?string $property3typed;

    public ?string $property4typed;
}
