<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyConsole\CommandCache\Module2;

use BadMethodCallException;
use LogicException;

final class Test2Commands
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @command test2:some-command
     * @return int
     */
    public function someCommand(): int
    {
        return 0;
    }

    /**
     * This method is not expected to be picked up because it has no command annotation
     *
     * @return int
     */
    public function someMethod(): int
    {
        return 0;
    }
}
