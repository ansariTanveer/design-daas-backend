<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyConsole\CommandCache;

use BadMethodCallException;
use LogicException;

final class NoCommandClass
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * This method is not expected to be picked up because the class is not named *Commands
     *
     * @command ignored:should-not-be-picked-up
     * @return int
     */
    public function someMethod(): int
    {
        return 0;
    }
}
