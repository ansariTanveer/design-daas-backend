<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyConsole\CommandCache;

use BadMethodCallException;

final class WorkingCommands
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @command working:correctly
     * @param int $return
     * @return int
     */
    public function correctly(int $return): int
    {
        return $return;
    }
}
