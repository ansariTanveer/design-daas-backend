<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyConsole\CommandCache\Module1;

use BadMethodCallException;
use LogicException;

final class Test1Commands
{
    public function __construct()
    {
        throw new LogicException('Constructor must not be executed');
    }

    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * @command test1:some-command
     * @return int
     */
    public function someCommand(): int
    {
        return 0;
    }

    /**
     * @command test1:do-something
     * @return int
     */
    public function doSomething(): int
    {
        return 0;
    }
}
