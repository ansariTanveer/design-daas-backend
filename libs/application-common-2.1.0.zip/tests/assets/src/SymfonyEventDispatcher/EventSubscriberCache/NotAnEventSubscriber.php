<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyEventDispatcher\EventSubscriberCache;

use BadMethodCallException;

/**
 * Correct class name suffix, but does not implement the subscriber interface - expected to NOT be picked up
 */
final class NotAnEventSubscriber
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    /**
     * Method is here intentionally but the class does not implement the required interface
     *
     * @return array<string, string|array{0: string, 1: int}|list<array{0: string, 1?: int}>>
     */
    public static function getSubscribedEvents(): array
    {
        // not relevant for test cases
        return [];
    }
}
