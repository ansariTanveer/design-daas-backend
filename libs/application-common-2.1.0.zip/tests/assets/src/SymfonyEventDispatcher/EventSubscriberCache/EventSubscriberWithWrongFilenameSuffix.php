<?php

declare(strict_types=1);

namespace Application\Test\Assets\SymfonyEventDispatcher\EventSubscriberCache;

use BadMethodCallException;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Wrong class name suffix but implements the subscriber interface - expected to NOT be picked up
 */
final class EventSubscriberWithWrongFilenameSuffix implements EventSubscriberInterface
{
    /**
     * Prevent clone.
     *
     * @codeCoverageIgnore
     */
    private function __clone()
    {
    }

    /**
     * Prevent serialize.
     *
     * @return array<string, mixed>
     * @codeCoverageIgnore
     */
    public function __serialize(): array
    {
        throw new BadMethodCallException('Cannot serialize ' . __CLASS__);
    }

    /**
     * Prevent unserialize.
     *
     * @param array<string, mixed> $data
     * @codeCoverageIgnore
     */
    public function __unserialize(array $data): void
    {
        throw new BadMethodCallException('Cannot unserialize ' . __CLASS__);
    }

    public static function getSubscribedEvents(): array
    {
        // not relevant for test cases
        return [];
    }
}
