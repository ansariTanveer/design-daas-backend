<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use Application\Common\DoctrineORM\InjectableEntityRepository;
use BadMethodCallException;
use Doctrine\ORM\EntityRepository;

/**
 * @extends InjectableEntityRepository<MissingEntity>
 * @template-extends InjectableEntityRepository<MissingEntity>
 * @extends EntityRepository<MissingEntity>
 * @template-extends EntityRepository<MissingEntity>
 */
final class MissingEntityRepository extends InjectableEntityRepository
{
}
