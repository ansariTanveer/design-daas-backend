<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use Application\Common\DoctrineORM\InjectableEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

/**
 * @extends InjectableEntityRepository<TestEntity>
 * @template-extends InjectableEntityRepository<TestEntity>
 * @extends EntityRepository<TestEntity>
 * @template-extends EntityRepository<TestEntity>
 */
final class TestEntityRepository extends InjectableEntityRepository
{
    public function getEntityManagerForTesting(): EntityManagerInterface
    {
        // Parent method is protected
        return parent::getEntityManager();
    }
}
