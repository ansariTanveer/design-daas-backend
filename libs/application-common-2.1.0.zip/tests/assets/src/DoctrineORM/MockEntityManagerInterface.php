<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\Mapping\ClassMetadata;
use Doctrine\Persistence\Mapping\ClassMetadataFactory;

/**
 * Defines additional methods in PHP code that the original EntityManagerInterface only defines in
 * annotations, to allow mocking of these methods.
 */
interface MockEntityManagerInterface extends EntityManagerInterface
{
    /**
     * @param callable $func
     * @return mixed
     */
    public function wrapInTransaction($func);

    /**
     * @return ClassMetadataFactory
     * @psalm-return ClassMetadataFactory<ClassMetadata<object>>
     */
    public function getMetadataFactory();
}
