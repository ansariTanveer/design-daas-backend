<?php

declare(strict_types=1);

namespace Application\Test\Assets\DoctrineORM;

use Application\Common\DoctrineORM\InjectableEntityRepository;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;

/**
 * @extends InjectableEntityRepository<AttributeEntity>
 * @template-extends InjectableEntityRepository<AttributeEntity>
 * @extends EntityRepository<AttributeEntity>
 * @template-extends EntityRepository<AttributeEntity>
 */
final class AttributeEntityRepository extends InjectableEntityRepository
{
    public function getEntityManagerForTesting(): EntityManagerInterface
    {
        // Parent method is protected
        return parent::getEntityManager();
    }
}
