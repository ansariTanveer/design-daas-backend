<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyConsole\CommandCache;

use Application\Common\SymfonyConsole\CommandCache\DataStore;
use Application\Test\TestCase;

final class DataStoreTest extends TestCase
{
    public function testAskingForNonExistingKeyReturnsFalse(): void
    {
        $dataStore = new DataStore();
        self::assertFalse($dataStore->has('someKey'));
    }

    public function testAskingForExistingEmptyArrayKeyReturnsTrue(): void
    {
        $dataStore = new DataStore();
        $dataStore->set('someKey', []);
        self::assertTrue($dataStore->has('someKey'));
    }

    public function testAccessingNonExistingKeyReturnsEmptyArray(): void
    {
        $dataStore = new DataStore();
        self::assertSame([], $dataStore->get('someKey'));
    }

    public function testAccessingExistingKeyReturnsCorrectValue(): void
    {
        $dataStore = new DataStore();
        $value = ['hello' => 'world'];
        $dataStore->set('someKey', $value);
        self::assertSame($value, $dataStore->get('someKey'));
    }

    public function testCorrectKeyListIsReturned(): void
    {
        $expectedKeys = ['key1', 'key2', 'key3'];
        sort($expectedKeys);
        $dataStore = new DataStore();
        foreach ($expectedKeys as $key) {
            $dataStore->set($key, []);
        }
        $actualKeys = $dataStore->keys();
        sort($actualKeys);
        self::assertSame($expectedKeys, $actualKeys);
    }
}
