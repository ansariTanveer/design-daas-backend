<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyConsole;

use Application\Common\SymfonyConsole\ConsoleOutput;
use Application\Test\TestCase;
use PHPUnit\Framework\MockObject\MockObject;
use Symfony\Component\Console\Formatter\OutputFormatterInterface;
use Symfony\Component\Console\Output\ConsoleOutputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class ConsoleOutputTest extends TestCase
{
    /**
     * @var OutputInterface|MockObject
     */
    private OutputInterface $stdOutMock;

    /**
     * @var OutputInterface|MockObject
     */
    private OutputInterface $stdErrMock;

    private ConsoleOutput $output;

    protected function setUp(): void
    {
        parent::setUp();

        $this->stdOutMock = $this->createMock(OutputInterface::class);
        $this->stdErrMock = $this->createMock(OutputInterface::class);
        $this->output = new ConsoleOutput($this->stdOutMock, $this->stdErrMock);
    }

    public function testWrite(): void
    {
        $message = 'Some Message';
        $newline = true;
        $options = 42;

        $this->stdOutMock->expects(self::once())
            ->method('write')
            ->with($message, $newline, $options);

        $this->stdErrMock->expects(self::never())
            ->method('write');

        $this->output->write($message, $newline, $options);
    }

    public function testWriteln(): void
    {
        $message = 'Some Message';
        $options = 42;

        $this->stdOutMock->expects(self::once())
            ->method('writeln')
            ->with($message, $options);

        $this->stdErrMock->expects(self::never())
            ->method('writeln');

        $this->output->writeln($message, $options);
    }

    public function testSetVerbosity(): void
    {
        $level = 42;

        $this->stdOutMock->expects(self::once())
            ->method('setVerbosity')
            ->with($level);

        $this->stdErrMock->expects(self::once())
            ->method('setVerbosity')
            ->with($level);

        $this->output->setVerbosity($level);
    }

    public function testGetVerbosity(): void
    {
        $level = 42;

        $this->stdOutMock->expects(self::once())
            ->method('getVerbosity')
            ->willReturn($level);

        $this->stdErrMock->expects(self::never())
            ->method('getVerbosity');

        self::assertSame($level, $this->output->getVerbosity());
    }

    public function testIsQuiet(): void
    {
        $this->stdOutMock->expects(self::once())
            ->method('isQuiet')
            ->willReturn(false);

        $this->stdErrMock->expects(self::never())
            ->method('isQuiet');

        self::assertFalse($this->output->isQuiet());
    }

    public function testIsVerbose(): void
    {
        $this->stdOutMock->expects(self::once())
            ->method('isVerbose')
            ->willReturn(false);

        $this->stdErrMock->expects(self::never())
            ->method('isVerbose');

        self::assertFalse($this->output->isVerbose());
    }

    public function testIsVeryVerbose(): void
    {
        $this->stdOutMock->expects(self::once())
            ->method('isVeryVerbose')
            ->willReturn(false);

        $this->stdErrMock->expects(self::never())
            ->method('isVeryVerbose');

        self::assertFalse($this->output->isVeryVerbose());
    }

    public function testIsDebug(): void
    {
        $this->stdOutMock->expects(self::once())
            ->method('isDebug')
            ->willReturn(false);

        $this->stdErrMock->expects(self::never())
            ->method('isDebug');

        self::assertFalse($this->output->isDebug());
    }

    public function testSetDecorated(): void
    {
        $decorated = false;

        $this->stdOutMock->expects(self::once())
            ->method('setDecorated')
            ->with($decorated);

        $this->stdErrMock->expects(self::once())
            ->method('setDecorated')
            ->with($decorated);

        $this->output->setDecorated($decorated);
    }

    public function testIsDecorated(): void
    {
        $this->stdOutMock->expects(self::once())
            ->method('isDecorated')
            ->willReturn(false);

        $this->stdErrMock->expects(self::never())
            ->method('isDecorated');

        self::assertFalse($this->output->isDecorated());
    }

    public function testSetFormatter(): void
    {
        $formatter = $this->createMock(OutputFormatterInterface::class);

        $this->stdOutMock->expects(self::once())
            ->method('setFormatter')
            ->with($formatter);

        $this->stdErrMock->expects(self::once())
            ->method('setFormatter')
            ->with($formatter);

        $this->output->setFormatter($formatter);
    }

    public function testGetFormatter(): void
    {
        $formatter = $this->createMock(OutputFormatterInterface::class);

        $this->stdOutMock->expects(self::once())
            ->method('getFormatter')
            ->willReturn($formatter);

        $this->stdErrMock->expects(self::never())
            ->method('getFormatter');

        self::assertSame($formatter, $this->output->getFormatter());
    }

    public function testStdOut(): void
    {
        self::assertSame($this->stdOutMock, $this->output->stdOut());
    }

    public function testStdErr(): void
    {
        self::assertSame($this->stdErrMock, $this->output->stdErr());
    }

    public function testWrapOutputReturnsSameInstanceIfAlreadyWrapped(): void
    {
        self::assertSame($this->output, ConsoleOutput::wrapOutput($this->output));
    }

    public function testWrapOutputUsesArgumentForStdOutAndStdErr(): void
    {
        $output = ConsoleOutput::wrapOutput($this->stdOutMock);

        self::assertSame($this->stdOutMock, $output->stdOut());
        self::assertSame($this->stdOutMock, $output->stdErr());
    }

    public function testWrapOutputExtractsStdErrFromConsoleOutputInterface(): void
    {
        $outputMock = $this->createMock(ConsoleOutputInterface::class);
        $outputMock->expects(self::once())
            ->method('getErrorOutput')
            ->willReturn($this->stdErrMock);

        $output = ConsoleOutput::wrapOutput($outputMock);

        self::assertSame($outputMock, $output->stdOut());
        self::assertSame($this->stdErrMock, $output->stdErr());
    }
}
