<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\DoctrineORM\ConfigurationCache;
use Application\Common\DoctrineORM\ConfigurationCollector;
use Application\Common\DoctrineORM\LazyEntityManager;
use Application\Test\Assets\DoctrineORM\AttributeEntity;
use Application\Test\Assets\DoctrineORM\TestEntity;
use Application\Test\TestCase;
use Doctrine\Persistence\Mapping\ClassMetadata;

final class ConfigurationCacheTest extends TestCase
{
    private string $cachePath;

    private string $basePath;

    private string $cacheFile;

    protected function setUp(): void
    {
        parent::setUp();
        $this->cachePath = self::TEST_TMP_DIR;
        $this->basePath = self::TEST_SRC_DIR . '/DoctrineORM';
        $this->cacheFile = 'doctrine.cache';
    }

    public function testCorrectMetadataIsPickedUp(): void
    {
        $collector = new ConfigurationCollector();
        $collector->addSearchPath($this->basePath);
        $cache = new ConfigurationCache($collector, null, $this->cacheFile);

        $em = new LazyEntityManager($this->createMock(DatabaseConnectionFactoryInterface::class), $cache);
        $metadata = $em->getMetadataFactory()->getAllMetadata();

        $expectedEntityNames = [];
        $expectedEntityNames[] = TestEntity::class;
        // attributes are supported since PHP 8
        if (PHP_VERSION_ID >= 80000) {
            $expectedEntityNames[] = AttributeEntity::class;
        }
        sort($expectedEntityNames);

        $actualEntityNames = array_values(
            array_map(
                function (ClassMetadata $metadata): string {
                    return $metadata->getName();
                },
                $metadata
            )
        );
        sort($actualEntityNames);

        self::assertSame($expectedEntityNames, $actualEntityNames);
    }

    public function testMetadataIsCorrectlyCached(): void
    {
        $collector = new ConfigurationCollector();
        $collector->addSearchPath($this->basePath);
        $cache = new ConfigurationCache($collector, $this->cachePath, $this->cacheFile);

        $cache->buildCache();
        unset($cache);
        unset($collector);

        self::assertFileExists(sprintf('%1$s/%2$s', $this->cachePath, $this->cacheFile));

        $collector = new ConfigurationCollector();
        $collector->addSearchPath($this->basePath);
        $cache = new ConfigurationCache($collector, $this->cachePath, $this->cacheFile);

        $em = new LazyEntityManager($this->createMock(DatabaseConnectionFactoryInterface::class), $cache);
        $metadata = $em->getMetadataFactory()->getAllMetadata();

        $expectedEntityNames = [];
        $expectedEntityNames[] = TestEntity::class;
        // attributes are supported since PHP 8
        if (PHP_VERSION_ID >= 80000) {
            $expectedEntityNames[] = AttributeEntity::class;
        }
        sort($expectedEntityNames);

        $actualEntityNames = array_values(
            array_map(
                function (ClassMetadata $metadata): string {
                    return $metadata->getName();
                },
                $metadata
            )
        );
        sort($actualEntityNames);

        self::assertSame($expectedEntityNames, $actualEntityNames);
    }

    public function testBuildingCacheWithoutCacheDirectoryDoesNothing(): void
    {
        $collector = new ConfigurationCollector();
        $collector->addSearchPath($this->basePath);
        $cache = new ConfigurationCache($collector, null, $this->cacheFile);

        $cache->buildCache();

        self::assertFileDoesNotExist(sprintf('%1$s/%2$s', $this->cachePath, $this->cacheFile));
    }
}
