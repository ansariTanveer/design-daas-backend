<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM\MappingCache;

use Application\Common\DoctrineORM\MappingCache\SimpleMappingDriverChain;
use Application\Test\TestCase;
use Doctrine\Persistence\Mapping\ClassMetadata;
use Doctrine\Persistence\Mapping\Driver\MappingDriver;

final class SimpleMappingDriverChainTest extends TestCase
{
    public function testMetadataIsLoadedFromFirstMatchingDriverOnly(): void
    {
        /** @var class-string $className */
        $className = 'SomeClass';
        $metadata = $this->createMock(ClassMetadata::class);
        $metadata->expects(self::never())->method(self::anything());

        $driver1 = $this->createMock(MappingDriver::class);
        $driver1->method('getAllClassNames')->willReturn([$className]);
        $driver1->expects(self::once())->method('loadMetadataForClass')->with($className, $metadata);

        $driver2 = $this->createMock(MappingDriver::class);
        $driver2->method('getAllClassNames')->willReturn([$className]);
        $driver2->expects(self::never())->method(self::anything());

        $chain = new SimpleMappingDriverChain();
        $chain->addDriver($driver1);
        $chain->addDriver($driver2);
        $chain->loadMetadataForClass($className, $metadata);
    }

    public function testNotMatchingClassDoesNotThrowException(): void
    {
        /** @var class-string $className */
        $className = 'NotExistingClass';
        $metadata = $this->createMock(ClassMetadata::class);
        $metadata->expects(self::never())->method(self::anything());

        $driver1 = $this->createMock(MappingDriver::class);
        $driver1->method('getAllClassNames')->willReturn([]);
        $driver1->expects(self::never())->method('loadMetadataForClass');

        $driver2 = $this->createMock(MappingDriver::class);
        $driver2->method('getAllClassNames')->willReturn([]);
        $driver2->expects(self::never())->method('loadMetadataForClass');

        $chain = new SimpleMappingDriverChain();
        $chain->addDriver($driver1);
        $chain->addDriver($driver2);
        $chain->loadMetadataForClass($className, $metadata);
    }

    public function testDuplicateClassnamesAreOnlyReturnedOnce(): void
    {
        /** @var class-string $className1 */
        $className1 = 'SomeClass';
        /** @var class-string $className2 */
        $className2 = 'AnotherClass';
        /** @var class-string $className3 */
        $className3 = 'ThirdClass';

        $driver1 = $this->createMock(MappingDriver::class);
        $driver1->method('getAllClassNames')->willReturn([$className1, $className2]);

        $driver2 = $this->createMock(MappingDriver::class);
        $driver2->method('getAllClassNames')->willReturn([$className1, $className3]);

        $chain = new SimpleMappingDriverChain();
        $chain->addDriver($driver1);
        $chain->addDriver($driver2);
        $classNames = $chain->getAllClassNames();

        self::assertSame(
            [$className1, $className2, $className3],
            $classNames
        );
    }

    public function testNonTransientClassIsMarkedCorrectly(): void
    {
        /** @var class-string $className */
        $className = 'SomeClass';

        $driver1 = $this->createMock(MappingDriver::class);
        $driver1->method('getAllClassNames')->willReturn([$className]);
        $driver1->expects(self::once())->method('isTransient')->with($className)->willReturn(false);

        $driver2 = $this->createMock(MappingDriver::class);
        $driver2->method('getAllClassNames')->willReturn([$className]);
        $driver2->expects(self::never())->method('isTransient');

        $chain = new SimpleMappingDriverChain();
        $chain->addDriver($driver1);
        $chain->addDriver($driver2);
        self::assertFalse($chain->isTransient($className));
    }

    public function testUnknownClassIsMarkedTransient(): void
    {
        /** @var class-string $className */
        $className = 'NotExistingClass';

        $driver1 = $this->createMock(MappingDriver::class);
        $driver1->method('getAllClassNames')->willReturn([]);
        $driver1->expects(self::never())->method('isTransient');

        $driver2 = $this->createMock(MappingDriver::class);
        $driver2->method('getAllClassNames')->willReturn([]);
        $driver2->expects(self::never())->method('isTransient');

        $chain = new SimpleMappingDriverChain();
        $chain->addDriver($driver1);
        $chain->addDriver($driver2);
        self::assertTrue($chain->isTransient($className));
    }
}
