<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM\MappingCache;

use Application\Common\DoctrineORM\MappingCache\StaticCacheMappingDriver;
use Application\Test\TestCase;
use Doctrine\Persistence\Mapping\ClassMetadata;
use Doctrine\Persistence\Mapping\Driver\MappingDriver;
use Doctrine\Persistence\Mapping\MappingException;
use PHPUnit\Framework\MockObject\MockObject;
use RuntimeException;

final class StaticCacheMappingDriverTest extends TestCase
{
    /**
     * @var array<string, array{transient: bool}>
     */
    private static array $classData = [
        'Class1' => ['transient' => true],
        'Class2' => ['transient' => false],
    ];

    /**
     * @var MappingDriver|MockObject
     */
    private MappingDriver $sourceDriver;

    protected function setUp(): void
    {
        parent::setUp();

        $this->sourceDriver = $this->createMock(MappingDriver::class);
        $this->sourceDriver->expects(self::atLeastOnce())
            ->method('getAllClassNames')
            ->willReturn(array_keys(self::$classData));
        $this->sourceDriver->expects(self::atLeastOnce())
            ->method('isTransient')
            ->willReturnCallback(function ($className): bool {
                return self::$classData[$className]['transient'];
            });

        self::assertNotEmpty(self::$classData);
    }

    public function testClassNamesAreCachedCorrectly(): void
    {
        $cache = new StaticCacheMappingDriver($this->sourceDriver);

        self::assertSame(array_keys(self::$classData), $cache->getAllClassNames());
    }

    public function testTransientStatusIsCachedCorrectly(): void
    {
        $cache = new StaticCacheMappingDriver($this->sourceDriver);

        foreach (self::$classData as $currentName => $currentData) {
            /** @var class-string $currentName */
            self::assertSame($currentData['transient'], $cache->isTransient($currentName));
        }
    }

    public function testTransientStatusForUnknownClassIsTrue(): void
    {
        $cache = new StaticCacheMappingDriver($this->sourceDriver);

        /** @psalm-var class-string $className */
        $className = 'UnknownClass';
        self::assertArrayNotHasKey($className, self::$classData);

        self::assertTrue($cache->isTransient($className));
    }

    public function testLoadingClassMetadataThrowsRuntimeException(): void
    {
        $cache = new StaticCacheMappingDriver($this->sourceDriver);

        /** @var class-string $className */
        $className = array_key_first(self::$classData);

        $this->expectException(RuntimeException::class);
        $cache->loadMetadataForClass($className, $this->createMock(ClassMetadata::class));
    }

    public function testLoadingUnknownClassMetadataThrowsMappingException(): void
    {
        $cache = new StaticCacheMappingDriver($this->sourceDriver);

        /** @psalm-var class-string $className */
        $className = 'UnknownClass';
        self::assertArrayNotHasKey($className, self::$classData);

        $this->expectException(MappingException::class);
        $cache->loadMetadataForClass($className, $this->createMock(ClassMetadata::class));
    }
}
