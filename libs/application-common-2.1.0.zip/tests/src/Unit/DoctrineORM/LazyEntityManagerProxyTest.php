<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\DoctrineORM\ConfigurationCacheInterface;
use Application\Common\DoctrineORM\LazyEntityManager;
use Application\Test\Assets\DoctrineORM\MockEntityManagerInterface;
use Application\Test\TestCase;
use Doctrine\Common\EventManager;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\LockMode;
use Doctrine\ORM\Cache;
use Doctrine\ORM\Configuration;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Internal\Hydration\AbstractHydrator;
use Doctrine\ORM\Mapping\ClassMetadata;
use Doctrine\ORM\Mapping\ClassMetadataFactory;
use Doctrine\ORM\NativeQuery;
use Doctrine\ORM\Proxy\ProxyFactory;
use Doctrine\ORM\Query;
use Doctrine\ORM\Query\Expr;
use Doctrine\ORM\Query\FilterCollection;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\QueryBuilder;
use Doctrine\ORM\UnitOfWork;
use PHPUnit\Framework\MockObject\MockObject;
use ReflectionClass;
use stdClass;

final class LazyEntityManagerProxyTest extends TestCase
{
    /**
     * @var EntityManagerInterface|MockObject
     */
    private EntityManagerInterface $wrappedInstance;

    private LazyEntityManager $testInstance;

    protected function setUp(): void
    {
        parent::setUp();

        $this->wrappedInstance = $this->createMock(MockEntityManagerInterface::class);

        $factoryMock = $this->createMock(DatabaseConnectionFactoryInterface::class);
        $factoryMock->expects(self::never())->method('build');
        $configurationCacheMock = $this->createMock(ConfigurationCacheInterface::class);
        $configurationCacheMock->expects(self::never())->method('buildCache');
        $configurationCacheMock->expects(self::never())->method('loadConfiguration');

        $this->testInstance = new LazyEntityManager($factoryMock, $configurationCacheMock);

        $reflectionClass = new ReflectionClass(LazyEntityManager::class);
        $reflectionInstanceProperty = $reflectionClass->getProperty('instance');
        $reflectionInstanceProperty->setAccessible(true);
        $reflectionInstanceProperty->setValue($this->testInstance, $this->wrappedInstance);
        $reflectionFullyInitializedProperty = $reflectionClass->getProperty('fullyInitialized');
        $reflectionFullyInitializedProperty->setAccessible(true);
        $reflectionFullyInitializedProperty->setValue($this->testInstance, true);
    }

    public function testGetCache(): void
    {
        $expected = $this->createMock(Cache::class);
        $this->wrappedInstance->expects(self::once())
            ->method('getCache')
            ->willReturn($expected);

        $actual = $this->testInstance->getCache();

        self::assertSame($expected, $actual);
    }

    public function testGetConnection(): void
    {
        $expected = $this->createMock(Connection::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getConnection')
            ->willReturn($expected);

        $actual = $this->testInstance->getConnection();

        self::assertSame($expected, $actual);
    }

    public function testGetExpressionBuilder(): void
    {
        $expected = $this->createMock(Expr::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getExpressionBuilder')
            ->willReturn($expected);

        $actual = $this->testInstance->getExpressionBuilder();

        self::assertSame($expected, $actual);
    }

    public function testBeginTransaction(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('beginTransaction');

        $this->testInstance->beginTransaction();
    }

    public function testTransactional(): void
    {
        /** @psalm-var callable $callback */
        $callback = ['time'];
        $expected = 42;
        $this->wrappedInstance
            ->expects(self::once())
            ->method('transactional')
            ->with($callback)
            ->willReturn($expected);

        $actual = $this->testInstance->transactional($callback);

        self::assertSame($expected, $actual);
    }

    public function testWrapInTransaction(): void
    {
        /** @psalm-var callable $callback */
        $callback = ['time'];
        $expected = 42;
        $this->wrappedInstance
            ->expects(self::once())
            ->method('wrapInTransaction')
            ->with($callback)
            ->willReturn($expected);

        $actual = $this->testInstance->wrapInTransaction($callback);

        self::assertSame($expected, $actual);
    }

    public function testCommit(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('commit');

        $this->testInstance->commit();
    }

    public function testRollback(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('rollback');

        $this->testInstance->rollback();
    }

    public function testCreateQuery(): void
    {
        $this->wrappedInstance
            ->expects(self::atLeastOnce())
            ->method('getConfiguration')
            ->willReturn(new Configuration());

        $dql = 'SomeDQL';
        $expected = new Query($this->wrappedInstance);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('createQuery')
            ->with($dql)
            ->willReturn($expected);

        $actual = $this->testInstance->createQuery($dql);

        self::assertSame($expected, $actual);
    }

    public function testCreateNamedQuery(): void
    {
        $this->wrappedInstance
            ->expects(self::atLeastOnce())
            ->method('getConfiguration')
            ->willReturn(new Configuration());

        $name = 'SomeName';
        $expected = new Query($this->wrappedInstance);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('createNamedQuery')
            ->with($name)
            ->willReturn($expected);

        $actual = $this->testInstance->createNamedQuery($name);

        self::assertSame($expected, $actual);
    }

    public function testCreateNativeQuery(): void
    {
        $this->wrappedInstance
            ->expects(self::atLeastOnce())
            ->method('getConfiguration')
            ->willReturn(new Configuration());

        $sql = 'SomeSQL';
        $mapping = $this->createMock(ResultSetMapping::class);
        $expected = new NativeQuery($this->wrappedInstance);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('createNativeQuery')
            ->with($sql, $mapping)
            ->willReturn($expected);

        $actual = $this->testInstance->createNativeQuery($sql, $mapping);

        self::assertSame($expected, $actual);
    }

    public function testCreateNamedNativeQuery(): void
    {
        $this->wrappedInstance
            ->expects(self::atLeastOnce())
            ->method('getConfiguration')
            ->willReturn(new Configuration());

        $name = 'SomeName';
        $expected = new NativeQuery($this->wrappedInstance);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('createNamedNativeQuery')
            ->with($name)
            ->willReturn($expected);

        $actual = $this->testInstance->createNamedNativeQuery($name);

        self::assertSame($expected, $actual);
    }

    public function testCreateQueryBuilder(): void
    {
        $expected = $this->createMock(QueryBuilder::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('createQueryBuilder')
            ->willReturn($expected);

        $actual = $this->testInstance->createQueryBuilder();

        self::assertSame($expected, $actual);
    }

    public function testGetReference(): void
    {
        /** @psalm-var class-string $entityName */
        $entityName = 'SomeEntityName';
        $id = 'SomeId';
        $expected = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getReference')
            ->with($entityName, $id)
            ->willReturn($expected);

        $actual = $this->testInstance->getReference($entityName, $id);

        self::assertSame($expected, $actual);
    }

    public function testGetPartialReference(): void
    {
        /** @psalm-var class-string $entityName */
        $entityName = 'SomeEntityName';
        $id = 'SomeIdentifier';
        $expected = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getPartialReference')
            ->with($entityName, $id)
            ->willReturn($expected);

        $actual = $this->testInstance->getPartialReference($entityName, $id);

        self::assertSame($expected, $actual);
    }

    public function testClose(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('close');

        $this->testInstance->close();
    }

    public function testCopy(): void
    {
        $entity = new stdClass();
        $deep = true;
        $expected = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('copy')
            ->with($entity, $deep)
            ->willReturn($expected);

        $actual = $this->testInstance->copy($entity, $deep);

        self::assertSame($expected, $actual);
    }

    public function testLock(): void
    {
        $entity = new stdClass();
        $lockMode = LockMode::PESSIMISTIC_WRITE;
        $lockVersion = 1337;
        $this->wrappedInstance
            ->expects(self::once())
            ->method('lock')
            ->with($entity, $lockMode, $lockVersion);

        $this->testInstance->lock($entity, $lockMode, $lockVersion);
    }

    public function testGetEventManager(): void
    {
        $expected = $this->createMock(EventManager::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getEventManager')
            ->willReturn($expected);

        $actual = $this->testInstance->getEventManager();

        self::assertSame($expected, $actual);
    }

    public function testGetConfiguration(): void
    {
        $expected = $this->createMock(Configuration::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getConfiguration')
            ->willReturn($expected);

        $actual = $this->testInstance->getConfiguration();

        self::assertSame($expected, $actual);
    }

    public function testIsOpen(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('isOpen')
            ->willReturn(false);

        self::assertFalse($this->testInstance->isOpen());
    }

    public function testGetUnitOfWork(): void
    {
        $expected = $this->createMock(UnitOfWork::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getUnitOfWork')
            ->willReturn($expected);

        $actual = $this->testInstance->getUnitOfWork();

        self::assertSame($expected, $actual);
    }

    public function testGetHydrator(): void
    {
        $hydrationMode = 'SomeEntityName';
        $expected = $this->createMock(AbstractHydrator::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getHydrator')
            ->with($hydrationMode)
            ->willReturn($expected);

        $actual = $this->testInstance->getHydrator($hydrationMode);

        self::assertSame($expected, $actual);
    }

    public function testNewHydrator(): void
    {
        $hydrationMode = 'SomeEntityName';
        $expected = $this->createMock(AbstractHydrator::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('newHydrator')
            ->with($hydrationMode)
            ->willReturn($expected);

        $actual = $this->testInstance->newHydrator($hydrationMode);

        self::assertSame($expected, $actual);
    }

    public function testGetProxyFactory(): void
    {
        $expected = $this->createMock(ProxyFactory::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getProxyFactory')
            ->willReturn($expected);

        $actual = $this->testInstance->getProxyFactory();

        self::assertSame($expected, $actual);
    }

    public function testGetFilters(): void
    {
        $expected = $this->createMock(FilterCollection::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getFilters')
            ->willReturn($expected);

        $actual = $this->testInstance->getFilters();

        self::assertSame($expected, $actual);
    }

    public function testIsFiltersStateClean(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('isFiltersStateClean')
            ->willReturn(false);

        self::assertFalse($this->testInstance->isFiltersStateClean());
    }

    public function testHasFilters(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('hasFilters')
            ->willReturn(false);

        self::assertFalse($this->testInstance->hasFilters());
    }

    public function testFind(): void
    {
        /** @psalm-var class-string $className */
        $className = 'SomeClassName';
        $id = 'SomeId';
        $expected = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('find')
            ->with($className, $id)
            ->willReturn($expected);

        $actual = $this->testInstance->find($className, $id);

        self::assertSame($expected, $actual);
    }

    public function testPersist(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('persist')
            ->with($object);

        $this->testInstance->persist($object);
    }

    public function testRemove(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('remove')
            ->with($object);

        $this->testInstance->remove($object);
    }

    public function testMerge(): void
    {
        $object = new stdClass();
        $expected = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('merge')
            ->with($object)
            ->willReturn($expected);

        $actual = $this->testInstance->merge($object);

        self::assertSame($expected, $actual);
    }

    public function testClear(): void
    {
        $objectName = 'SomeName';
        $this->wrappedInstance
            ->expects(self::once())
            ->method('clear')
            ->with($objectName);

        $this->testInstance->clear($objectName);
    }

    public function testDetach(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('detach')
            ->with($object);

        $this->testInstance->detach($object);
    }

    public function testRefresh(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('refresh')
            ->with($object);

        $this->testInstance->refresh($object);
    }

    public function testFlush(): void
    {
        $this->wrappedInstance
            ->expects(self::once())
            ->method('flush');

        $this->testInstance->flush();
    }

    public function testGetRepository(): void
    {
        /** @psalm-var class-string $className */
        $className = 'SomeClass';
        $expected = $this->createMock(EntityRepository::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getRepository')
            ->with($className)
            ->willReturn($expected);

        $actual = $this->testInstance->getRepository($className);

        self::assertSame($expected, $actual);
    }

    public function testGetMetadataFactory(): void
    {
        $expected = $this->createMock(ClassMetadataFactory::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getMetadataFactory')
            ->willReturn($expected);

        $actual = $this->testInstance->getMetadataFactory();

        self::assertSame($expected, $actual);
    }

    public function testInitializeObject(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('initializeObject')
            ->with($object);

        $this->testInstance->initializeObject($object);
    }

    public function testContains(): void
    {
        $object = new stdClass();
        $this->wrappedInstance
            ->expects(self::once())
            ->method('contains')
            ->with($object)
            ->willReturn(false);

        self::assertFalse($this->testInstance->contains($object));
    }

    public function testGetClassMetadata(): void
    {
        $className = 'SomeClass';
        $expected = $this->createMock(ClassMetadata::class);
        $this->wrappedInstance
            ->expects(self::once())
            ->method('getClassMetadata')
            ->with($className)
            ->willReturn($expected);

        $actual = $this->testInstance->getClassMetadata($className);

        self::assertSame($expected, $actual);
    }
}
