<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineORM;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\DoctrineORM\ConfigurationCacheInterface;
use Application\Common\DoctrineORM\LazyEntityManager;
use Application\Test\TestCase;
use Doctrine\ORM\EntityManagerInterface;
use ReflectionClass;
use ReflectionProperty;

final class LazyEntityManagerResetTest extends TestCase
{
    private LazyEntityManager $testInstance;

    private ReflectionProperty $reflectionInstanceProperty;

    private ReflectionProperty $reflectionFullyInitializedProperty;

    protected function setUp(): void
    {
        parent::setUp();

        $factoryMock = $this->createMock(DatabaseConnectionFactoryInterface::class);
        $factoryMock->expects(self::never())->method('build');
        $configurationCacheMock = $this->createMock(ConfigurationCacheInterface::class);
        $configurationCacheMock->expects(self::never())->method('buildCache');
        $configurationCacheMock->expects(self::never())->method('loadConfiguration');

        $this->testInstance = new LazyEntityManager($factoryMock, $configurationCacheMock);

        $reflectionClass = new ReflectionClass(LazyEntityManager::class);
        $this->reflectionInstanceProperty = $reflectionClass->getProperty('instance');
        $this->reflectionInstanceProperty->setAccessible(true);
        $this->reflectionFullyInitializedProperty = $reflectionClass->getProperty('fullyInitialized');
        $this->reflectionFullyInitializedProperty->setAccessible(true);
    }

    public function testResetPartlyInitializedInstance(): void
    {
        $wrappedInstance = $this->createMock(EntityManagerInterface::class);
        $wrappedInstance->expects(self::once())->method('close');

        $this->reflectionInstanceProperty->setValue($this->testInstance, $wrappedInstance);
        $this->reflectionFullyInitializedProperty->setValue($this->testInstance, false);

        $this->testInstance->reset();

        self::assertNull($this->reflectionInstanceProperty->getValue($this->testInstance));
        self::assertFalse($this->reflectionFullyInitializedProperty->getValue($this->testInstance));
    }

    public function testResetFullyInitializedInstance(): void
    {
        $wrappedInstance = $this->createMock(EntityManagerInterface::class);
        $wrappedInstance->expects(self::once())->method('close');

        $this->reflectionInstanceProperty->setValue($this->testInstance, $wrappedInstance);
        $this->reflectionFullyInitializedProperty->setValue($this->testInstance, true);

        $this->testInstance->reset();

        self::assertNull($this->reflectionInstanceProperty->getValue($this->testInstance));
        self::assertFalse($this->reflectionFullyInitializedProperty->getValue($this->testInstance));
    }

    public function testResetUninitialized(): void
    {
        $this->reflectionInstanceProperty->setValue($this->testInstance, null);
        $this->reflectionFullyInitializedProperty->setValue($this->testInstance, false);

        $this->testInstance->reset();

        self::assertNull($this->reflectionInstanceProperty->getValue($this->testInstance));
        self::assertFalse($this->reflectionFullyInitializedProperty->getValue($this->testInstance));
    }
}
