<?php

declare(strict_types=1);

namespace Application\Test\Unit\GuzzleHttpClient;

use Application\Common\GuzzleHttpClient\HttpClientFactory;
use Application\Test\TestCase;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Request;
use LogicException;
use Psr\Http\Message\ResponseInterface;

final class HttpClientFactoryTest extends TestCase
{
    public function testConfigurationIsPassedOnCorrectly(): void
    {
        $expectedResponse = $this->createMock(ResponseInterface::class);
        $requestHandler = function (Request $request) use ($expectedResponse): ResponseInterface {
            self::assertSame('GET', $request->getMethod());
            self::assertSame('https://www.example.com/test', (string)$request->getUri());
            return $expectedResponse;
        };

        $factory = new HttpClientFactory(new HandlerStack(new MockHandler([$requestHandler])));
        $client = $factory->build(['base_uri' => 'https://www.example.com']);
        $response = $client->request('GET', '/test');

        self::assertSame($expectedResponse, $response);
    }

    public function testSpecifyingCustomHandlerThrowsException(): void
    {
        $factory = new HttpClientFactory(new HandlerStack(new MockHandler()));

        $this->expectException(LogicException::class);
        $this->expectExceptionMessage('Not allowed to specify custom handler stack when building HTTP client');
        $factory->build(['handler' => new MockHandler()]);
    }
}
