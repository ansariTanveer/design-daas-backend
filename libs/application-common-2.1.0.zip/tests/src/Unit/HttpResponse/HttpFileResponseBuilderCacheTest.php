<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpResponse\HttpFileResponseBuilder;
use Application\Test\TestCase;
use DateTimeInterface;
use GuzzleHttp\Psr7\ServerRequest;
use Http\Factory\Guzzle\ResponseFactory;
use Psr\Http\Message\StreamInterface;

final class HttpFileResponseBuilderCacheTest extends TestCase
{
    private ResponseFactory $responseFactory;

    private ServerRequest $request;

    private StreamInterface $body;

    protected function setUp(): void
    {
        parent::setUp();

        $this->responseFactory = new ResponseFactory();
        $this->request = new ServerRequest('GET', 'http://www.example.com/some.file');
        $this->body = $this->createMock(StreamInterface::class);
    }

    public function testRequestWildcardETagReturns304IfETagIsSpecified(): void
    {
        $this->request = $this->request->withHeader('If-None-Match', '*');

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withETag('some-etag-that-does-not-matter');

        $response = $builder->build();

        self::assertSame(304, $response->getStatusCode());
    }

    public function testRequestMatchingETagReturns304(): void
    {
        $expectedETag = 'some-etag-that-does-not-matter';

        $this->request = $this->request->withHeader(
            'If-None-Match',
            sprintf(
                '"%1$s", "%2$s", "%3$s"',
                'something-else',
                $expectedETag,
                'another-not-matching-etag'
            )
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withETag($expectedETag);

        $response = $builder->build();

        self::assertSame(304, $response->getStatusCode());
    }

    public function testRequestNotMatchingETagReturns200(): void
    {
        $this->request = $this->request->withHeader(
            'If-None-Match',
            sprintf(
                '"%1$s", "%2$s", "%3$s"',
                'something-else',
                'also-not-the-actual-etag',
                'another-not-matching-etag'
            )
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withETag('some-etag-that-does-not-matter');

        $response = $builder->build();

        self::assertSame(200, $response->getStatusCode());
    }

    public function testRequestIfModifiedSinceSameAsModificationTimeReturns304(): void
    {
        $modificationTime = 1234567;

        $this->request = $this->request->withHeader(
            'If-Modified-Since',
            gmdate(DateTimeInterface::RFC7231, $modificationTime)
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withModificationTime($modificationTime);

        $response = $builder->build();

        self::assertSame(304, $response->getStatusCode());
    }

    public function testRequestIfModifiedSinceInTheFutureOfModificationTimeReturns304(): void
    {
        $modificationTime = 1234567;

        $this->request = $this->request->withHeader(
            'If-Modified-Since',
            gmdate(DateTimeInterface::RFC7231, $modificationTime + 1)
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withModificationTime($modificationTime);

        $response = $builder->build();

        self::assertSame(304, $response->getStatusCode());
    }

    public function testRequestIfModifiedSinceInThePastOfModificationTimeReturns200(): void
    {
        $modificationTime = 1234567;

        $this->request = $this->request->withHeader(
            'If-Modified-Since',
            gmdate(DateTimeInterface::RFC7231, $modificationTime - 1)
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withModificationTime($modificationTime);

        $response = $builder->build();

        self::assertSame(200, $response->getStatusCode());
    }

    public function testRequestMalformedIfModifiedSinceReturns200(): void
    {
        $this->request = $this->request->withHeader(
            'If-Modified-Since',
            'some-malformed-datetime'
        );

        $builder = new HttpFileResponseBuilder($this->responseFactory, $this->request, $this->body);
        $builder->withModificationTime(1234567);

        $response = $builder->build();

        self::assertSame(200, $response->getStatusCode());
    }
}
