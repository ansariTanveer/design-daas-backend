<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpBaseUrl\StaticBaseUrlResolver;
use Application\Common\HttpResponse\HttpResponseFactory;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Uri;
use Http\Factory\Guzzle\ResponseFactory as GuzzleResponseFactory;
use Http\Factory\Guzzle\StreamFactory as GuzzleStreamFactory;
use stdClass;

final class HttpResponseFactoryTest extends TestCase
{
    private HttpResponseFactory $responseFactory;

    protected function setUp(): void
    {
        $this->responseFactory = new HttpResponseFactory(
            new GuzzleResponseFactory(),
            new GuzzleStreamFactory(),
            new StaticBaseUrlResolver(new Uri('http://www.example.com/base/url'))
        );
    }

    /**
     * @return iterable<string, list<int>>
     */
    public function statusCodeProvider(): iterable
    {
        yield 'status-ok' => [200];
        yield 'status-bad-request' => [400];
        yield 'status-internal-server-error' => [500];
    }

    /**
     * @dataProvider statusCodeProvider
     */
    public function testBuildEmptyResponseWithStatusCode(int $statusCode): void
    {
        $response = $this->responseFactory->buildEmpty($statusCode);

        self::assertSame($statusCode, $response->getStatusCode());
    }

    public function testBuildCorrectLocalRedirect(): void
    {
        $redirect = $this->responseFactory->buildLocalRedirect('/sub-route');

        self::assertSame(302, $redirect->getStatusCode());
        self::assertSame('/base/url/sub-route', $redirect->getHeaderLine('Location'));
    }

    public function testBuildHtmlResponse(): void
    {
        $content = '<html></html>';
        $htmlRequest = $this->responseFactory->buildHtml(200, $content);

        self::assertSame(200, $htmlRequest->getStatusCode());
        self::assertSame('text/html', $htmlRequest->getHeaderLine('Content-Type'));
        self::assertSame($content, (string)$htmlRequest->getBody());
    }

    /**
     * @return iterable<string, array<int, int|object|array<string, string>|string>>
     */
    public function jsonBodyProvider(): iterable
    {
        yield 'as-array' => [
            200,
            ['foo' => 'bar'],
            (string)json_encode((object)['foo' => 'bar']),
        ];

        $object = new stdClass();
        $object->bar = 'baz';

        yield 'as-object' => [
            400,
            $object,
            (string)json_encode((object)['bar' => 'baz']),
        ];
    }

    /**
     * @param object|array<string, string> $body
     * @dataProvider jsonBodyProvider
     */
    public function testBuildJsonResponse(int $statusCode, $body, string $expectedBody): void
    {
        $jsonResponse = $this->responseFactory->buildJson($statusCode, $body);

        self::assertSame($statusCode, $jsonResponse->getStatusCode());
        self::assertSame('application/json', $jsonResponse->getHeaderLine('Content-Type'));
        self::assertSame($expectedBody, (string)$jsonResponse->getBody());
    }

    public function testBuildJsonMessage(): void
    {
        $message = 'test-message';
        $additional = ['foo' => 'bar'];

        $expectedBody = (object)[
            'message' => 'test-message',
            'foo' => 'bar',
        ];

        $response = $this->responseFactory->buildJsonMessage(400, $message, $additional);

        self::assertEquals($expectedBody, json_decode((string)$response->getBody()));
    }

    public function testBuildJsonMessageWithComplexAdditionalFields(): void
    {
        $message = 'test-message';
        $additional = [
            'foo' => 'bar',
            'hello' => [
                'world',
                '!',
            ],
            'object' => (object)[
                'property' => 'value',
            ],
            'object_array' => [
                'property' => 'value',
            ],
        ];

        $expectedBody = (object)[
            'message' => 'test-message',
            'foo' => 'bar',
            'hello' => [
                'world',
                '!',
            ],
            'object' => (object)[
                'property' => 'value',
            ],
            'object_array' => (object)[
                'property' => 'value',
            ],
        ];

        $response = $this->responseFactory->buildJsonMessage(400, $message, $additional);

        self::assertEquals($expectedBody, json_decode((string)$response->getBody()));
    }
}
