<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpResponse;

use Application\Common\HttpResponse\HttpFileResponseFactory;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\ServerRequest;
use Http\Factory\Guzzle\ResponseFactory;
use Http\Factory\Guzzle\StreamFactory;

final class HttpFileResponseFactoryFromStringTest extends TestCase
{
    private HttpFileResponseFactory $factory;

    private ServerRequest $request;

    protected function setUp(): void
    {
        parent::setUp();

        $this->factory = new HttpFileResponseFactory(new ResponseFactory(), new StreamFactory());
        $this->request = new ServerRequest('GET', 'http://www.example.com/some.file');
    }

    public function testDefaultMimeTypeIsReturnedIfNotSpecified(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $response = $this->factory->buildFromString(
            $this->request,
            $contents
        );

        self::assertSame(
            'application/octet-stream',
            $response->getHeaderLine('Content-Type')
        );
    }

    public function testManualMimeTypeIsUsed(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $mime = 'something/that-does-not-make-sense';

        $response = $this->factory->buildFromString(
            $this->request,
            $contents,
            $mime
        );

        self::assertSame(
            $mime,
            $response->getHeaderLine('Content-Type')
        );
    }

    public function testCorrectBodyContentsAreReturned(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $response = $this->factory->buildFromString(
            $this->request,
            $contents
        );

        self::assertSame(
            $contents,
            (string)$response->getBody()
        );
    }

    public function testCorrectContentLengthIsReturned(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $response = $this->factory->buildFromString(
            $this->request,
            $contents
        );

        $expectedSize = strlen($contents);
        self::assertGreaterThan(0, $expectedSize);

        self::assertSame(
            $expectedSize,
            (int)$response->getHeaderLine('Content-Length')
        );
    }

    public function testCorrectModificationTimeIsReturned(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $expectedModificationTime = 1234567;

        $response = $this->factory->buildFromString(
            $this->request,
            $contents,
            null,
            $expectedModificationTime
        );

        self::assertSame(
            $expectedModificationTime,
            strtotime($response->getHeaderLine('Last-Modified'))
        );
    }

    public function testReasonableETagIsReturned(): void
    {
        $contents = file_get_contents(self::TEST_CONFIG_DIR . '/HttpFileResponse/tux.png');
        self::assertNotFalse($contents);
        self::assertNotEmpty($contents);

        $response = $this->factory->buildFromString(
            $this->request,
            $contents
        );

        $eTag = trim($response->getHeaderLine('ETag'), '"');

        self::assertNotEmpty($eTag);
        self::assertMatchesRegularExpression('=^[0-9a-zA-Z\\.\\-\\_\\@]{32,}$=', $eTag);
    }
}
