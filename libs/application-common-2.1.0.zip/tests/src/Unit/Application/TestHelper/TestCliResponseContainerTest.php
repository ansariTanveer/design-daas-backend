<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\TestHelper;

use Application\Common\Application\TestHelper\TestCliResponseContainer;
use Application\Test\TestCase;
use InvalidArgumentException;

final class TestCliResponseContainerTest extends TestCase
{
    public function testCorrectExitCodeIsReturned(): void
    {
        $expectedExitCode = 42;

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $container = new TestCliResponseContainer($expectedExitCode, $stdOut, $stdErr);

        self::assertSame($expectedExitCode, $container->exitCode());
    }

    public function testCorrectStdOutIsReturned(): void
    {
        $expectedStdOut = 'StdOut Content';

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        fwrite($stdOut, $expectedStdOut);

        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $container = new TestCliResponseContainer(42, $stdOut, $stdErr);

        self::assertSame($expectedStdOut, $container->stdOut());
    }

    public function testCorrectStdErrIsReturned(): void
    {
        $expectedStdErr = 'StdErr Content';

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);

        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);
        fwrite($stdErr, $expectedStdErr);

        $container = new TestCliResponseContainer(42, $stdOut, $stdErr);

        self::assertSame($expectedStdErr, $container->stdErr());
    }

    public function testFormattedStringContainsExitCode(): void
    {
        $expectedExitCode = 42;

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $container = new TestCliResponseContainer($expectedExitCode, $stdOut, $stdErr);

        self::assertStringContainsString(
            (string)$expectedExitCode,
            $container->formatAsString()
        );
    }

    public function testFormattedStringContainsStdOut(): void
    {
        $expectedStdOut = 'StdOut Content';

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        fwrite($stdOut, $expectedStdOut);

        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $container = new TestCliResponseContainer(42, $stdOut, $stdErr);

        self::assertStringContainsString(
            $expectedStdOut,
            $container->formatAsString()
        );
    }

    public function testFormattedStringContainsStdErr(): void
    {
        $expectedStdErr = 'StdErr Content';

        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);

        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);
        fwrite($stdErr, $expectedStdErr);

        $container = new TestCliResponseContainer(42, $stdOut, $stdErr);

        self::assertStringContainsString(
            $expectedStdErr,
            $container->formatAsString()
        );
    }

    public function testInvalidStdOutResourceThrowsException(): void
    {
        /** @var resource $stdOut */
        $stdOut = 'invalid';

        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid output resource');

        new TestCliResponseContainer(42, $stdOut, $stdErr);
    }

    public function testInvalidStdErrResourceThrowsException(): void
    {
        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);

        /** @var resource $stdErr */
        $stdErr = 'invalid';

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid error resource');

        new TestCliResponseContainer(42, $stdOut, $stdErr);
    }

    public function testCastingToStringIsSameAsFormattedString(): void
    {
        $stdOut = fopen('php://memory', 'r+');
        assert($stdOut !== false);
        $stdErr = fopen('php://memory', 'r+');
        assert($stdErr !== false);

        $container = new TestCliResponseContainer(42, $stdOut, $stdErr);

        self::assertSame(
            $container->formatAsString(),
            (string)$container
        );
    }
}
