<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application;

use Application\Common\Application\ApplicationContextInterface;
use Application\Common\Application\ApplicationContextResetEvent;
use Application\Common\Application\SimpleFileContext;
use Application\Test\Assets\Application\ServiceWithServiceDependency;
use Application\Test\Assets\Application\ServiceWithStringParameter;
use Application\Test\TestCase;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\RequestFactoryInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Psr\Http\Message\StreamFactoryInterface;
use Psr\Http\Message\UploadedFileFactoryInterface;
use Psr\Http\Message\UriFactoryInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface as SymfonyComponentEventDispatcherInterface;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface as SymfonyContractEventDispatcherInterface;

final class SimpleFileContextTest extends TestCase
{
    private SimpleFileContext $context;

    protected function setUp(): void
    {
        parent::setUp();

        $this->context = new SimpleFileContext(
            [
                self::TEST_CONFIG_DIR . '/Application/container_entries_1.static.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_2.static.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_3.static.php',
            ],
            [
                self::TEST_CONFIG_DIR . '/Application/container_entries_1.env.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_2.env.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_3.env.php',
            ]
        );
    }

    private function applyEnvironmentVariables(): void
    {
        $this->context->applyEnvironmentVariablesFromServer(
            [
                'environment_1' => 'environment_value_1',
                'environment_2' => 'environment_value_2',
                'environment_3' => 'environment_value_3',
            ]
        );
    }

    public function testStaticEntriesAreLoadedInOrder(): void
    {
        self::assertSame(
            'static_value_1',
            $this->context->container()->get('static_1')
        );

        self::assertSame(
            'static_value_2',
            $this->context->container()->get('static_2')
        );
    }

    public function testEnvironmentEntriesAreLoadedInOrder(): void
    {
        $this->applyEnvironmentVariables();

        self::assertSame(
            'environment_value_1',
            $this->context->container()->get('environment_1')
        );

        self::assertSame(
            'environment_value_2',
            $this->context->container()->get('environment_2')
        );
    }

    public function testEnvironmentVariablesArePassedCorrectly(): void
    {
        $this->applyEnvironmentVariables();

        self::assertSame(
            'environment_value_2',
            $this->context->container()->get('environment_2')
        );
    }

    public function testResetDoesCreateNewContainer(): void
    {
        $originalContainer = $this->context->container();
        $originalContainer->set('some_name', 'some_value');

        self::assertTrue($originalContainer->has('some_name'));

        $this->context->reset();
        $newContainer = $this->context->container();

        self::assertNotSame($originalContainer, $newContainer);
        self::assertFalse($newContainer->has('some_name'));
    }

    public function testResetDoesSendResetEvent(): void
    {
        $mockDispatcher = $this->createMock(PsrEventDispatcherInterface::class);
        $mockDispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(function (object $event): object {
                self::assertInstanceOf(ApplicationContextResetEvent::class, $event);
                return $event;
            });

        $originalContainer = $this->context->container();
        $originalContainer->set(PsrEventDispatcherInterface::class, $mockDispatcher);

        $this->context->reset();
    }

    public function testEnvironmentEntriesAreReset(): void
    {
        $this->applyEnvironmentVariables();

        self::assertNotNull($this->context->container()->get('environment_2'));

        $this->context->reset();

        self::assertNull($this->context->container()->get('environment_2'));
    }

    public function testContainerAutowiringIsEnabled(): void
    {
        $service = $this->context->container()->get(ServiceWithServiceDependency::class);

        self::assertInstanceOf(ServiceWithServiceDependency::class, $service);
    }

    public function testContainerProcessesAnnotations(): void
    {
        $this->applyEnvironmentVariables();

        $service = $this->context->container()->get(ServiceWithStringParameter::class);

        self::assertInstanceOf(ServiceWithStringParameter::class, $service);

        self::assertSame(
            'environment_value_1',
            $service->parameter
        );
    }

    /**
     * @return array<string, array<string>>
     */
    public function defaultContainerServicesDataProvider(): array
    {
        $classes = [
            RequestFactoryInterface::class,
            ServerRequestFactoryInterface::class,
            UriFactoryInterface::class,
            UploadedFileFactoryInterface::class,
            StreamFactoryInterface::class,
            ResponseFactoryInterface::class,
            SymfonyComponentEventDispatcherInterface::class,
            SymfonyContractEventDispatcherInterface::class,
            PsrEventDispatcherInterface::class,
        ];

        $dataProvider = [];
        foreach ($classes as $class) {
            $dataProvider[$class] = [$class];
        }
        return $dataProvider;
    }

    /**
     * @dataProvider defaultContainerServicesDataProvider
     */
    public function testDefaultContainerServicesAreRegisteredByDefault(string $service): void
    {
        $context = new SimpleFileContext([], []);

        self::assertTrue($context->container()->has($service));
    }

    /**
     * @dataProvider defaultContainerServicesDataProvider
     */
    public function testDefaultContainerServicesAreNotRegisteredIfDisabled(string $service): void
    {
        $context = new SimpleFileContext([], [], false);

        self::assertFalse($context->container()->has($service));
    }

    public function testStaticEntriesCanBeDecorated(): void
    {
        self::assertSame(
            'static_value_3_decorated',
            $this->context->container()->get('static_3')
        );
    }

    public function testEnvironmentEntriesCanBeDecorated(): void
    {
        $this->applyEnvironmentVariables();

        self::assertSame(
            'environment_value_3_decorated',
            $this->context->container()->get('environment_3')
        );
    }

    public function testEnvironmentVariablesCanBeAppliedAfterEntriesHaveBeenAddedManually(): void
    {
        $this->context->container()->set('manual_1', 'manual_value_1');

        $this->applyEnvironmentVariables();

        self::assertTrue($this->context->container()->has('manual_1'));
        self::assertTrue($this->context->container()->has('environment_1'));
    }

    /**
     * @doesNotPerformAssertions
     */
    public function testResetWithoutRegisteredEventDispatcherDoesNotTryToSendEvent(): void
    {
        $context = new SimpleFileContext([], [], false);
        $context->reset();
    }

    /**
     * @doesNotPerformAssertions
     */
    public function testOverriddenEventDispatcherIsNotUsedWithoutEnvironmentEntries(): void
    {
        $context = new SimpleFileContext(
            [
                self::TEST_CONFIG_DIR . '/Application/event_dispatcher_static.php',
            ],
            [
                self::TEST_CONFIG_DIR . '/Application/event_dispatcher_environment.php',
            ]
        );
        $context->reset();
    }

    public function testBuilderReturnsCorrectType(): void
    {
        /** @var ApplicationContextInterface $context */
        $context = SimpleFileContext::builder(false)
            ->build();

        self::assertInstanceOf(SimpleFileContext::class, $context);
    }
}
