<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application;

use Application\Common\Application\ApplicationContextInterface;
use Application\Common\Application\Cli\CliApplication;
use Application\Common\Application\Cli\CliContextInterface;
use Application\Common\Application\GenericApplication;
use Application\Common\Application\Http\HttpApplication;
use Application\Common\Application\Http\HttpContextInterface;
use Application\Common\Application\Http\HttpDispatcherInterface;
use Application\Common\PhpIniValueConverter;
use Application\Common\SymfonyConsole\ConsoleOutput;
use Application\Test\TestCase;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use ReflectionClass;
use Symfony\Component\Console\Input\StreamableInputInterface;
use Symfony\Component\Console\Output\StreamOutput;

/**
 * @backupGlobals enabled
 */
final class ApplicationRuntimeEnvironmentFromGlobalsTest extends TestCase
{
    public function testGenericApplicationUsesCorrectGlobals(): void
    {
        $context = $this->createMock(ApplicationContextInterface::class);
        $context->expects(self::once())
            ->method('applyEnvironmentVariablesFromServer')
            ->willReturnCallback(
                function (array $server) {
                    self::assertSame($_SERVER, $server);
                }
            );

        $application = new GenericApplication($context);

        $application->setRuntimeEnvironmentFromGlobals();
    }

    public function testCliApplicationUsesCorrectGlobals(): void
    {
        $_SERVER['__PHPUNIT_EXPECTED_ADDITIONAL_PROPERTY'] = 42;

        $context = $this->createMock(CliContextInterface::class);
        $context->expects(self::once())
            ->method('applyEnvironmentVariablesFromServer')
            ->willReturnCallback(
                function (array $server) {
                    self::assertSame($_SERVER, $server);
                }
            );

        $application = new CliApplication($context);
        $application->setRuntimeEnvironmentFromGlobals();

        $applicationReflection = new ReflectionClass($application);

        $inputProperty = $applicationReflection->getProperty('input');
        $inputProperty->setAccessible(true);
        $inputValue = $inputProperty->getValue($application);
        self::assertInstanceOf(StreamableInputInterface::class, $inputValue);
        self::assertSame(STDIN, $inputValue->getStream());

        $outputProperty = $applicationReflection->getProperty('output');
        $outputProperty->setAccessible(true);
        $outputValue = $outputProperty->getValue($application);
        self::assertInstanceOf(ConsoleOutput::class, $outputValue);
        $stdOutValue = $outputValue->stdOut();
        self::assertInstanceOf(StreamOutput::class, $stdOutValue);
        $stdErrValue = $outputValue->stdErr();
        self::assertInstanceOf(StreamOutput::class, $stdErrValue);
        self::assertSame(STDOUT, $stdOutValue->getStream());
        self::assertSame(STDERR, $stdErrValue->getStream());
    }

    public function testHttpApplicationUsesCorrectGlobals(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com:8080';
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI'] = '/subdir/hello/world';
        $_SERVER['PHP_SELF'] = '/subdir/index.php';
        $_SERVER['SCRIPT_NAME'] = '/subdir/index.php';
        $_SERVER['SCRIPT_FILENAME'] = '/path/to/application/public/subdir/index.php';

        $uploadFile = self::TEST_TMP_DIR . '/does-not-matter.file';
        file_put_contents($uploadFile, 'something');

        $_GET['__PHPUNIT_EXPECTED_ADDITIONAL_GET_PROPERTY'] = 42;
        $_POST['__PHPUNIT_EXPECTED_ADDITIONAL_POST_PROPERTY'] = 4242;
        $_COOKIE['__PHPUNIT_EXPECTED_ADDITIONAL_COOKIE_PROPERTY'] = 1337;
        $_SERVER['__PHPUNIT_EXPECTED_ADDITIONAL_SERVER_PROPERTY'] = 7331;
        $_FILES['__PHPUNIT_EXPECTED_ADDITIONAL_FILE_PROPERTY'] = [
            'name' => 'FileName',
            'type' => 'file/type',
            'tmp_name' => $uploadFile,
            'error' => UPLOAD_ERR_OK,
            'size' => filesize($uploadFile),
        ];

        $context = $this->createMock(HttpContextInterface::class);
        $context->expects(self::once())
            ->method('applyEnvironmentVariablesFromServer')
            ->willReturnCallback(
                function (array $server) {
                    self::assertSame($_SERVER, $server);
                }
            );

        $application = new HttpApplication($context);
        $application->setRuntimeEnvironmentFromGlobals();

        $applicationReflection = new ReflectionClass($application);

        $requestProperty = $applicationReflection->getProperty('request');
        $requestProperty->setAccessible(true);
        $requestValue = $requestProperty->getValue($application);
        self::assertInstanceOf(ServerRequestInterface::class, $requestValue);
        self::assertSame($_GET, $requestValue->getQueryParams());
        self::assertSame($_POST, $requestValue->getParsedBody());
        self::assertSame($_COOKIE, $requestValue->getCookieParams());
        self::assertSame($_SERVER, $requestValue->getServerParams());
        self::assertArrayHasKey('__PHPUNIT_EXPECTED_ADDITIONAL_FILE_PROPERTY', $requestValue->getUploadedFiles());
        self::assertIsNotClosedResource($requestValue->getBody()->detach());
    }

    public function testHttpApplicationUsesRealInputStreamIfBodyIsNotTooLarge(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com:8080';
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI'] = '/subdir/hello/world';
        $_SERVER['PHP_SELF'] = '/subdir/index.php';
        $_SERVER['SCRIPT_NAME'] = '/subdir/index.php';
        $_SERVER['SCRIPT_FILENAME'] = '/path/to/application/public/subdir/index.php';

        $_SERVER['CONTENT_LENGTH'] =
            PhpIniValueConverter::convertShorthandByteValue((string)ini_get('post_max_size')) - 1;

        $context = $this->createMock(HttpContextInterface::class);

        $application = new HttpApplication($context);
        $application->setRuntimeEnvironmentFromGlobals();

        $applicationReflection = new ReflectionClass($application);

        $requestProperty = $applicationReflection->getProperty('request');
        $requestProperty->setAccessible(true);
        $requestValue = $requestProperty->getValue($application);
        self::assertInstanceOf(ServerRequestInterface::class, $requestValue);

        $inputStream = $requestValue->getBody()->detach();
        self::assertNotNull($inputStream);
        $metadata = stream_get_meta_data($inputStream);
        self::assertSame('php://input', $metadata['uri']);
    }

    public function testHttpApplicationUsesAlternativeInputStreamIfBodyIsTooLarge(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com:8080';
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI'] = '/subdir/hello/world';
        $_SERVER['PHP_SELF'] = '/subdir/index.php';
        $_SERVER['SCRIPT_NAME'] = '/subdir/index.php';
        $_SERVER['SCRIPT_FILENAME'] = '/path/to/application/public/subdir/index.php';

        $_SERVER['CONTENT_LENGTH'] =
            PhpIniValueConverter::convertShorthandByteValue((string)ini_get('post_max_size')) + 1;

        $context = $this->createMock(HttpContextInterface::class);

        $application = new HttpApplication($context);
        $application->setRuntimeEnvironmentFromGlobals();

        $applicationReflection = new ReflectionClass($application);

        $requestProperty = $applicationReflection->getProperty('request');
        $requestProperty->setAccessible(true);
        $requestValue = $requestProperty->getValue($application);
        self::assertInstanceOf(ServerRequestInterface::class, $requestValue);

        $inputStream = $requestValue->getBody()->detach();
        self::assertNotNull($inputStream);
        $metadata = stream_get_meta_data($inputStream);
        self::assertSame('php://memory', $metadata['uri']);
    }

    public function testHttpApplicationCorrectlyFlagsTooLargeRequestBody(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com:8080';
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $_SERVER['REQUEST_URI'] = '/subdir/hello/world';
        $_SERVER['PHP_SELF'] = '/subdir/index.php';
        $_SERVER['SCRIPT_NAME'] = '/subdir/index.php';
        $_SERVER['SCRIPT_FILENAME'] = '/path/to/application/public/subdir/index.php';

        $_SERVER['CONTENT_LENGTH'] =
            PhpIniValueConverter::convertShorthandByteValue((string)ini_get('post_max_size')) + 1;

        $context = $this->createMock(HttpContextInterface::class);

        $application = new HttpApplication($context);
        $application->setRuntimeEnvironmentFromGlobals();

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function (ServerRequestInterface $request, bool $bodyTooLarge): ResponseInterface {
                    self::assertTrue($bodyTooLarge);
                    return $this->createStub(ResponseInterface::class);
                }
            );
        $context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        $application->execute();
    }
}
