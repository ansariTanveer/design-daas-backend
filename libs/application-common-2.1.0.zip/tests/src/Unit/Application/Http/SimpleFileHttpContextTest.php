<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Http;

use Application\Common\Application\ApplicationContextInterface;
use Application\Common\Application\Http\HttpDispatcherInterface;
use Application\Common\Application\Http\SimpleFileHttpContext;
use Application\Test\TestCase;
use PHPUnit\Framework\MockObject\MockObject;

final class SimpleFileHttpContextTest extends TestCase
{
    private const DISPATCHER_ENTRY_NAME = 'application.dispatcher';

    private SimpleFileHttpContext $context;

    /**
     * @var HttpDispatcherInterface|MockObject
     */
    private HttpDispatcherInterface $dispatcher;

    protected function setUp(): void
    {
        parent::setUp();

        $this->context = new SimpleFileHttpContext(
            self::DISPATCHER_ENTRY_NAME,
            [
                self::TEST_CONFIG_DIR . '/Application/container_entries_1.static.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_2.static.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_3.static.php',
            ],
            [
                self::TEST_CONFIG_DIR . '/Application/container_entries_1.env.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_2.env.php',
                self::TEST_CONFIG_DIR . '/Application/container_entries_3.env.php',
            ]
        );

        $this->dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $this->context->container()->set(self::DISPATCHER_ENTRY_NAME, $this->dispatcher);
    }

    private function applyEnvironmentVariables(): void
    {
        $this->context->applyEnvironmentVariablesFromServer(
            [
                'environment_1' => 'environment_value_1',
                'environment_2' => 'environment_value_2',
                'environment_3' => 'environment_value_3',
            ]
        );
    }

    public function testEnvironmentVariablesArePassedCorrectly(): void
    {
        $this->applyEnvironmentVariables();

        self::assertSame(
            'environment_value_2',
            $this->context->container()->get('environment_2')
        );
    }

    public function testEnvironmentEntriesAreReset(): void
    {
        $this->applyEnvironmentVariables();

        self::assertNotNull($this->context->container()->get('environment_2'));

        $this->context->reset();

        self::assertNull($this->context->container()->get('environment_2'));
    }

    public function testCorrectDispatcherIsReturned(): void
    {
        self::assertSame(
            $this->dispatcher,
            $this->context->dispatcher()
        );
    }

    public function testBuilderReturnsCorrectType(): void
    {
        /** @var ApplicationContextInterface $context */
        $context = SimpleFileHttpContext::builder('some_dispatcher_name', false)
            ->build();

        self::assertInstanceOf(SimpleFileHttpContext::class, $context);
    }
}
