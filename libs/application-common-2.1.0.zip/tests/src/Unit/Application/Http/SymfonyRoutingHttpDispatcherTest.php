<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Http;

use Application\Common\Application\Http\HttpDispatcherFinishedEvent;
use Application\Common\Application\Http\SymfonyRoutingHttpDispatcher;
use Application\Common\Application\UnexpectedExceptionEvent;
use Application\Common\SymfonyRouting\Psr7RouterInterface;
use Application\Test\TestCase;
use Closure;
use DI\Container;
use Exception;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ServerRequest;
use PHPUnit\Framework\MockObject\MockObject;
use Psr\EventDispatcher\EventDispatcherInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use RuntimeException;
use Throwable;

final class SymfonyRoutingHttpDispatcherTest extends TestCase
{
    private Container $container;

    /**
     * @var EventDispatcherInterface|MockObject
     */
    private EventDispatcherInterface $eventDispatcher;

    /**
     * @var Psr7RouterInterface|MockObject
     */
    private Psr7RouterInterface $router;

    protected function setUp(): void
    {
        parent::setUp();
        $this->container = new Container();
        $this->eventDispatcher = $this->createMock(EventDispatcherInterface::class);
        $this->router = $this->createMock(Psr7RouterInterface::class);
        $this->router->method('routeNameAttribute')->willReturn('__PHPUNIT_ROUTE_NAME');
        $this->router->method('routeParametersAttribute')->willReturn('__PHPUNIT_ROUTE_PARAMETERS');
        $this->router->method('routeOptionsAttribute')->willReturn('__PHPUNIT_ROUTE_OPTIONS');
    }

    private function setResolvedRoute(callable $callback): void
    {
        $callback = Closure::fromCallable($callback);
        $this->router->expects(self::atLeastOnce())
            ->method('process')
            ->willReturnCallback(
                function (
                    ServerRequestInterface $request,
                    RequestHandlerInterface $handler
                ) use (
                    $callback
                ): ResponseInterface {
                    $request = $request->withAttribute($this->router->routeNameAttribute(), $callback)
                        ->withAttribute($this->router->routeParametersAttribute(), [])
                        ->withAttribute($this->router->routeOptionsAttribute(), []);
                    return $handler->handle($request);
                }
            );
    }

    /**
     * @param array<MiddlewareInterface|RequestHandlerInterface|callable> $preRouteMiddlewareQueue
     * @param array<MiddlewareInterface|RequestHandlerInterface|callable> $postRouteMiddlewareQueue
     */
    private function buildDispatcher(
        array $preRouteMiddlewareQueue,
        array $postRouteMiddlewareQueue
    ): SymfonyRoutingHttpDispatcher {
        return new SymfonyRoutingHttpDispatcher(
            $this->container,
            $this->router,
            $preRouteMiddlewareQueue,
            $postRouteMiddlewareQueue,
            $this->eventDispatcher
        );
    }

    public function testResolvedRouteIsCalled(): void
    {
        $expectedResponse = new Response();
        $this->setResolvedRoute(
            function (ServerRequestInterface $request) use ($expectedResponse): ResponseInterface {
                return $expectedResponse;
            }
        );

        $dispatcher = $this->buildDispatcher([], []);

        $actualResponse = $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            false
        );

        self::assertSame(
            $expectedResponse,
            $actualResponse
        );
    }

    public function testTooLargeBodyReturnsHttp413ByDefault(): void
    {
        $dispatcher = $this->buildDispatcher([], []);

        $response = $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            true
        );

        self::assertSame(
            413,
            $response->getStatusCode()
        );
    }

    public function testSpecifiedMiddlewaresAreExecutedInCorrectOrder(): void
    {
        $this->setResolvedRoute(
            function (ServerRequestInterface $request): ResponseInterface {
                self::assertSame(4, $request->getAttribute('middleware_counter'));
                return (new Response())->withHeader(
                    'x-middleware-counter',
                    (string)$request->getAttribute('middleware_counter')
                );
            }
        );

        $dispatcher = $this->buildDispatcher(
            [
                function (ServerRequestInterface $request, callable $next): ResponseInterface {
                    self::assertNull($request->getAttribute('middleware_counter'));
                    return $next($request->withAttribute('middleware_counter', 1));
                },
                function (ServerRequestInterface $request, callable $next): ResponseInterface {
                    self::assertNull($request->getAttribute($this->router->routeNameAttribute()));
                    self::assertSame(1, $request->getAttribute('middleware_counter'));
                    return $next($request->withAttribute('middleware_counter', 2));
                },
            ],
            [
                function (ServerRequestInterface $request, callable $next): ResponseInterface {
                    self::assertNotNull($request->getAttribute($this->router->routeNameAttribute()));
                    self::assertSame(2, $request->getAttribute('middleware_counter'));
                    return $next($request->withAttribute('middleware_counter', 3));
                },
                function (ServerRequestInterface $request, callable $next): ResponseInterface {
                    self::assertSame(3, $request->getAttribute('middleware_counter'));
                    return $next($request->withAttribute('middleware_counter', 4));
                },
            ]
        );

        $response = $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            false
        );

        self::assertSame(
            '4',
            $response->getHeaderLine('x-middleware-counter')
        );
    }

    public function testThrownExceptionIsNotCaught(): void
    {
        $expectedException = new Exception('Expected exception');
        $this->setResolvedRoute(
            function (ServerRequestInterface $request) use ($expectedException): ResponseInterface {
                throw $expectedException;
            }
        );

        $dispatcher = $this->buildDispatcher([], []);

        try {
            $dispatcher->dispatch(
                new ServerRequest('GET', '/'),
                false
            );
            self::fail('Expected exception not thrown');
        } catch (Throwable $actualException) {
            self::assertSame($expectedException, $actualException);
        }
    }

    public function testDispatcherFinishedEventIsSentOnSuccess(): void
    {
        $expectedStatusCode = 242;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedStatusCode, &$eventWasSent): object {
                if ($event instanceof HttpDispatcherFinishedEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertTrue($event->successful());
                    self::assertSame($expectedStatusCode, $event->statusCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $this->setResolvedRoute(
            function (ServerRequestInterface $request) use ($expectedStatusCode): ResponseInterface {
                return new Response($expectedStatusCode);
            }
        );

        $dispatcher = $this->buildDispatcher([], []);
        $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            false
        );

        self::assertTrue($eventWasSent);
    }

    public function testDispatcherFinishedEventIsSentOnFailure(): void
    {
        $expectedStatusCode = 242;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedStatusCode, &$eventWasSent): object {
                if ($event instanceof HttpDispatcherFinishedEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertFalse($event->successful());
                    self::assertSame($expectedStatusCode, $event->statusCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $this->setResolvedRoute(
            function (ServerRequestInterface $request) use ($expectedStatusCode): ResponseInterface {
                throw new RuntimeException('Some Message', $expectedStatusCode);
            }
        );

        $dispatcher = $this->buildDispatcher([], []);

        $this->expectExceptionCode($expectedStatusCode);
        $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            false
        );

        self::assertTrue($eventWasSent);
    }

    public function testUnexpectedExceptionEventIsSentOnFailure(): void
    {
        $expectedStatusCode = 242;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedStatusCode, &$eventWasSent): object {
                if ($event instanceof UnexpectedExceptionEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertSame($expectedStatusCode, $event->exception()->getCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $this->setResolvedRoute(
            function (ServerRequestInterface $request) use ($expectedStatusCode): ResponseInterface {
                throw new RuntimeException('Some Message', $expectedStatusCode);
            }
        );

        $dispatcher = $this->buildDispatcher([], []);

        $this->expectExceptionCode($expectedStatusCode);
        $dispatcher->dispatch(
            new ServerRequest('GET', '/'),
            false
        );

        self::assertTrue($eventWasSent);
    }

    /**
     * @doesNotPerformAssertions
     */
    public function testResetDoesNotCauseErrors(): void
    {
        $dispatcher = $this->buildDispatcher([], []);
        $dispatcher->reset();
    }
}
