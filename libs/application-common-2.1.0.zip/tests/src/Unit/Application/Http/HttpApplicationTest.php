<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Http;

use Application\Common\Application\Http\HttpApplication;
use Application\Common\Application\Http\HttpContextInterface;
use Application\Common\Application\Http\HttpDispatcherInterface;
use Application\Test\TestCase;
use DI\Container;
use Exception;
use InvalidArgumentException;
use PHPUnit\Framework\MockObject\MockObject;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Throwable;

final class HttpApplicationTest extends TestCase
{
    /**
     * @var HttpContextInterface|MockObject
     */
    private HttpContextInterface $context;

    private HttpApplication $application;

    protected function setUp(): void
    {
        parent::setUp();
        $this->context = $this->createMock(HttpContextInterface::class);
        $this->application = new HttpApplication($this->context);
    }

    public function testInvalidInputStreamThrowsException(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid input resource');

        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [];
        /** @psalm-var resource $inputStream */
        $inputStream = 'invalid';

        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);
    }

    public function testCorrectEnvironmentVariablesArePassedToApplicationContext(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');

        $this->context->expects(self::once())
            ->method('applyEnvironmentVariablesFromServer')
            ->willReturnCallback(
                function (array $passedServer) use ($server): void {
                    self::assertSame($server, $passedServer);
                }
            );

        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);
    }

    public function testContainerFromApplicationContextIsReturned(): void
    {
        $container = $this->createStub(Container::class);
        $this->context->expects(self::atLeastOnce())
            ->method('container')
            ->willReturn($container);

        self::assertSame(
            $container,
            $this->application->container()
        );
    }

    public function testApplicationResetAlsoResetsContext(): void
    {
        $this->context->expects(self::once())
            ->method('reset');

        $this->application->reset();
    }

    public function testCorrectRequestIsPassedToDispatcher(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');
        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function (ServerRequestInterface $request, bool $bodyTooLarge): ResponseInterface {
                    self::assertSame('GET', $request->getMethod());
                    self::assertSame('http://example.com:8080/subdir/hello/world', (string)$request->getUri());
                    self::assertFalse($bodyTooLarge);
                    return $this->createStub(ResponseInterface::class);
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        $this->application->execute();
    }

    public function testTooLargeRequestBodyFlagIsPassedToDispatcher(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');
        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);
        $this->application->flagTooLargeRequestBody();

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function (ServerRequestInterface $request, bool $bodyTooLarge): ResponseInterface {
                    self::assertSame('GET', $request->getMethod());
                    self::assertSame('http://example.com:8080/subdir/hello/world', (string)$request->getUri());
                    self::assertTrue($bodyTooLarge);
                    return $this->createStub(ResponseInterface::class);
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        $this->application->execute();
    }

    public function testCorrectResponseIsReturnedByApplication(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');
        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);
        $this->application->flagTooLargeRequestBody();

        $expectedResponse = $this->createStub(ResponseInterface::class);

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function () use ($expectedResponse): ResponseInterface {
                    return $expectedResponse;
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        self::assertSame(
            $expectedResponse,
            $this->application->execute()
        );
    }

    public function testApplicationContextIsNotResetOnSuccessfulExecution(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');
        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function (): ResponseInterface {
                    return $this->createMock(ResponseInterface::class);
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);
        $this->context->expects(self::never())
            ->method('reset');

        $this->application->execute();
    }

    public function testApplicationContextIsNotResetIfDispatcherThrowsException(): void
    {
        $get = [];
        $post = [];
        $cookie = [];
        $files = [];
        $server = [
            'HTTP_HOST' => 'example.com:8080',
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/subdir/hello/world',
            'PHP_SELF' => '/subdir/index.php',
            'SCRIPT_NAME' => '/subdir/index.php',
            'SCRIPT_FILENAME' => '/path/to/application/public/subdir/index.php',
        ];
        /** @psalm-var resource $inputStream */
        $inputStream = fopen('php://memory', 'rb');
        $this->application->setRuntimeEnvironment($get, $post, $cookie, $files, $server, $inputStream);

        $expectedException = new Exception('Expected exception');

        $dispatcher = $this->createMock(HttpDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function () use ($expectedException): ResponseInterface {
                    throw $expectedException;
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);
        $this->context->expects(self::never())
            ->method('reset');

        try {
            $this->application->execute();
            self::fail('Expected exception not thrown');
        } catch (Throwable $actualException) {
            self::assertSame($expectedException, $actualException);
        }
    }
}
