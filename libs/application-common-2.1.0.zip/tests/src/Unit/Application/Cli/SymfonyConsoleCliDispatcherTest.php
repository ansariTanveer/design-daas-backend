<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Cli;

use Application\Common\Application\Cli\CliDispatcherFinishedEvent;
use Application\Common\Application\Cli\SymfonyConsoleApplicationReadyEvent;
use Application\Common\Application\Cli\SymfonyConsoleCliDispatcher;
use Application\Common\Application\UnexpectedExceptionEvent;
use Application\Common\SymfonyConsole\CommandCacheInterface;
use Application\Common\SymfonyConsole\ConsoleOutput;
use Application\Test\TestCase;
use Consolidation\AnnotatedCommand\AnnotatedCommand;
use Consolidation\AnnotatedCommand\AnnotationData;
use Consolidation\AnnotatedCommand\CommandProcessor;
use Consolidation\AnnotatedCommand\Hooks\HookManager;
use DI\Container;
use Exception;
use PHPUnit\Framework\MockObject\MockObject;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use RuntimeException;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\ConsoleEvents;
use Symfony\Component\Console\Event\ConsoleCommandEvent;
use Symfony\Component\Console\Event\ConsoleTerminateEvent;
use Symfony\Component\Console\Input\ArgvInput;
use Symfony\Component\Console\Output\StreamOutput;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface as SymfonyContractEventDispatcherInterface;

final class SymfonyConsoleCliDispatcherTest extends TestCase
{
    /**
     * @var string
     */
    private const COMMAND_NAME = 'test:command';

    /**
     * @var Container|MockObject
     */
    private Container $container;

    /**
     * @var PsrEventDispatcherInterface|MockObject
     */
    private PsrEventDispatcherInterface $eventDispatcher;

    /**
     * @var CommandCacheInterface|MockObject
     */
    private CommandCacheInterface $commandCache;

    private string $applicationName;

    private string $applicationVersion;

    private SymfonyConsoleCliDispatcher $dispatcher;

    protected function setUp(): void
    {
        parent::setUp();
        $this->container = $this->createMock(Container::class);
        $this->eventDispatcher = $this->createMock(PsrEventDispatcherInterface::class);
        $this->commandCache = $this->createMock(CommandCacheInterface::class);
        $this->applicationName = 'ApplicationName';
        $this->applicationVersion = 'ApplicationVersion';
        $this->dispatcher = new SymfonyConsoleCliDispatcher(
            $this->container,
            $this->commandCache,
            $this->applicationName,
            $this->applicationVersion,
            $this->eventDispatcher
        );
    }

    private function setupCommand(callable $callback): void
    {
        $this->commandCache->expects(self::once())
            ->method('loadCommandList')
            ->with($this->container)
            ->willReturn(
                [
                    (new AnnotatedCommand(self::COMMAND_NAME))
                        ->setCommandCallback($callback)
                        ->setAnnotationData(new AnnotationData())
                        ->setCommandProcessor(
                            (new CommandProcessor(new HookManager()))
                                ->setPassExceptions(true)
                        ),
                ]
            );
    }

    public function testResolvedCommandIsCalled(): void
    {
        $commandHasBeenCalled = false;
        $commandCallback = function () use (&$commandHasBeenCalled): int {
            $commandHasBeenCalled = true;
            return 0;
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($commandHasBeenCalled);
    }

    public function testCorrectExitCodeIsReturned(): void
    {
        $expectedExitCode = 42;
        $commandCallback = function () use ($expectedExitCode): int {
            return $expectedExitCode;
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        self::assertSame(
            $expectedExitCode,
            $this->dispatcher->dispatch($input, $output)
        );
    }

    public function testEmptyCommandDoesNotWriteToAnyStreams(): void
    {
        $commandCallback = function (): int {
            return 0;
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        fseek($stdIn, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdIn)
        );

        fseek($stdOut, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdOut)
        );

        fseek($stdErr, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdErr)
        );
    }

    public function testThrownExceptionIsOutputToStdErrAndCorrectExitCodeIsReturned(): void
    {
        $expectedErrorMessage = 'Expected Error Message';
        $expectedExitCode = 123;
        $commandCallback = function () use ($expectedErrorMessage, $expectedExitCode): int {
            throw new Exception($expectedErrorMessage, $expectedExitCode);
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        self::assertSame(
            $expectedExitCode,
            $this->dispatcher->dispatch($input, $output)
        );

        fseek($stdIn, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdIn)
        );

        fseek($stdOut, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdOut)
        );

        fseek($stdErr, 0);
        self::assertStringContainsString(
            $expectedErrorMessage,
            (string)stream_get_contents($stdErr)
        );
    }

    public function testApplicationNameAndVersionIsOutputFromBuiltinVersionCommand(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', '--version']);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        fseek($stdIn, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdIn)
        );

        fseek($stdOut, 0);
        self::assertStringContainsString(
            $this->applicationName,
            (string)stream_get_contents($stdOut)
        );
        fseek($stdOut, 0);
        self::assertStringContainsString(
            $this->applicationVersion,
            (string)stream_get_contents($stdOut)
        );

        fseek($stdErr, 0);
        self::assertSame(
            '',
            (string)stream_get_contents($stdErr)
        );
    }

    public function testApplicationReadyEventIsSentBeforeExecutingCommand(): void
    {
        $commandWasExecuted = false;
        $eventWasSent = false;

        $commandCallback = function () use (&$commandWasExecuted): int {
            self::assertFalse($commandWasExecuted);
            $commandWasExecuted = true;
            return 0;
        };
        $this->setupCommand($commandCallback);

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use (&$commandWasExecuted, &$eventWasSent): object {
                if ($event instanceof SymfonyConsoleApplicationReadyEvent) {
                    self::assertFalse($commandWasExecuted);
                    self::assertFalse($eventWasSent);
                    $eventWasSent = true;
                }
                return $event;
            });

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($eventWasSent);
    }

    public function testCommandAddedByApplicationReadyEventCanBeExecuted(): void
    {
        $commandWasExecuted = false;
        $commandCode = function () use (&$commandWasExecuted): int {
            self::assertFalse($commandWasExecuted);
            $commandWasExecuted = true;
            return 0;
        };
        $commandName = self::COMMAND_NAME . ':custom-command';

        $commandCallback = function (): void {
            self::fail('Command was not expected to be executed');
        };
        $this->setupCommand($commandCallback);

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($commandName, $commandCode): object {
                if ($event instanceof SymfonyConsoleApplicationReadyEvent) {
                    $command = new Command($commandName);
                    $command->setCode($commandCode);
                    $event->application()->add($command);
                }
                return $event;
            });

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', $commandName]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($commandWasExecuted);
    }

    public function testDispatcherFinishedEventIsSentOnSuccess(): void
    {
        $expectedExitCode = 42;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedExitCode, &$eventWasSent): object {
                if ($event instanceof CliDispatcherFinishedEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertTrue($event->successful());
                    self::assertSame($expectedExitCode, $event->exitCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $commandCallback = function () use ($expectedExitCode): int {
            return $expectedExitCode;
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($eventWasSent);
    }

    public function testDispatcherFinishedEventIsSentOnFailure(): void
    {
        $expectedExitCode = 42;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedExitCode, &$eventWasSent): object {
                if ($event instanceof CliDispatcherFinishedEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertFalse($event->successful());
                    self::assertSame($expectedExitCode, $event->exitCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $commandCallback = function () use ($expectedExitCode): int {
            throw new RuntimeException('Some Message', $expectedExitCode);
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($eventWasSent);
    }

    public function testUnexpectedExceptionEventIsSentOnFailure(): void
    {
        $expectedExitCode = 42;
        $eventWasSent = false;

        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(function (object $event) use ($expectedExitCode, &$eventWasSent): object {
                if ($event instanceof UnexpectedExceptionEvent) {
                    self::assertFalse($eventWasSent);
                    self::assertSame($expectedExitCode, $event->exception()->getCode());
                    $eventWasSent = true;
                }
                return $event;
            });

        $commandCallback = function () use ($expectedExitCode): int {
            throw new RuntimeException('Some Message', $expectedExitCode);
        };
        $this->setupCommand($commandCallback);

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $this->dispatcher->dispatch($input, $output);

        self::assertTrue($eventWasSent);
    }

    public function testEventDispatcherIsAttachedToSymfonyApplication(): void
    {
        $symfonyCommandEventWasSent = false;
        $symfonyTerminateEventWasSent = false;

        $symfonyEventDispatcher = $this->createMock(SymfonyContractEventDispatcherInterface::class);
        $symfonyEventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(
                function (
                    object $event,
                    ?string $eventName = null
                ) use (
                    &$symfonyCommandEventWasSent,
                    &$symfonyTerminateEventWasSent
                ): object {
                    if ($eventName === ConsoleEvents::COMMAND) {
                        self::assertFalse($symfonyCommandEventWasSent);
                        self::assertInstanceOf(ConsoleCommandEvent::class, $event);
                        $symfonyCommandEventWasSent = true;
                    }
                    if ($eventName === ConsoleEvents::TERMINATE) {
                        self::assertFalse($symfonyTerminateEventWasSent);
                        self::assertInstanceOf(ConsoleTerminateEvent::class, $event);
                        $symfonyTerminateEventWasSent = true;
                    }
                    return $event;
                }
            );

        $commandCallback = function (): int {
            return 0;
        };
        $this->setupCommand($commandCallback);

        $dispatcherWithSymfonyEventDispatcher = new SymfonyConsoleCliDispatcher(
            $this->container,
            $this->commandCache,
            $this->applicationName,
            $this->applicationVersion,
            $symfonyEventDispatcher
        );

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        $input = new ArgvInput(['application.php', self::COMMAND_NAME]);
        $input->setStream($stdIn);

        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $output = new ConsoleOutput(new StreamOutput($stdOut), new StreamOutput($stdErr));

        $dispatcherWithSymfonyEventDispatcher->dispatch($input, $output);

        self::assertTrue($symfonyCommandEventWasSent);
        self::assertTrue($symfonyTerminateEventWasSent);
    }

    /**
     * @doesNotPerformAssertions
     */
    public function testResetDoesNotCauseErrors(): void
    {
        $this->dispatcher->reset();
    }
}
