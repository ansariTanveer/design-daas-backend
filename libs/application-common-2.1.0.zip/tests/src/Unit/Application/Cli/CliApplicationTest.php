<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application\Cli;

use Application\Common\Application\Cli\CliApplication;
use Application\Common\Application\Cli\CliContextInterface;
use Application\Common\Application\Cli\CliDispatcherInterface;
use Application\Common\SymfonyConsole\ConsoleOutput;
use Application\Test\TestCase;
use DI\Container;
use Exception;
use InvalidArgumentException;
use PHPUnit\Framework\MockObject\MockObject;
use Symfony\Component\Console\Input\ArgvInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Throwable;

final class CliApplicationTest extends TestCase
{
    /**
     * @var CliContextInterface|MockObject
     */
    private CliContextInterface $context;

    private CliApplication $application;

    protected function setUp(): void
    {
        parent::setUp();
        $this->context = $this->createMock(CliContextInterface::class);
        $this->application = new CliApplication($this->context);
    }

    public function testInvalidStdInThrowsException(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid input resource');

        /** @psalm-var resource $stdIn */
        $stdIn = 'invalid';
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);
    }

    public function testInvalidStdOutThrowsException(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid output resource');

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = 'invalid';
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);
    }

    public function testInvalidStdErrThrowsException(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid error resource');

        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = 'invalid';
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);
    }

    public function testCorrectEnvironmentVariablesArePassedToApplicationContext(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [
            'key1' => 'value1',
            'key2' => 'value2',
        ];

        $this->context->expects(self::once())
            ->method('applyEnvironmentVariablesFromServer')
            ->willReturnCallback(
                function (array $passedServer) use ($server): void {
                    self::assertSame($server, $passedServer);
                }
            );

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);
    }

    public function testContainerFromApplicationContextIsReturned(): void
    {
        $container = $this->createStub(Container::class);
        $this->context->expects(self::atLeastOnce())
            ->method('container')
            ->willReturn($container);

        self::assertSame(
            $container,
            $this->application->container()
        );
    }

    public function testApplicationResetAlsoResetsContext(): void
    {
        $this->context->expects(self::once())
            ->method('reset');

        $this->application->reset();
    }

    public function testCorrectParametersArePassedToDispatcher(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'wb');
        fwrite($stdIn, 'Hello World');
        fseek($stdIn, 0);
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'wb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'wb');
        $server = [
            'argv' => ['application.php', '--flag1=value1', 'argument1', 'argument2'],
        ];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);

        $dispatcher = $this->createMock(CliDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function (InputInterface $input, OutputInterface $output): int {
                    self::assertInstanceOf(ArgvInput::class, $input);
                    self::assertSame(
                        '--flag1=value1 argument1 argument2',
                        (string)$input
                    );
                    /** @psalm-var resource $stdIn */
                    $stdIn = $input->getStream();
                    self::assertSame('Hello World', (string)stream_get_contents($stdIn));

                    self::assertInstanceOf(ConsoleOutput::class, $output);
                    $output->write('Output to stdOut');
                    $output->stdErr()->write('Output to stdErr');

                    return 0;
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        $this->application->execute();

        fseek($stdOut, 0);
        self::assertSame('Output to stdOut', stream_get_contents($stdOut));

        fseek($stdErr, 0);
        self::assertSame('Output to stdErr', stream_get_contents($stdErr));
    }

    public function testCorrectExitCodeIsReturnedByApplication(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);

        $expectedExitCode = 42;

        $dispatcher = $this->createMock(CliDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function () use ($expectedExitCode): int {
                    return $expectedExitCode;
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);

        self::assertSame(
            $expectedExitCode,
            $this->application->execute()
        );
    }

    public function testApplicationContextIsNotResetOnSuccessfulExecution(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);

        $dispatcher = $this->createMock(CliDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturn(0);
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);
        $this->context->expects(self::never())
            ->method('reset');

        $this->application->execute();
    }

    public function testApplicationContextIsNotResetIfDispatcherThrowsException(): void
    {
        /** @psalm-var resource $stdIn */
        $stdIn = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdOut */
        $stdOut = fopen('php://memory', 'rb');
        /** @psalm-var resource $stdErr */
        $stdErr = fopen('php://memory', 'rb');
        $server = [];

        $this->application->setRuntimeEnvironment($stdIn, $stdOut, $stdErr, $server);

        $expectedException = new Exception('Expected exception');

        $dispatcher = $this->createMock(CliDispatcherInterface::class);
        $dispatcher->expects(self::once())
            ->method('dispatch')
            ->willReturnCallback(
                function () use ($expectedException): int {
                    throw $expectedException;
                }
            );
        $this->context->expects(self::atLeastOnce())
            ->method('dispatcher')
            ->willReturn($dispatcher);
        $this->context->expects(self::never())
            ->method('reset');

        try {
            $this->application->execute();
            self::fail('Expected exception not thrown');
        } catch (Throwable $actualException) {
            self::assertSame($expectedException, $actualException);
        }
    }
}
