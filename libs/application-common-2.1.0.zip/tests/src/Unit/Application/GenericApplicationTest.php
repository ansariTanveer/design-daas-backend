<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application;

use Application\Common\Application\ApplicationContextInterface;
use Application\Common\Application\GenericApplication;
use Application\Test\TestCase;
use DI\Container;
use PHPUnit\Framework\MockObject\MockObject;

final class GenericApplicationTest extends TestCase
{
    /**
     * @var ApplicationContextInterface|MockObject
     */
    private ApplicationContextInterface $context;

    private GenericApplication $application;

    protected function setUp(): void
    {
        parent::setUp();
        $this->context = $this->createMock(ApplicationContextInterface::class);
        $this->application = new GenericApplication($this->context);
    }

    public function testContainerFromApplicationContextIsReturned(): void
    {
        $container = $this->createStub(Container::class);
        $this->context->expects(self::atLeastOnce())
            ->method('container')
            ->willReturn($container);

        self::assertSame(
            $container,
            $this->application->container()
        );
    }

    public function testApplicationResetAlsoResetsContext(): void
    {
        $this->context->expects(self::once())
            ->method('reset');

        $this->application->reset();
    }
}
