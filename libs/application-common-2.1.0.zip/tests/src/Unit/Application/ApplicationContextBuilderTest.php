<?php

declare(strict_types=1);

namespace Application\Test\Unit\Application;

use Application\Common\Application\ApplicationContextBuilder;
use Application\Common\Application\ApplicationContextInterface;
use Application\Test\TestCase;

final class ApplicationContextBuilderTest extends TestCase
{
    public function testCorrectFilesAreSelectedByDefault(): void
    {
        $expectedStaticFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.static.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_2.static.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_3.static.php',
        ];
        $expectedEnvironmentFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.env.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_2.env.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_3.env.php',
        ];
        $expectedInstance = $this->createMock(ApplicationContextInterface::class);

        $callbackCalled = false;
        $callback = function (
            array $staticFiles,
            array $environmentFiles
        ) use (
            $expectedStaticFiles,
            $expectedEnvironmentFiles,
            $expectedInstance,
            &$callbackCalled
        ): ApplicationContextInterface {
            self::assertSame($expectedStaticFiles, $staticFiles);
            self::assertSame($expectedEnvironmentFiles, $environmentFiles);
            self::assertFalse($callbackCalled);
            $callbackCalled = true;
            return $expectedInstance;
        };

        $builder = new ApplicationContextBuilder(
            ApplicationContextInterface::class,
            $callback
        );
        $builder->scanDir(self::TEST_CONFIG_DIR . '/Application');
        $actualInstance = $builder->build();

        self::assertTrue($callbackCalled);
        self::assertSame($expectedInstance, $actualInstance);
    }

    public function testCorrectFilesAreSelectedWithModifiedStaticFileSuffix(): void
    {
        $expectedStaticFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.alternative_static.php',
        ];
        $expectedEnvironmentFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.env.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_2.env.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_3.env.php',
        ];
        $expectedInstance = $this->createMock(ApplicationContextInterface::class);

        $callbackCalled = false;
        $callback = function (
            array $staticFiles,
            array $environmentFiles
        ) use (
            $expectedStaticFiles,
            $expectedEnvironmentFiles,
            $expectedInstance,
            &$callbackCalled
        ): ApplicationContextInterface {
            self::assertSame($expectedStaticFiles, $staticFiles);
            self::assertSame($expectedEnvironmentFiles, $environmentFiles);
            self::assertFalse($callbackCalled);
            $callbackCalled = true;
            return $expectedInstance;
        };

        $builder = new ApplicationContextBuilder(
            ApplicationContextInterface::class,
            $callback
        );
        $builder->withStaticFileSuffix('.alternative_static.php');
        $builder->scanDir(self::TEST_CONFIG_DIR . '/Application');
        $actualInstance = $builder->build();

        self::assertTrue($callbackCalled);
        self::assertSame($expectedInstance, $actualInstance);
    }

    public function testCorrectFilesAreSelectedWithModifiedEnvironmentFileSuffix(): void
    {
        $expectedStaticFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.static.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_2.static.php',
            self::TEST_CONFIG_DIR . '/Application/container_entries_3.static.php',
        ];
        $expectedEnvironmentFiles = [
            self::TEST_CONFIG_DIR . '/Application/container_entries_1.alternative_env.php',
        ];
        $expectedInstance = $this->createMock(ApplicationContextInterface::class);

        $callbackCalled = false;
        $callback = function (
            array $staticFiles,
            array $environmentFiles
        ) use (
            $expectedStaticFiles,
            $expectedEnvironmentFiles,
            $expectedInstance,
            &$callbackCalled
        ): ApplicationContextInterface {
            self::assertSame($expectedStaticFiles, $staticFiles);
            self::assertSame($expectedEnvironmentFiles, $environmentFiles);
            self::assertFalse($callbackCalled);
            $callbackCalled = true;
            return $expectedInstance;
        };

        $builder = new ApplicationContextBuilder(
            ApplicationContextInterface::class,
            $callback
        );
        $builder->withEnvironmentFileSuffix('.alternative_env.php');
        $builder->scanDir(self::TEST_CONFIG_DIR . '/Application');
        $actualInstance = $builder->build();

        self::assertTrue($callbackCalled);
        self::assertSame($expectedInstance, $actualInstance);
    }
}
