<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyRouting;

use Application\Common\SymfonyRouting\RouteNotFoundEvent;
use Application\Test\TestCase;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;

final class RouteNotFoundEventTest extends TestCase
{
    public function testSameRequestIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(ResourceNotFoundException::class);

        $event = new RouteNotFoundEvent($request, $exception);

        self::assertSame($request, $event->request());
    }

    public function testSameExceptionIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(ResourceNotFoundException::class);

        $event = new RouteNotFoundEvent($request, $exception);

        self::assertSame($exception, $event->exception());
    }

    public function testResponseIsNullByDefault(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(ResourceNotFoundException::class);

        $event = new RouteNotFoundEvent($request, $exception);

        self::assertNull($event->response());
    }

    public function testSetResponseIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(ResourceNotFoundException::class);

        $event = new RouteNotFoundEvent($request, $exception);

        $response = $this->createMock(ResponseInterface::class);
        $event->setResponse($response);
        self::assertSame($response, $event->response());
    }
}
