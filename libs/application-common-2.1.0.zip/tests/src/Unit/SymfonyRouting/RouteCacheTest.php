<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyRouting;

use Application\Common\SymfonyRouting\RouteCache;
use Application\Common\SymfonyRouting\RouteCollector;
use Application\Common\SymfonyRouting\RouteCollectorInterface;
use Application\Test\Assets\SymfonyRouting\RouteCache\InvokableController;
use Application\Test\Assets\SymfonyRouting\RouteCache\WorkingController;
use Application\Test\TestCase;
use Symfony\Component\Routing\RouteCollection;

final class RouteCacheTest extends TestCase
{
    private string $cacheFile;

    private string $controllerPath;

    private string $controllerPattern;

    /**
     * @var string[]
     */
    private array $expectedRouteNames;

    protected function setUp(): void
    {
        parent::setUp();
        $this->cacheFile = self::TEST_TMP_DIR . '/http-routes.cache';
        $this->controllerPath = self::TEST_SRC_DIR . '/SymfonyRouting/RouteCache';
        $this->controllerPattern = '*Controller.php';
        $this->expectedRouteNames = [
            'basic_action',
            'test1_some_action',
            'test1_do_something',
            'test2_some_action',
            'working_correctly',
            'invokable_action',
        ];
        sort($this->expectedRouteNames);
    }

    /**
     * @param RouteCollection $routes
     * @return string[]
     */
    private static function convertRouteList(RouteCollection $routes): array
    {
        $routeNames = array_keys($routes->all());
        sort($routeNames);
        return $routeNames;
    }

    public function testCorrectRoutesArePickedUp(): void
    {
        $collector = new RouteCollector();
        $collector->addSearchPath(
            $this->controllerPath,
            $this->controllerPattern
        );
        $cache = new RouteCache($collector, null);

        $routes = $cache->loadRouteCollection();

        $actualRouteNames = self::convertRouteList($routes);
        self::assertSame($this->expectedRouteNames, $actualRouteNames);
    }

    public function testRoutesAreCorrectlyCached(): void
    {
        $collector = new RouteCollector();
        $collector->addSearchPath(
            $this->controllerPath,
            $this->controllerPattern
        );
        $cache = new RouteCache($collector, $this->cacheFile);
        $cache->buildCache();
        unset($cache);
        unset($collector);

        $collector = $this->createMock(RouteCollectorInterface::class);
        $collector->expects(self::never())->method('collectRoutes');
        $cache = new RouteCache($collector, $this->cacheFile);

        $routes = $cache->loadRouteCollection();

        $actualRouteNames = self::convertRouteList($routes);
        self::assertSame($this->expectedRouteNames, $actualRouteNames);
    }

    public function testBuildingCacheWithoutCacheFileDoesNothing(): void
    {
        $collector = $this->createMock(RouteCollectorInterface::class);
        $collector->expects(self::never())->method('collectRoutes');
        $cache = new RouteCache($collector, null);

        $cache->buildCache();

        self::assertFileDoesNotExist($this->cacheFile);
    }

    public function testWorkingControllerAndActionNameIsSetCorrectly(): void
    {
        $collector = new RouteCollector();
        $collector->addSearchPath(
            $this->controllerPath,
            $this->controllerPattern
        );
        $cache = new RouteCache($collector, null);

        $route = $cache->loadRouteCollection()->get('working_correctly');

        self::assertNotNull(
            $route
        );

        self::assertSame(
            WorkingController::class . '::' . 'correctly',
            $route->getDefault('_controller')
        );

        self::assertSame(
            WorkingController::class,
            $route->getDefault('_controllerClass')
        );

        self::assertSame(
            'correctly',
            $route->getDefault('_controllerMethod')
        );
    }

    public function testInvokableControllerAndActionNameIsSetCorrectly(): void
    {
        $collector = new RouteCollector();
        $collector->addSearchPath(
            $this->controllerPath,
            $this->controllerPattern
        );
        $cache = new RouteCache($collector, null);

        $route = $cache->loadRouteCollection()->get('invokable_action');

        self::assertNotNull(
            $route
        );

        self::assertSame(
            InvokableController::class,
            $route->getDefault('_controller')
        );

        self::assertSame(
            InvokableController::class,
            $route->getDefault('_controllerClass')
        );

        self::assertSame(
            '__invoke',
            $route->getDefault('_controllerMethod')
        );
    }
}
