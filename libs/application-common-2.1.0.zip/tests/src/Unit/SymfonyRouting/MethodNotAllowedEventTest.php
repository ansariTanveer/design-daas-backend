<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyRouting;

use Application\Common\SymfonyRouting\MethodNotAllowedEvent;
use Application\Test\TestCase;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Component\Routing\Exception\MethodNotAllowedException;

final class MethodNotAllowedEventTest extends TestCase
{
    public function testSameRequestIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(MethodNotAllowedException::class);

        $event = new MethodNotAllowedEvent($request, $exception);

        self::assertSame($request, $event->request());
    }

    public function testSameExceptionIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(MethodNotAllowedException::class);

        $event = new MethodNotAllowedEvent($request, $exception);

        self::assertSame($exception, $event->exception());
    }

    public function testResponseIsNullByDefault(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(MethodNotAllowedException::class);

        $event = new MethodNotAllowedEvent($request, $exception);

        self::assertNull($event->response());
    }

    public function testSetResponseIsReturned(): void
    {
        $request = $this->createMock(ServerRequestInterface::class);
        $exception = $this->createMock(MethodNotAllowedException::class);

        $event = new MethodNotAllowedEvent($request, $exception);

        $response = $this->createMock(ResponseInterface::class);
        $event->setResponse($response);
        self::assertSame($response, $event->response());
    }
}
