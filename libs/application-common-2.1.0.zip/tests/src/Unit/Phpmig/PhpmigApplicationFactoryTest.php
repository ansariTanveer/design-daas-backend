<?php

declare(strict_types=1);

namespace Application\Test\Unit\Phpmig;

use Application\Common\Phpmig\PhpmigApplicationFactory;
use Application\Test\TestCase;
use ArrayAccess;
use ArrayObject;
use Phpmig\Migration\Migrator;
use ReflectionClass;
use Symfony\Component\Console\Output\OutputInterface;

final class PhpmigApplicationFactoryTest extends TestCase
{
    public function testCorrectDependenciesAreInjected(): void
    {
        /** @var ArrayAccess<string, mixed> $container */
        $container = new ArrayObject(
            [
                'phpmig.migrator' => $this->createMock(Migrator::class),
            ]
        );
        $output = $this->createMock(OutputInterface::class);

        $factory = new PhpmigApplicationFactory($container);
        $application = $factory->build($output);

        $reflection = new ReflectionClass($application);

        $containerProperty = $reflection->getProperty('container');
        $containerProperty->setAccessible(true);
        self::assertSame($container, $containerProperty->getValue($application));

        $outputProperty = $reflection->getProperty('output');
        $outputProperty->setAccessible(true);
        self::assertSame($output, $outputProperty->getValue($application));
    }
}
