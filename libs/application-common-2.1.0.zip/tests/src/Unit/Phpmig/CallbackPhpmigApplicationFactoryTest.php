<?php

declare(strict_types=1);

namespace Application\Test\Unit\Phpmig;

use Application\Common\Phpmig\CallbackPhpmigApplicationFactory;
use Application\Test\TestCase;
use Phpmig\Api\PhpmigApplication;
use Symfony\Component\Console\Output\OutputInterface;

final class CallbackPhpmigApplicationFactoryTest extends TestCase
{
    public function testCallbackIsCalledCorrectly(): void
    {
        $expectedPhpmigApplication = $this->createMock(PhpmigApplication::class);
        $expectedOutput = $this->createMock(OutputInterface::class);

        $callback = function (
            OutputInterface $output
        ) use (
            $expectedOutput,
            $expectedPhpmigApplication
        ): PhpmigApplication {
            self::assertSame($expectedOutput, $output);
            return $expectedPhpmigApplication;
        };

        $factory = new CallbackPhpmigApplicationFactory($callback);

        $buildPhpmigApplication = $factory->build($expectedOutput);

        self::assertSame($expectedPhpmigApplication, $buildPhpmigApplication);
    }
}
