<?php

declare(strict_types=1);

namespace Application\Test\Unit\Phpmig;

use Application\Common\Phpmig\PharCompatiblePhpmigApplication;
use Application\Test\TestCase;
use ArrayAccess;
use ArrayObject;
use Phpmig\Migration\Migrator;
use ReflectionClass;
use Symfony\Component\Console\Output\OutputInterface;

final class PharCompatiblePhpmigApplicationTest extends TestCase
{
    public function testFilesAreAccepted(): void
    {
        /** @var ArrayAccess<string, mixed> $container */
        $container = new ArrayObject(
            [
                'phpmig.migrator' => $this->createMock(Migrator::class),
                'phpmig.migrations' => [
                    'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/001_test_file_1.php',
                    'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/002_test_file_2.php',
                    'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/003_test_file_3.php',
                ],
                'phpmig.migrations_path' => 'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/test',
            ]
        );
        $output = $this->createMock(OutputInterface::class);

        $application = new PharCompatiblePhpmigApplication($container, $output);

        $reflection = new ReflectionClass($application);

        $containerProperty = $reflection->getProperty('migrations');
        $containerProperty->setAccessible(true);
        self::assertSame(
            [
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/001_test_file_1.php',
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/002_test_file_2.php',
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/003_test_file_3.php',
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/test/001_file_4.php',
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/test/002_file_5.php',
                'phar://' . self::TEST_CONFIG_DIR . '/Phpmig/test.phar/test/003_file_6.php',
            ],
            $containerProperty->getValue($application)
        );
    }
}
