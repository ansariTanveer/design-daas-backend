<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpMiddleware;

use Application\Common\HttpMiddleware\NaiveCORSResponseHeadersMiddleware;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ServerRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final class NaiveCORSResponseHeadersMiddlewareTest extends TestCase
{
    public function testRequestIsPassedOnCorrectly(): void
    {
        $expectedRequest = new ServerRequest('GET', '/');

        $middleware = new NaiveCORSResponseHeadersMiddleware();
        $middleware(
            $expectedRequest,
            function (ServerRequestInterface $actualRequest) use ($expectedRequest): ResponseInterface {
                self::assertSame($expectedRequest, $actualRequest);
                return new Response();
            }
        );
    }

    public function testMissingOriginHeaderIsFilledInWithAsterisk(): void
    {
        $request = new ServerRequest('GET', '/');
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertSame('*', $response->getHeaderLine('Access-Control-Allow-Origin'));
    }

    public function testOriginHeaderIsEchoedBackIfNotAlreadyPresentInResponse(): void
    {
        $origin = 'https://www.example.com';
        $request = new ServerRequest('GET', '/', ['Origin' => $origin]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertSame($origin, $response->getHeaderLine('Access-Control-Allow-Origin'));
    }

    public function testOriginHeaderAlreadyPresentInResponseIsNotReplaced(): void
    {
        $origin = 'https://www.example.com';
        $request = new ServerRequest('GET', '/', ['Origin' => $origin]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $expectedAllowOrigin = 'https://expected.example.com';
        /** @phpstan-ignore-next-line */
        self::assertNotSame($expectedAllowOrigin, $origin);
        $response = $middleware(
            $request,
            function () use ($expectedAllowOrigin): ResponseInterface {
                return new Response(200, ['Access-Control-Allow-Origin' => $expectedAllowOrigin]);
            }
        );

        self::assertSame($expectedAllowOrigin, $response->getHeaderLine('Access-Control-Allow-Origin'));
    }

    public function testRequestMethodHeaderIsEchoedBackIfNotAlreadyPresentInResponse(): void
    {
        $method = 'POST';
        $request = new ServerRequest('OPTIONS', '/', ['Access-Control-Request-Method' => $method]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertSame($method, $response->getHeaderLine('Access-Control-Allow-Methods'));
    }

    public function testRequestMethodHeaderIsNotEchoedBackIfNotOptionsRequest(): void
    {
        $method = 'POST';
        $request = new ServerRequest('GET', '/', ['Access-Control-Request-Method' => $method]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertFalse($response->hasHeader('Access-Control-Allow-Methods'));
    }

    public function testRequestMethodHeaderAlreadyPresentInResponseIsNotReplaced(): void
    {
        $method = 'POST';
        $request = new ServerRequest('OPTIONS', '/', ['Access-Control-Request-Method' => $method]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $expectedAllowMethods = 'GET';
        /** @phpstan-ignore-next-line */
        self::assertNotSame($expectedAllowMethods, $method);
        $response = $middleware(
            $request,
            function () use ($expectedAllowMethods): ResponseInterface {
                return new Response(200, ['Access-Control-Allow-Methods' => $expectedAllowMethods]);
            }
        );

        self::assertSame($expectedAllowMethods, $response->getHeaderLine('Access-Control-Allow-Methods'));
    }

    public function testRequestHeadersHeaderIsEchoedBackIfNotAlreadyPresentInResponse(): void
    {
        $headers = 'request-header';
        $request = new ServerRequest('OPTIONS', '/', ['Access-Control-Request-Headers' => $headers]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertSame($headers, $response->getHeaderLine('Access-Control-Allow-Headers'));
    }

    public function testRequestHeadersHeaderIsNotEchoedBackIfNotOptionsRequest(): void
    {
        $headers = 'request-header';
        $request = new ServerRequest('GET', '/', ['Access-Control-Request-Headers' => $headers]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $response = $middleware(
            $request,
            function (): ResponseInterface {
                return new Response();
            }
        );

        self::assertFalse($response->hasHeader('Access-Control-Allow-Headers'));
    }

    public function testRequestHeadersHeaderAlreadyPresentInResponseIsNotReplaced(): void
    {
        $headers = 'request-header';
        $request = new ServerRequest('OPTIONS', '/', ['Access-Control-Request-Headers' => $headers]);
        $middleware = new NaiveCORSResponseHeadersMiddleware();

        $expectedAllowHeaders = 'some-header, another-header';
        /** @phpstan-ignore-next-line */
        self::assertNotSame($expectedAllowHeaders, $headers);
        $response = $middleware(
            $request,
            function () use ($expectedAllowHeaders): ResponseInterface {
                return new Response(200, ['Access-Control-Allow-Headers' => $expectedAllowHeaders]);
            }
        );

        self::assertSame($expectedAllowHeaders, $response->getHeaderLine('Access-Control-Allow-Headers'));
    }
}
