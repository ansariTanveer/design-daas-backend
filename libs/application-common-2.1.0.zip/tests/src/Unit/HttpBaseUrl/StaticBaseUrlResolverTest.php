<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpBaseUrl;

use Application\Common\HttpBaseUrl\StaticBaseUrlResolver;
use Application\Test\TestCase;
use Psr\Http\Message\UriInterface;

final class StaticBaseUrlResolverTest extends TestCase
{
    public function testCorrectBaseUrlIsReturned(): void
    {
        $baseUrl = $this->createMock(UriInterface::class);
        $resolver = new StaticBaseUrlResolver($baseUrl);
        self::assertSame($baseUrl, $resolver->baseUrl());
    }
}
