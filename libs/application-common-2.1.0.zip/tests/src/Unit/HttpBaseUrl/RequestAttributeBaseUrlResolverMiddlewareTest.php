<?php

declare(strict_types=1);

namespace Application\Test\Unit\HttpBaseUrl;

use Application\Common\HttpBaseUrl\RequestAttributeBaseUrlResolverMiddleware;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ServerRequest;
use LogicException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UriInterface;

final class RequestAttributeBaseUrlResolverMiddlewareTest extends TestCase
{
    public function testRequestIsPassedOnCorrectly(): void
    {
        $expectedRequest = new ServerRequest('GET', '/');
        $expectedRequest = $expectedRequest->withAttribute(
            'base_url',
            $this->createMock(UriInterface::class)
        );

        $middleware = new RequestAttributeBaseUrlResolverMiddleware('base_url');
        $middleware(
            $expectedRequest,
            function (ServerRequestInterface $actualRequest) use ($expectedRequest): ResponseInterface {
                self::assertSame($expectedRequest, $actualRequest);
                return new Response();
            }
        );
    }

    public function testInvalidBaseUrlThrowsException(): void
    {
        $request = new ServerRequest('GET', '/');

        $middleware = new RequestAttributeBaseUrlResolverMiddleware('base_url');
        $this->expectException(LogicException::class);
        $middleware(
            $request,
            function () {
                self::fail('$next is not expected to be called');
            }
        );
    }

    public function testCorrectResponseIsReturned(): void
    {
        $request = new ServerRequest('GET', '/');
        $request = $request->withAttribute(
            'base_url',
            $this->createMock(UriInterface::class)
        );
        $expectedResponse = $this->createMock(ResponseInterface::class);

        $middleware = new RequestAttributeBaseUrlResolverMiddleware('base_url');
        $response = $middleware(
            $request,
            function () use ($expectedResponse): ResponseInterface {
                return $expectedResponse;
            }
        );

        self::assertSame($expectedResponse, $response);
    }

    public function testCorrectBaseUrlIsReturned(): void
    {
        $expectedBaseUrl = $this->createMock(UriInterface::class);
        $request = new ServerRequest('GET', '/');
        $request = $request->withAttribute(
            'base_url',
            $expectedBaseUrl
        );

        $middleware = new RequestAttributeBaseUrlResolverMiddleware('base_url');
        $middleware(
            $request,
            function (): ResponseInterface {
                return $this->createMock(ResponseInterface::class);
            }
        );

        self::assertSame($expectedBaseUrl, $middleware->baseUrl());
    }
}
