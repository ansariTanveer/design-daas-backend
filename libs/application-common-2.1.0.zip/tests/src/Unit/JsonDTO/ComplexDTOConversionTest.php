<?php

declare(strict_types=1);

namespace Application\Test\Unit\JsonDTO;

use Application\Test\Assets\JsonDTO\ComplexTestDTO;
use Application\Test\Assets\JsonDTO\SimpleTestDTO;
use Application\Test\TestCase;
use stdClass;

final class ComplexDTOConversionTest extends TestCase
{
    public function testFromJson(): void
    {
        $json = new stdClass();
        $json->childDTO = new stdClass();
        $json->childDTO->property1untyped = 'value1.1';
        $json->childDTO->property3typed = 'value1.3';
        $json->childDTOs = [
            0 => new stdClass(),
            1 => new stdClass(),
        ];
        $json->childDTOs[0]->property2untyped = 'value2.0.2';
        $json->childDTOs[0]->property4typed = 'value2.0.4';
        $json->childDTOs[1]->property3typed = 'value2.1.3';

        $dto = ComplexTestDTO::fromJson($json);

        self::assertSame($json->childDTO->property1untyped, $dto->childDTO->property1untyped);
        self::assertFalse(isset($dto->childDTO->property2untyped));
        self::assertSame($json->childDTO->property3typed, $dto->childDTO->property3typed);
        self::assertFalse(isset($dto->childDTO->property4typed));

        self::assertFalse(isset($dto->childDTOs[0]->property1untyped));
        self::assertSame($json->childDTOs[0]->property2untyped, $dto->childDTOs[0]->property2untyped);
        self::assertFalse(isset($dto->childDTOs[0]->property3typed));
        self::assertSame($json->childDTOs[0]->property4typed, $dto->childDTOs[0]->property4typed);

        self::assertFalse(isset($dto->childDTOs[1]->property1untyped));
        self::assertFalse(isset($dto->childDTOs[1]->property2untyped));
        self::assertSame($json->childDTOs[1]->property3typed, $dto->childDTOs[1]->property3typed);
        self::assertFalse(isset($dto->childDTOs[1]->property4typed));
    }

    public function testConvertToJson(): void
    {
        $dto = new ComplexTestDTO();
        $dto->childDTOs = [
            0 => new SimpleTestDTO(),
            1 => new SimpleTestDTO(),
        ];
        $dto->childDTOs[0]->property1untyped = 'value2.0.1';
        $dto->childDTOs[1]->property2untyped = 'value2.1.2';
        $dto->childDTOs[1]->property4typed = 'value2.1.4';

        $json = json_decode((string)json_encode($dto));

        self::assertInstanceOf(stdClass::class, $json);
        self::assertFalse(property_exists($json, 'childDTO'));
        self::assertTrue(property_exists($json, 'childDTOs'));
        self::assertIsArray($json->childDTOs);
        self::assertArrayHasKey(0, $json->childDTOs);
        self::assertInstanceOf(stdClass::class, $json->childDTOs[0]);
        self::assertTrue(property_exists($json->childDTOs[0], 'property1untyped'));
        self::assertFalse(property_exists($json->childDTOs[0], 'property2untyped'));
        self::assertFalse(property_exists($json->childDTOs[0], 'property3typed'));
        self::assertFalse(property_exists($json->childDTOs[0], 'property4typed'));
        self::assertArrayHasKey(1, $json->childDTOs);
        self::assertInstanceOf(stdClass::class, $json->childDTOs[1]);
        self::assertFalse(property_exists($json->childDTOs[1], 'property1untyped'));
        self::assertTrue(property_exists($json->childDTOs[1], 'property2untyped'));
        self::assertFalse(property_exists($json->childDTOs[1], 'property3typed'));
        self::assertTrue(property_exists($json->childDTOs[1], 'property4typed'));

        self::assertSame($dto->childDTOs[0]->property1untyped, $json->childDTOs[0]->property1untyped);
        self::assertSame($dto->childDTOs[1]->property2untyped, $json->childDTOs[1]->property2untyped);
        self::assertSame($dto->childDTOs[1]->property4typed, $json->childDTOs[1]->property4typed);
    }
}
