<?php

declare(strict_types=1);

namespace Application\Test\Unit\JsonDTO;

use Application\Test\Assets\JsonDTO\SimpleTestDTO;
use Application\Test\TestCase;
use Http\Factory\Guzzle\StreamFactory;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use ReflectionClass;
use ReflectionProperty;
use stdClass;

final class SimpleDTOConversionTest extends TestCase
{
    public function testPropertiesUnsetByDefault(): void
    {
        $dto = new SimpleTestDTO();

        self::assertFalse(isset($dto->property1untyped));
        self::assertFalse(isset($dto->property2untyped));
        self::assertFalse(isset($dto->property3typed));
        self::assertFalse(isset($dto->property4typed));
    }

    public function testPropertiesUninitializedByDefault(): void
    {
        $dto = new SimpleTestDTO();

        $reflectionClass = new ReflectionClass($dto);

        $property1 = $reflectionClass->getProperty('property1untyped');
        self::assertFalse($property1->isInitialized($dto));

        $property2 = $reflectionClass->getProperty('property2untyped');
        self::assertFalse($property2->isInitialized($dto));

        $property3 = $reflectionClass->getProperty('property3typed');
        self::assertFalse($property3->isInitialized($dto));

        $property4 = $reflectionClass->getProperty('property4typed');
        self::assertFalse($property4->isInitialized($dto));
    }

    public function testFromJson(): void
    {
        $json = new stdClass();
        $json->property1untyped = 'value1';
        $json->property3typed = 'value3';

        $dto = SimpleTestDTO::fromJson($json);

        self::assertSame($json->property1untyped, $dto->property1untyped);
        self::assertFalse(isset($dto->property2untyped));
        self::assertSame($json->property3typed, $dto->property3typed);
        self::assertFalse(isset($dto->property4typed));
    }

    public function testFromRequest(): void
    {
        $json = new stdClass();
        $json->property2untyped = 'value2';
        $json->property4typed = 'value4';
        $request = $this->createMock(ServerRequestInterface::class);
        $request->method('getBody')->willReturn(
            (new StreamFactory())->createStream((string)json_encode($json))
        );

        $dto = SimpleTestDTO::fromRequest($request);

        self::assertFalse(isset($dto->property1untyped));
        self::assertSame($json->property2untyped, $dto->property2untyped);
        self::assertFalse(isset($dto->property3typed));
        self::assertSame($json->property4typed, $dto->property4typed);
    }

    public function testFromResponse(): void
    {
        $json = new stdClass();
        $json->property1untyped = 'value1';
        $json->property3typed = 'value3';

        $response = $this->createMock(ResponseInterface::class);
        $response->method('getBody')->willReturn(
            (new StreamFactory())->createStream((string)json_encode($json))
        );

        $dto = SimpleTestDTO::fromResponse($response);

        self::assertSame($json->property1untyped, $dto->property1untyped);
        self::assertFalse(isset($dto->property2untyped));
        self::assertSame($json->property3typed, $dto->property3typed);
        self::assertFalse(isset($dto->property4typed));
    }

    public function testConvertToJson(): void
    {
        $dto = new SimpleTestDTO();
        $dto->property1untyped = 'value1';
        $dto->property3typed = 'value3';

        $json = json_decode((string)json_encode($dto));

        self::assertInstanceOf(stdClass::class, $json);
        self::assertTrue(property_exists($json, 'property1untyped'));
        self::assertFalse(property_exists($json, 'property2untyped'));
        self::assertTrue(property_exists($json, 'property3typed'));
        self::assertFalse(property_exists($json, 'property4typed'));

        self::assertSame($dto->property1untyped, $json->property1untyped);
        self::assertSame($dto->property3typed, $json->property3typed);
    }

    public function testNullValuesAreConvertedToJson(): void
    {
        $dto = new SimpleTestDTO();
        $dto->property1untyped = 'value1';
        $dto->property2untyped = null;
        $dto->property3typed = 'value3';
        $dto->property4typed = null;

        $json = json_decode((string)json_encode($dto));

        self::assertInstanceOf(stdClass::class, $json);
        self::assertTrue(property_exists($json, 'property1untyped'));
        self::assertTrue(property_exists($json, 'property2untyped'));
        self::assertTrue(property_exists($json, 'property3typed'));
        self::assertTrue(property_exists($json, 'property4typed'));

        self::assertSame($dto->property1untyped, $json->property1untyped);
        self::assertSame($dto->property2untyped, $json->property2untyped);
        self::assertSame($dto->property3typed, $json->property3typed);
        self::assertSame($dto->property4typed, $json->property4typed);
    }

    public function testExtraPropertiesInJsonAreIgnored(): void
    {
        $json = new stdClass();
        $json->property2untyped = 'value2';
        $json->property4typed = 'value4';
        $json->property6missing = 'value6';

        $dto = SimpleTestDTO::fromJson($json);

        self::assertFalse(isset($dto->property1untyped));
        self::assertSame($json->property2untyped, $dto->property2untyped);
        self::assertFalse(isset($dto->property3typed));
        self::assertSame($json->property4typed, $dto->property4typed);

        self::assertSame(
            ['property1untyped', 'property2untyped', 'property3typed', 'property4typed'],
            array_values(
                array_map(
                    function (ReflectionProperty $property) {
                        return $property->getName();
                    },
                    array_filter(
                        (new ReflectionClass($dto))->getProperties(),
                        function (ReflectionProperty $property) {
                            return $property->isPublic() && !$property->isStatic();
                        }
                    )
                )
            )
        );

        self::assertSame(
            ['property2untyped', 'property4typed'],
            array_keys(get_object_vars($dto))
        );
    }

    public function testDifferenceBetweenNullAndUnsetPropertiesCanBeDetected(): void
    {
        $dto = new SimpleTestDTO();
        $dto->property1untyped = null;
        $dto->property3typed = null;

        self::assertFalse($dto->hasProperty('staticPropertyWillBeIgnored'));
        self::assertFalse($dto->hasProperty('protectedPropertyWillBeIgnored'));
        self::assertFalse($dto->hasProperty('privatePropertyWillBeIgnored'));

        self::assertTrue($dto->hasProperty('property1untyped'));
        self::assertFalse($dto->hasProperty('property2untyped'));
        self::assertTrue($dto->hasProperty('property3typed'));
        self::assertFalse($dto->hasProperty('property4typed'));
    }
}
