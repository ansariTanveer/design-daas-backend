<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineDBAL;

use Application\Common\DoctrineDBAL\CallbackConnectionPreparer;
use Application\Test\TestCase;
use Doctrine\Common\EventManager;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\Configuration;

final class CallbackConnectionPreparerTest extends TestCase
{
    public function testDefaultPrepareParamsReturnsArrayUnmodified(): void
    {
        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            null,
            null
        );

        $expected = ['hello' => 'world', 'test' => 42];
        $actual = $connectionPreparer->prepareParams($expected);

        self::assertSame($expected, $actual);
    }

    public function testPrepareParamsCallsCorrectCallback(): void
    {
        $originalParams = ['hello' => 'world', 'test' => 42];
        $paramsToReturn = ['return' => 'params'];
        $callbackCalled = false;
        $prepareParamsCallback = function (
            array $params
        ) use (
            &$callbackCalled,
            $originalParams,
            $paramsToReturn
        ): array {
            self::assertFalse($callbackCalled);
            $callbackCalled = true;
            self::assertSame($originalParams, $params);
            return $paramsToReturn;
        };

        $connectionPreparer = new CallbackConnectionPreparer(
            $prepareParamsCallback,
            null,
            null,
            null
        );

        $returnedParams = $connectionPreparer->prepareParams($originalParams);

        self::assertTrue($callbackCalled);
        self::assertSame($paramsToReturn, $returnedParams);
    }

    public function testDefaultPrepareConfigurationReturnsNull(): void
    {
        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            null,
            null
        );

        $actual = $connectionPreparer->prepareConfiguration();

        self::assertNull($actual);
    }

    public function testPrepareConfigurationCallsCorrectCallback(): void
    {
        $expectedConfiguration = $this->createMock(Configuration::class);
        $expectedConfiguration->expects(self::never())
            ->method(self::anything());
        $prepareConfigurationCallback = function () use ($expectedConfiguration): Configuration {
            return $expectedConfiguration;
        };
        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            $prepareConfigurationCallback,
            null,
            null
        );

        $actualConfiguration = $connectionPreparer->prepareConfiguration();

        self::assertSame($expectedConfiguration, $actualConfiguration);
    }

    public function testDefaultPrepareEventManagerReturnsNull(): void
    {
        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            null,
            null
        );

        $actual = $connectionPreparer->prepareEventManager();

        self::assertNull($actual);
    }

    public function testPrepareEventManagerCallsCorrectCallback(): void
    {
        $expectedEventManager = $this->createMock(EventManager::class);
        $expectedEventManager->expects(self::never())
            ->method(self::anything());
        $prepareEventManagerCallback = function () use ($expectedEventManager): EventManager {
            return $expectedEventManager;
        };
        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            $prepareEventManagerCallback,
            null
        );

        $actualEventManager = $connectionPreparer->prepareEventManager();

        self::assertSame($expectedEventManager, $actualEventManager);
    }

    public function testDefaultPrepareConnectionDoesNotModifyConnection(): void
    {
        $connection = $this->createMock(Connection::class);
        $connection->expects(self::never())
            ->method(self::anything());

        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            null,
            null
        );

        $connectionPreparer->prepareConnection($connection);
    }

    public function testPrepareConnectionCallsCorrectCallback(): void
    {
        $expectedConnection = $this->createMock(Connection::class);
        $expectedConnection->expects(self::never())
            ->method(self::anything());
        $callbackCalled = false;
        $prepareConnectionCallback = function (
            Connection $connection
        ) use (
            &$callbackCalled,
            $expectedConnection
        ): void {
            self::assertFalse($callbackCalled);
            $callbackCalled = true;
            self::assertSame($expectedConnection, $connection);
        };

        $connectionPreparer = new CallbackConnectionPreparer(
            null,
            null,
            null,
            $prepareConnectionCallback
        );

        $connectionPreparer->prepareConnection($expectedConnection);

        self::assertTrue($callbackCalled);
    }
}
