<?php

declare(strict_types=1);

namespace Application\Test\Unit\DoctrineDBAL;

use Application\Common\DoctrineDBAL\NullConnectionPreparer;
use Application\Test\TestCase;
use Doctrine\DBAL\Connection;

final class NullConnectionPreparerTest extends TestCase
{
    public function testPrepareParamsReturnsArrayUnmodified(): void
    {
        $connectionPreparer = new NullConnectionPreparer();

        $expected = ['hello' => 'world', 'test' => 42];
        $actual = $connectionPreparer->prepareParams($expected);

        self::assertSame($expected, $actual);
    }

    public function testPrepareConfigurationReturnsNull(): void
    {
        $connectionPreparer = new NullConnectionPreparer();

        $actual = $connectionPreparer->prepareConfiguration();

        self::assertNull($actual);
    }

    public function testPrepareEventManagerReturnsNull(): void
    {
        $connectionPreparer = new NullConnectionPreparer();

        $actual = $connectionPreparer->prepareEventManager();

        self::assertNull($actual);
    }

    public function testPrepareConnectionDoesNotModifyConnection(): void
    {
        $connection = $this->createMock(Connection::class);
        $connection->expects(self::never())
            ->method(self::anything());

        $connectionPreparer = new NullConnectionPreparer();

        $connectionPreparer->prepareConnection($connection);
    }
}
