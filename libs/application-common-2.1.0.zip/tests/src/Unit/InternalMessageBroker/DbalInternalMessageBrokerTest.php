<?php

declare(strict_types=1);

namespace Application\Test\Unit\InternalMessageBroker;

use Application\Common\InternalMessageBroker\DbalInternalMessageBroker;
use Application\Common\InternalMessageBroker\ProcessingResult;
use Application\Test\TestCase;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\EntityManagerInterface;
use Enqueue\Dbal\DbalConsumer;
use Enqueue\Dbal\DbalContext;
use Enqueue\Dbal\DbalDestination;
use Enqueue\Dbal\DbalMessage;
use Enqueue\Dbal\DbalProducer;
use Enqueue\Dbal\DbalSubscriptionConsumer;
use LogicException;
use ReflectionClass;

final class DbalInternalMessageBrokerTest extends TestCase
{
    private static function extractContext(DbalInternalMessageBroker $broker): DbalContext
    {
        $reflection = new ReflectionClass($broker);
        $property = $reflection->getProperty('context');
        $property->setAccessible(true);
        $context = $property->getValue($broker);
        assert($context instanceof DbalContext);
        return $context;
    }

    public function testFromConnection(): void
    {
        $connectionMock = $this->createMock(Connection::class);
        $broker = DbalInternalMessageBroker::fromConnection('someDatabaseTable', $connectionMock);
        $context = self::extractContext($broker);

        self::assertSame(
            'someDatabaseTable',
            $context->getTableName()
        );

        self::assertSame(
            $connectionMock,
            $context->getDbalConnection()
        );
    }

    public function testFromEntityManager(): void
    {
        $connectionMock = $this->createMock(Connection::class);
        $emMock = $this->createMock(EntityManagerInterface::class);
        $emMock->method('getConnection')->willReturn($connectionMock);
        $broker = DbalInternalMessageBroker::fromEntityManager('someDatabaseTable', $emMock);
        $context = self::extractContext($broker);

        self::assertSame(
            'someDatabaseTable',
            $context->getTableName()
        );

        self::assertSame(
            $connectionMock,
            $context->getDbalConnection()
        );
    }

    public function testSendMessageWithDelayBelowZeroThrowsException(): void
    {
        $contextMock = $this->createMock(DbalContext::class);
        $broker = new DbalInternalMessageBroker($contextMock);

        $this->expectException(LogicException::class);
        $this->expectExceptionMessageMatches('=\$delayInMs must be at least 0=');

        $broker->sendMessage('someQueue', 'someMessage', -1);
    }

    public function testReceiveMessagesWithTimeoutBelowZeroThrowsException(): void
    {
        $contextMock = $this->createMock(DbalContext::class);
        $broker = new DbalInternalMessageBroker($contextMock);

        $this->expectException(LogicException::class);
        $this->expectExceptionMessageMatches('=\$timeoutInMs must be at least 0=');

        $processor = function (string $message): ProcessingResult {
            self::fail('Processor was not expected to be called');
        };
        $broker->receiveMessages('someQueue', $processor, -1);
    }

    public function testReceiveMessagesWithRedeliveryDelayBelowZeroThrowsException(): void
    {
        $contextMock = $this->createMock(DbalContext::class);
        $broker = new DbalInternalMessageBroker($contextMock);

        $this->expectException(LogicException::class);
        $this->expectExceptionMessageMatches('=\$redeliveryDelayInMs must be at least 0=');

        $processor = function (string $message): ProcessingResult {
            self::fail('Processor was not expected to be called');
        };
        $broker->receiveMessages('someQueue', $processor, 1, -1);
    }

    public function testSendMessageSendsToCorrectQueue(): void
    {
        $expectedQueue = 'someQueue';
        $destinationMock = $this->createMock(DbalDestination::class);

        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::never())
            ->method('setDeliveryDelay');

        $producerMock = $this->createMock(DbalProducer::class);
        $producerMock->expects(self::once())
            ->method('send')
            ->willReturnCallback(
                function (DbalDestination $destination, DbalMessage $message) use ($destinationMock): void {
                    self::assertSame($destinationMock, $destination);
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createQueue')
            ->with($expectedQueue)
            ->willReturn($destinationMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createMessage')
            ->willReturn($messageMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createProducer')
            ->willReturn($producerMock);

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->sendMessage($expectedQueue, 'someMessage');
    }

    public function testSendMessageSendsCorrectMessage(): void
    {
        $expectedMessage = 'someMessage';
        $destinationMock = $this->createMock(DbalDestination::class);

        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::never())
            ->method('setDeliveryDelay');

        $producerMock = $this->createMock(DbalProducer::class);
        $producerMock->expects(self::once())
            ->method('send')
            ->willReturnCallback(
                function (DbalDestination $destination, DbalMessage $message) use ($messageMock): void {
                    self::assertSame($messageMock, $message);
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createQueue')
            ->willReturn($destinationMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createMessage')
            ->with($expectedMessage)
            ->willReturn($messageMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createProducer')
            ->willReturn($producerMock);

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->sendMessage('someQueue', $expectedMessage);
    }

    public function testSendMessageSendsCorrectDeliveryDelay(): void
    {
        $expectedDeliveryDelay = 42;
        $destinationMock = $this->createMock(DbalDestination::class);

        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::atLeastOnce())
            ->method('setDeliveryDelay')
            ->with($expectedDeliveryDelay);

        $producerMock = $this->createMock(DbalProducer::class);
        $producerMock->expects(self::once())
            ->method('send')
            ->willReturnCallback(
                function (DbalDestination $destination, DbalMessage $message) use ($messageMock): void {
                    self::assertSame($messageMock, $message);
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createQueue')
            ->willReturn($destinationMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createMessage')
            ->willReturn($messageMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createProducer')
            ->willReturn($producerMock);

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->sendMessage('someQueue', 'someMessage', $expectedDeliveryDelay);
    }

    public function testReceiveMessagesUsesCorrectQueue(): void
    {
        $expectedQueue = 'someQueue';
        $destinationMock = $this->createMock(DbalDestination::class);
        $consumerMock = $this->createMock(DbalConsumer::class);

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createQueue')
            ->with($expectedQueue)
            ->willReturn($destinationMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->with($destinationMock)
            ->willReturn($consumerMock);

        $processor = function (string $message): ProcessingResult {
            self::fail('Processor was not expected to be called');
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages($expectedQueue, $processor);
    }

    public function testReceiveMessagesUsesCorrectTimeout(): void
    {
        $expectedTimeout = 42;
        $consumerMock = $this->createMock(DbalConsumer::class);

        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('consume')
            ->with($expectedTimeout);

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message): ProcessingResult {
            self::fail('Processor was not expected to be called');
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor, $expectedTimeout);
    }

    public function testReceiveMessagesSetsCorrectRedeliveryDelay(): void
    {
        $expectedRedeliveryDelay = 42;

        $consumerMock = $this->createMock(DbalConsumer::class);
        $consumerMock->expects(self::atLeastOnce())
            ->method('setRedeliveryDelay')
            ->with($expectedRedeliveryDelay);

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);

        $processor = function (string $message): ProcessingResult {
            self::fail('Processor was not expected to be called');
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor, 0, $expectedRedeliveryDelay);
    }

    public function testReceiveMessagesPassesCorrectMessageToProcessor(): void
    {
        $expectedMessage = 'someMessage';
        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::atLeastOnce())
            ->method('getBody')
            ->willReturn($expectedMessage);

        $consumerMock = $this->createMock(DbalConsumer::class);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message) use ($expectedMessage): ProcessingResult {
            self::assertSame($expectedMessage, $message);
            return ProcessingResult::acknowledge();
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $extractedCallback($messageMock, $consumerMock);
    }

    public function testReceiveMessagesAcknowledgesMessageCorrectly(): void
    {
        $messageMock = $this->createMock(DbalMessage::class);

        $consumerMock = $this->createMock(DbalConsumer::class);
        $consumerMock->expects(self::once())
            ->method('acknowledge')
            ->with($messageMock);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message): ProcessingResult {
            return ProcessingResult::acknowledge();
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $extractedCallback($messageMock, $consumerMock);
    }

    public function testReceiveMessagesRejectsMessageWithoutRedeliveryCorrectly(): void
    {
        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::once())
            ->method('setDeliveryDelay')
            ->with(null);

        $consumerMock = $this->createMock(DbalConsumer::class);
        $consumerMock->expects(self::once())
            ->method('reject')
            ->with($messageMock, false);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message): ProcessingResult {
            return ProcessingResult::rejectAndDiscard();
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $extractedCallback($messageMock, $consumerMock);
    }

    public function testReceiveMessagesRejectsMessageWithRedeliveryCorrectly(): void
    {
        $expectedRedeliveryDelay = 42;

        $messageMock = $this->createMock(DbalMessage::class);
        $messageMock->expects(self::once())
            ->method('setDeliveryDelay')
            ->with($expectedRedeliveryDelay);

        $consumerMock = $this->createMock(DbalConsumer::class);
        $consumerMock->expects(self::once())
            ->method('reject')
            ->with($messageMock, true);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message) use ($expectedRedeliveryDelay): ProcessingResult {
            return ProcessingResult::rejectAndRedeliver($expectedRedeliveryDelay);
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $extractedCallback($messageMock, $consumerMock);
    }

    public function testReceiveMessagesContinuesProcessingIfNotInstructedToStop(): void
    {
        $messageMock = $this->createMock(DbalMessage::class);
        $consumerMock = $this->createMock(DbalConsumer::class);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message): ProcessingResult {
            return new ProcessingResult(true, null, true);
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $continueProcessing = $extractedCallback($messageMock, $consumerMock);

        self::assertTrue($continueProcessing);
    }

    public function testReceiveMessagesStopsProcessingIfInstructedToDoSo(): void
    {
        $messageMock = $this->createMock(DbalMessage::class);
        $consumerMock = $this->createMock(DbalConsumer::class);

        $extractedCallback = null;
        $subscriptionConsumerMock = $this->createMock(DbalSubscriptionConsumer::class);
        $subscriptionConsumerMock->expects(self::once())
            ->method('subscribe')
            ->with($consumerMock)
            ->willReturnCallback(
                function (DbalConsumer $consumer, callable $callback) use (&$extractedCallback): void {
                    $extractedCallback = $callback;
                }
            );

        $contextMock = $this->createMock(DbalContext::class);
        $contextMock->expects(self::atLeastOnce())
            ->method('createConsumer')
            ->willReturn($consumerMock);
        $contextMock->expects(self::atLeastOnce())
            ->method('createSubscriptionConsumer')
            ->willReturn($subscriptionConsumerMock);

        $processor = function (string $message): ProcessingResult {
            return new ProcessingResult(true, null, false);
        };

        $broker = new DbalInternalMessageBroker($contextMock);
        $broker->receiveMessages('someQueue', $processor);

        self::assertIsCallable($extractedCallback);
        $continueProcessing = $extractedCallback($messageMock, $consumerMock);

        self::assertFalse($continueProcessing);
    }
}
