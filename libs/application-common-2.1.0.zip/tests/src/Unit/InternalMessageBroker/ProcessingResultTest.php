<?php

declare(strict_types=1);

namespace Application\Test\Unit\InternalMessageBroker;

use Application\Common\InternalMessageBroker\ProcessingResult;
use Application\Test\TestCase;
use LogicException;

final class ProcessingResultTest extends TestCase
{
    public function testAcknowledgeConstructorSetsCorrectProperties(): void
    {
        $result = ProcessingResult::acknowledge();

        self::assertTrue($result->acknowledgeMessage());
        self::assertFalse($result->redeliverMessage());
        self::assertNull($result->redeliverMessageAfterMs());
        self::assertTrue($result->continueProcessing());
    }

    public function testRejectAndDiscardConstructorSetsCorrectProperties(): void
    {
        $result = ProcessingResult::rejectAndDiscard();

        self::assertFalse($result->acknowledgeMessage());
        self::assertFalse($result->redeliverMessage());
        self::assertNull($result->redeliverMessageAfterMs());
        self::assertTrue($result->continueProcessing());
    }

    public function testRejectAndRedeliverConstructorSetsCorrectProperties(): void
    {
        $redeliveryDelay = 42;

        $result = ProcessingResult::rejectAndRedeliver($redeliveryDelay);

        self::assertFalse($result->acknowledgeMessage());
        self::assertTrue($result->redeliverMessage());
        self::assertSame($redeliveryDelay, $result->redeliverMessageAfterMs());
        self::assertTrue($result->continueProcessing());
    }

    public function testAcknowledgeMessageWithRedeliveryDelayThrowsException(): void
    {
        $this->expectException(LogicException::class);
        $this->expectExceptionMessageMatches(
            '=Acknowledged messages cannot be redelivered, \$redeliverAfterMs must be null='
        );

        new ProcessingResult(true, 0, true);
    }

    public function testRedeliveryDelayBelowZeroThrowsException(): void
    {
        $this->expectException(LogicException::class);
        $this->expectExceptionMessageMatches(
            '=\$redeliverAfterMs must be null or at least 0='
        );

        new ProcessingResult(false, -1, true);
    }
}
