<?php

declare(strict_types=1);

namespace Application\Test\Unit\SymfonyEventDispatcher;

use Application\Common\SymfonyEventDispatcher\EventSubscriberCache;
use Application\Common\SymfonyEventDispatcher\EventSubscriberCollector;
use Application\Common\SymfonyEventDispatcher\EventSubscriberCollectorInterface;
use Application\Test\Assets\SymfonyEventDispatcher\EventSubscriberCache\AnotherEventSubscriber;
use Application\Test\Assets\SymfonyEventDispatcher\EventSubscriberCache\SimpleEventSubscriber;
use Application\Test\TestCase;

final class EventSubscriberCacheTest extends TestCase
{
    private string $cacheFile;

    private string $subscriberPath;

    private string $subscriberPattern;

    /**
     * @var class-string[]
     */
    private array $expectedClassNames;

    protected function setUp(): void
    {
        parent::setUp();
        $this->cacheFile = self::TEST_TMP_DIR . '/event-subscribers.cache';
        $this->subscriberPath = self::TEST_SRC_DIR . '/SymfonyEventDispatcher/EventSubscriberCache';
        $this->subscriberPattern = '*EventSubscriber.php';
        $this->expectedClassNames = [
            SimpleEventSubscriber::class,
            AnotherEventSubscriber::class,
        ];
        sort($this->expectedClassNames);
    }

    public function testCorrectClassNamesArePickedUp(): void
    {
        $collector = new EventSubscriberCollector();
        $collector->addSearchPath(
            $this->subscriberPath,
            $this->subscriberPattern
        );
        $cache = new EventSubscriberCache($collector, null);

        $actualClassNames = $cache->loadEventSubscriberClassNames();
        sort($actualClassNames);

        self::assertSame($this->expectedClassNames, $actualClassNames);
    }

    public function testClassNamesAreCorrectlyCached(): void
    {
        $collector = new EventSubscriberCollector();
        $collector->addSearchPath(
            $this->subscriberPath,
            $this->subscriberPattern
        );
        $cache = new EventSubscriberCache($collector, $this->cacheFile);
        $cache->buildCache();
        unset($cache);
        unset($collector);

        $collector = $this->createMock(EventSubscriberCollectorInterface::class);
        $collector->expects(self::never())->method('collectEventSubscriberClassNames');
        $cache = new EventSubscriberCache($collector, $this->cacheFile);

        $actualClassNames = $cache->loadEventSubscriberClassNames();
        sort($actualClassNames);

        self::assertSame($this->expectedClassNames, $actualClassNames);
    }

    public function testBuildingCacheWithoutCacheFileDoesNothing(): void
    {
        $collector = $this->createMock(EventSubscriberCollectorInterface::class);
        $collector->expects(self::never())->method('collectEventSubscriberClassNames');
        $cache = new EventSubscriberCache($collector, null);

        $cache->buildCache();

        self::assertFileDoesNotExist($this->cacheFile);
    }
}
