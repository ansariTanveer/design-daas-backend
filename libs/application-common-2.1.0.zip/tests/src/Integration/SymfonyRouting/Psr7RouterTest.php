<?php

declare(strict_types=1);

namespace Application\Test\Integration\SymfonyRouting;

use Application\Common\HttpBaseUrl\BaseUrlResolverInterface;
use Application\Common\HttpBaseUrl\StaticBaseUrlResolver;
use Application\Common\SymfonyRouting\MethodNotAllowedEvent;
use Application\Common\SymfonyRouting\Psr7Router;
use Application\Common\SymfonyRouting\RouteCache;
use Application\Common\SymfonyRouting\RouteCacheInterface;
use Application\Common\SymfonyRouting\RouteCollector;
use Application\Common\SymfonyRouting\RouteNotFoundEvent;
use Application\Test\Assets\SymfonyRouting\RouteCache\WorkingController;
use Application\Test\TestCase;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ServerRequest;
use GuzzleHttp\Psr7\Uri;
use Http\Factory\Guzzle\ResponseFactory;
use PHPUnit\Framework\MockObject\MockObject;
use Psr\EventDispatcher\EventDispatcherInterface as PsrEventDispatcherInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;

final class Psr7RouterTest extends TestCase
{
    private const BASE_URL = 'https://www.example.com';

    /**
     * @var PsrEventDispatcherInterface|MockObject
     */
    private PsrEventDispatcherInterface $eventDispatcher;

    private Psr7Router $router;

    protected function setUp(): void
    {
        parent::setUp();

        $collector = new RouteCollector();
        $collector->addSearchPath(
            self::TEST_SRC_DIR . '/SymfonyRouting/RouteCache',
            '*Controller.php'
        );

        $this->eventDispatcher = $this->createMock(PsrEventDispatcherInterface::class);

        $this->router = new Psr7Router(
            new StaticBaseUrlResolver(new Uri(self::BASE_URL)),
            new RouteCache($collector, null),
            new ResponseFactory(),
            $this->eventDispatcher
        );
    }

    public function testSuccessfulRouting(): void
    {
        $expectedResponse = $this->createMock(ResponseInterface::class);
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::once())
            ->method('handle')
            ->willReturnCallback(
                function (ServerRequestInterface $request) use ($expectedResponse): ResponseInterface {
                    self::assertSame(
                        WorkingController::class . '::correctly',
                        $request->getAttribute($this->router->routeNameAttribute())
                    );
                    return $expectedResponse;
                }
            );

        $response = $this->router->process(
            new ServerRequest('GET', self::BASE_URL . '/working-correctly'),
            $handlerMock
        );

        self::assertSame($expectedResponse, $response);
    }

    public function testRouteNotFoundDefaultResponse(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::never())->method('handle');

        $response = $this->router->process(
            new ServerRequest('GET', self::BASE_URL . '/does-not-exist'),
            $handlerMock
        );

        self::assertSame(404, $response->getStatusCode());
    }

    public function testRouteNotFoundEventResponseIsUsed(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::never())->method('handle');

        $expectedResponse = new Response();
        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(
                function (RouteNotFoundEvent $event) use ($expectedResponse): void {
                    self::assertNull($event->response());
                    $event->setResponse($expectedResponse);
                }
            );

        $response = $this->router->process(
            new ServerRequest('GET', self::BASE_URL . '/does-not-exist'),
            $handlerMock
        );

        self::assertSame($expectedResponse, $response);
    }

    public function testMethodNotAllowedDefaultResponse(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::never())->method('handle');

        $response = $this->router->process(
            new ServerRequest('POST', self::BASE_URL . '/working-correctly'),
            $handlerMock
        );

        self::assertSame(405, $response->getStatusCode());
        self::assertFalse($response->hasHeader('Allow'));
    }

    public function testMethodNotAllowedEventResponseIsUsed(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::never())->method('handle');

        $expectedResponse = new Response();
        $this->eventDispatcher->expects(self::atLeastOnce())
            ->method('dispatch')
            ->willReturnCallback(
                function (MethodNotAllowedEvent $event) use ($expectedResponse): void {
                    self::assertNull($event->response());
                    $event->setResponse($expectedResponse);
                }
            );

        $response = $this->router->process(
            new ServerRequest('POST', self::BASE_URL . '/working-correctly'),
            $handlerMock
        );

        self::assertSame($expectedResponse, $response);
    }

    public function testOptionsRequestReturnsAllowedMethods(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::never())->method('handle');

        $response = $this->router->process(
            new ServerRequest('OPTIONS', self::BASE_URL . '/working-correctly'),
            $handlerMock
        );

        self::assertSame(200, $response->getStatusCode());
        self::assertSame('GET', $response->getHeaderLine('Allow'));
    }

    public function testOptionsAreAttachedToRequest(): void
    {
        $handlerMock = $this->createMock(RequestHandlerInterface::class);
        $handlerMock->expects(self::once())
            ->method('handle')
            ->willReturnCallback(
                function (ServerRequestInterface $request): ResponseInterface {
                    $options = $request->getAttribute($this->router->routeOptionsAttribute());
                    self::assertIsArray($options);
                    self::assertArrayHasKey('hello', $options);
                    self::assertSame('world', $options['hello']);
                    self::assertArrayHasKey('some', $options);
                    self::assertSame(['additional', 'data'], $options['some']);
                    return $this->createMock(ResponseInterface::class);
                }
            );

        $this->router->process(
            new ServerRequest('GET', self::BASE_URL . '/working-correctly'),
            $handlerMock
        );
    }

    public function testDefaultAttributesNamesAreSet(): void
    {
        $router = new Psr7Router(
            $this->createMock(BaseUrlResolverInterface::class),
            $this->createMock(RouteCacheInterface::class),
            $this->createMock(ResponseFactoryInterface::class),
            $this->createMock(PsrEventDispatcherInterface::class)
        );

        self::assertSame('route_name', $router->routeNameAttribute());
        self::assertSame('route_parameters', $router->routeParametersAttribute());
        self::assertSame('route_options', $router->routeOptionsAttribute());
    }

    public function testCustomAttributesNamesAreSet(): void
    {
        $router = new Psr7Router(
            $this->createMock(BaseUrlResolverInterface::class),
            $this->createMock(RouteCacheInterface::class),
            $this->createMock(ResponseFactoryInterface::class),
            $this->createMock(PsrEventDispatcherInterface::class),
            '__PHPUNIT_ROUTE_NAME',
            '__PHPUNIT_ROUTE_PARAMETERS',
            '__PHPUNIT_ROUTE_OPTIONS'
        );

        self::assertSame('__PHPUNIT_ROUTE_NAME', $router->routeNameAttribute());
        self::assertSame('__PHPUNIT_ROUTE_PARAMETERS', $router->routeParametersAttribute());
        self::assertSame('__PHPUNIT_ROUTE_OPTIONS', $router->routeOptionsAttribute());
    }
}
