<?php

declare(strict_types=1);

namespace Application\Test\Integration\InternalMessageBroker;

use Application\Common\DoctrineDBAL\DatabaseConnectionFactoryInterface;
use Application\Common\InternalMessageBroker\DbalInternalMessageBroker;
use Application\Common\InternalMessageBroker\ProcessingResult;
use Application\Test\TestCase;
use Application\Test\TestDoctrineDBALConnections;
use Enqueue\Dbal\DbalContext;

final class DbalInternalMessageBrokerUsageTest extends TestCase
{
    /**
     * @return array<string, array<DatabaseConnectionFactoryInterface>>
     */
    public function dataProvider(): array
    {
        return TestDoctrineDBALConnections::databaseConnectionFactoryDataProvider();
    }

    private function prepareBroker(DatabaseConnectionFactoryInterface $dbFactory): DbalInternalMessageBroker
    {
        $tableName = 'TEST_INTERNAL_MESSAGE_BROKER';

        $connection = $dbFactory->build();
        if ($connection->getSchemaManager()->tablesExist($tableName)) {
            $connection->getSchemaManager()->dropTable($tableName);
        }

        $context = new DbalContext($connection, ['table_name' => $tableName]);
        $context->createDataBaseTable();

        return new DbalInternalMessageBroker($context);
    }

    /**
     * @dataProvider dataProvider
     */
    public function testSendAndReceiveMessages(DatabaseConnectionFactoryInterface $dbFactory): void
    {
        $broker = $this->prepareBroker($dbFactory);
        $queue = 'TEST_QUEUE';

        $messages = [
            'Message1' => true,
            'Message2' => false,
            'Message3' => true,
        ];
        $expectedMessageCount = 4; // the number of $messages + the number of messages that are rejected

        foreach (array_keys($messages) as $message) {
            $broker->sendMessage($queue, $message);
        }

        $actualMessageCount = 0;
        $stoppedProcessing = false;
        $processor = function (
            string $actualMessage
        ) use (
            &$messages,
            &$actualMessageCount,
            &$stoppedProcessing
        ): ProcessingResult {
            self::assertFalse($stoppedProcessing);
            self::assertArrayHasKey($actualMessage, $messages);
            $acknowledge = $messages[$actualMessage];
            unset($messages[$actualMessage]);
            if (!$acknowledge) {
                $messages[$actualMessage] = true;
            }
            $actualMessageCount++;
            $stoppedProcessing = count($messages) < 1;
            return new ProcessingResult(
                $acknowledge,
                $acknowledge ? null : 0,
                !$stoppedProcessing
            );
        };
        /*
         * The timeout is only used as a safeguard to prevent the test from hanging forever.
         * Processing of the expected messages is supposed to happen in the fraction of a second, but the
         * actual runtime will vary depending on the current load of the system running the test.
         * To account for this variance the timeout is rather generous, which hopefully prevents false positives.
         */
        $timeoutInMs = 10000;
        $broker->receiveMessages($queue, $processor, $timeoutInMs);

        self::assertTrue($stoppedProcessing);
        self::assertSame($expectedMessageCount, $actualMessageCount);
        self::assertCount(0, $messages);
    }
}
