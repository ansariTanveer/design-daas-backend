<?php

declare(strict_types=1);

namespace Application\Test;

use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use ReflectionClass;
use SplFileInfo;
use Symfony\Contracts\Service\ResetInterface;

abstract class TestCase extends \PHPUnit\Framework\TestCase
{
    /**
     * @var string
     */
    public const TEST_CONFIG_DIR = __DIR__ . '/../assets/config';

    /**
     * @var string
     */
    public const TEST_SRC_DIR = __DIR__ . '/../assets/src';

    /**
     * @var string
     */
    public const TEST_TMP_DIR = __DIR__ . '/../assets/tmp';

    protected function tearDown(): void
    {
        parent::tearDown();
        self::clearTestTmpFiles();

        /*
         * Automatically cleanup properties of child classes
         */
        $class = new ReflectionClass($this);
        foreach ($class->getProperties() as $property) {
            if (!is_subclass_of($property->class, self::class) || $property->isStatic()) {
                continue;
            }
            $property->setAccessible(true);
            $type = $property->getType();
            if ($type === null || $type->allowsNull()) {
                $property->setValue($this, null);
            } elseif ($property->isInitialized($this)) {
                $value = $property->getValue($this);
                if ($value instanceof ResetInterface) {
                    $value->reset();
                }
            }
        }
    }

    public static function tearDownAfterClass(): void
    {
        parent::tearDownAfterClass();

        /*
         * Automatically cleanup properties of child classes
         */
        $class = new ReflectionClass(static::class);
        foreach ($class->getProperties() as $property) {
            if (!is_subclass_of($property->class, self::class) || !$property->isStatic()) {
                continue;
            }
            $property->setAccessible(true);
            $type = $property->getType();
            if ($type === null || $type->allowsNull()) {
                $property->setValue(null);
            } elseif ($property->isInitialized()) {
                $value = $property->getValue();
                if ($value instanceof ResetInterface) {
                    $value->reset();
                }
            }
        }
    }

    public static function clearTestTmpFiles(): void
    {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(self::TEST_TMP_DIR, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($files as $file) {
            assert($file instanceof SplFileInfo);
            $path = $file->getPathname();
            if ($path === self::TEST_TMP_DIR . '/.gitignore') {
                continue;
            }
            if ($file->isDir()) {
                rmdir($path);
            } else {
                unlink($path);
            }
        }
    }
}
