# Library with common code used across applications

## Development Setup

- `make init` to initialize the development containers and dependencies
- `make up` to start the docker development environment
- `make` or `make check` can be used to run PHPCS, PHPStan and PHPUnit
    - `make cs` to run PHPCS alone
    - `make stan` to run PHPStan alone
    - `make test` to run all PHPUnit tests
    - `make test-unit` to only run PHPUnit unit tests
    - `make test-integration` to only run PHPUnit integration tests
    - `make test-compatibility` to run all PHPUnit tests with different PHP versions
- `make down` to stop the docker development environment
